<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Set content type header first
header('Content-Type: application/json');

// Include database config
$db_path = dirname(__DIR__) . '/config/database.php';
if (!file_exists($db_path)) {
    echo json_encode(['success' => false, 'message' => 'Database file not found']);
    exit();
}

require_once $db_path;

// Start session if not started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check authentication
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

// Check request method
if ($_SERVER['REQUEST_METHOD'] != 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit();
}

// Get parameters
$teacher_id = intval($_POST['teacher_id'] ?? 0);
$teacher_photo_path = $_POST['teacher_photo'] ?? '';
$action = $_POST['action'] ?? 'checkin'; // 'checkin' or 'checkout'

if ($teacher_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid teacher selected']);
    exit();
}

// Check if teacher exists and get their photo
$teacher_check = $mysqli->prepare("SELECT id, fullname, photo FROM teachers WHERE id = ?");
$teacher_check->bind_param("i", $teacher_id);
$teacher_check->execute();
$teacher_result = $teacher_check->get_result();

if ($teacher_result->num_rows == 0) {
    echo json_encode(['success' => false, 'message' => 'Teacher not found']);
    exit();
}

$teacher = $teacher_result->fetch_assoc();

// Get the actual teacher photo path from database
$db_teacher_photo = $teacher['photo'];
if (!$db_teacher_photo || $db_teacher_photo == 'null') {
    echo json_encode(['success' => false, 'message' => 'Teacher has no profile photo. Please upload one first.']);
    exit();
}

// Get today's date and current time
$today = date('Y-m-d');
$current_time = date('H:i:s');

// Check if attendance record exists for today
$check_stmt = $mysqli->prepare("SELECT id, status, check_in, check_out FROM attendance WHERE teacher_id = ? AND date = ?");
$check_stmt->bind_param("is", $teacher_id, $today);
$check_stmt->execute();
$check_result = $check_stmt->get_result();
$existing_record = $check_result->fetch_assoc();

// Validate action based on existing record
if ($action == 'checkin' && $existing_record && $existing_record['check_in']) {
    echo json_encode([
        'success' => false,
        'message' => 'Already checked in today at ' . $existing_record['check_in']
    ]);
    exit();
}

if ($action == 'checkout' && !$existing_record) {
    echo json_encode([
        'success' => false,
        'message' => 'Cannot check out. No check-in record found for today.'
    ]);
    exit();
}

if ($action == 'checkout' && $existing_record && $existing_record['check_out'] && $existing_record['check_out'] != '00:00:00') {
    echo json_encode([
        'success' => false,
        'message' => 'Already checked out today at ' . $existing_record['check_out']
    ]);
    exit();
}

// Perform face comparison
$match_score = 0;
$comparison_result = false;

if (isset($_FILES['face_image']) && $_FILES['face_image']['error'] == 0) {
    // Get the captured image
    $captured_image_tmp = $_FILES['face_image']['tmp_name'];
    
    // Get the stored teacher photo
    $teacher_photo_full_path = dirname(__DIR__) . '/' . $db_teacher_photo;
    
    // Check if teacher photo exists
    if (file_exists($teacher_photo_full_path)) {
        // Perform face comparison
        $match_score = compareFaces($captured_image_tmp, $teacher_photo_full_path);
        
        // Set threshold for match (70% similarity)
        if ($match_score >= 70) {
            $comparison_result = true;
        } else {
            // Face doesn't match well enough
            echo json_encode([
                'success' => false,
                'message' => 'Face verification failed. The captured image does not match the teacher\'s profile photo. Please ensure proper lighting and positioning.',
                'match_score' => round($match_score, 2)
            ]);
            exit();
        }
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Teacher profile photo not found on server. Please re-upload the photo.'
        ]);
        exit();
    }
} else {
    echo json_encode(['success' => false, 'message' => 'No face image captured']);
    exit();
}

// Handle face image upload and storage
$captured_image_path = null;
if (isset($_FILES['face_image']) && $_FILES['face_image']['error'] == 0) {
    $upload_dir = dirname(__DIR__) . '/uploads/attendance/';
    if (!file_exists($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }
    
    $file_extension = strtolower(pathinfo($_FILES['face_image']['name'], PATHINFO_EXTENSION));
    $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];
    
    if (in_array($file_extension, $allowed_extensions)) {
        $filename = $today . '_' . $teacher_id . '_' . time() . '_' . $action . '.' . $file_extension;
        $target_path = $upload_dir . $filename;
        
        if (move_uploaded_file($_FILES['face_image']['tmp_name'], $target_path)) {
            $captured_image_path = 'uploads/attendance/' . $filename;
        }
    }
}

// Determine status based on time (late if after 8:30 AM) - only for check-in
$late_time = '08:30:00';
$status = null;
$response_data = [];

if ($action == 'checkin') {
    $status = ($current_time > $late_time) ? 'Late' : 'Present';
    
    // Insert new attendance record
    $stmt = $mysqli->prepare("INSERT INTO attendance (teacher_id, date, check_in, status, captured_image, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
    if (!$stmt) {
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $mysqli->error]);
        exit();
    }
    
    $stmt->bind_param("issss", $teacher_id, $today, $current_time, $status, $captured_image_path);
    
    if ($stmt->execute()) {
        $attendance_id = $stmt->insert_id;
        
        // Insert face verification log
        $log_stmt = $mysqli->prepare("INSERT INTO face_verification_logs (attendance_id, teacher_id, captured_image, match_score, verified_by) VALUES (?, ?, ?, ?, ?)");
        $verified_by = $_SESSION['user_id'];
        $log_stmt->bind_param("iisdi", $attendance_id, $teacher_id, $captured_image_path, $match_score, $verified_by);
        $log_stmt->execute();
        $log_stmt->close();
        
        // Log the activity
        error_log("Check-in for Teacher ID: $teacher_id ($teacher[fullname]) on $today at $current_time - Status: $status - Match Score: " . round($match_score, 2) . "%");
        
        $response_data = [
            'success' => true,
            'message' => 'Check-in successful with face verification!',
            'action' => 'checkin',
            'status' => $status,
            'time' => $current_time,
            'teacher_name' => $teacher['fullname'],
            'match_score' => round($match_score, 2),
            'captured_image' => $captured_image_path
        ];
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to mark check-in: ' . $stmt->error]);
        exit();
    }
    $stmt->close();
    
} else if ($action == 'checkout') {
    // Update existing record with check-out time
    $stmt = $mysqli->prepare("UPDATE attendance SET check_out = ?, captured_image = ? WHERE id = ?");
    if (!$stmt) {
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $mysqli->error]);
        exit();
    }
    
    $stmt->bind_param("ssi", $current_time, $captured_image_path, $existing_record['id']);
    
    if ($stmt->execute()) {
        // Insert face verification log for check-out
        $log_stmt = $mysqli->prepare("INSERT INTO face_verification_logs (attendance_id, teacher_id, captured_image, match_score, verified_by) VALUES (?, ?, ?, ?, ?)");
        $verified_by = $_SESSION['user_id'];
        $log_stmt->bind_param("iisdi", $existing_record['id'], $teacher_id, $captured_image_path, $match_score, $verified_by);
        $log_stmt->execute();
        $log_stmt->close();
        
        // Log the activity
        error_log("Check-out for Teacher ID: $teacher_id ($teacher[fullname]) on $today at $current_time - Match Score: " . round($match_score, 2) . "%");
        
        $response_data = [
            'success' => true,
            'message' => 'Check-out successful with face verification!',
            'action' => 'checkout',
            'status' => $existing_record['status'],
            'time' => $current_time,
            'teacher_name' => $teacher['fullname'],
            'match_score' => round($match_score, 2),
            'captured_image' => $captured_image_path
        ];
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to mark check-out: ' . $stmt->error]);
        exit();
    }
    $stmt->close();
}

$check_stmt->close();
$teacher_check->close();

echo json_encode($response_data);

/**
 * Face comparison function
 * 
 * IMPORTANT: This is a simplified placeholder for demonstration.
 * For production, integrate with a proper face recognition service:
 * 
 * Option 1: Use Face++ API (https://console.faceplusplus.com/)
 * Option 2: Use Amazon Rekognition (https://aws.amazon.com/rekognition/)
 * Option 3: Use Microsoft Face API (https://azure.microsoft.com/en-us/services/cognitive-services/face/)
 * Option 4: Use OpenCV with face_recognition Python library via API call
 * 
 * This function currently uses a simple image hash comparison as demo
 */
function compareFaces($captured_image_path, $stored_image_path) {
    // For demo purposes, we'll use a simple perceptual hash comparison
    // This is NOT accurate for production but shows the flow
    
    if (!file_exists($captured_image_path) || !file_exists($stored_image_path)) {
        return 0;
    }
    
    // Simple image hash comparison (demo only)
    $hash1 = simpleImageHash($captured_image_path);
    $hash2 = simpleImageHash($stored_image_path);
    
    // Calculate similarity percentage
    $similarity = calculateHashSimilarity($hash1, $hash2);
    
    // For demo, return a higher score if images are similar
    // In production, use proper face recognition API
    return $similarity;
}

/**
 * Simple image hash for demo purposes only
 * DO NOT USE for actual face recognition
 */
function simpleImageHash($image_path) {
    $img = imagecreatefromjpeg($image_path);
    if (!$img) {
        $img = imagecreatefrompng($image_path);
    }
    if (!$img) {
        return '';
    }
    
    // Resize to 8x8
    $resized = imagecreatetruecolor(8, 8);
    imagecopyresampled($resized, $img, 0, 0, 0, 0, 8, 8, imagesx($img), imagesy($img));
    
    // Convert to grayscale and calculate average
    $pixels = [];
    $total = 0;
    for ($y = 0; $y < 8; $y++) {
        for ($x = 0; $x < 8; $x++) {
            $rgb = imagecolorat($resized, $x, $y);
            $r = ($rgb >> 16) & 0xFF;
            $g = ($rgb >> 8) & 0xFF;
            $b = $rgb & 0xFF;
            $gray = ($r + $g + $b) / 3;
            $pixels[] = $gray;
            $total += $gray;
        }
    }
    
    $average = $total / 64;
    
    // Create hash
    $hash = '';
    foreach ($pixels as $pixel) {
        $hash .= ($pixel >= $average) ? '1' : '0';
    }
    
    imagedestroy($img);
    imagedestroy($resized);
    
    return $hash;
}

function calculateHashSimilarity($hash1, $hash2) {
    if (strlen($hash1) != strlen($hash2)) {
        return 0;
    }
    
    $differences = 0;
    for ($i = 0; $i < strlen($hash1); $i++) {
        if ($hash1[$i] != $hash2[$i]) {
            $differences++;
        }
    }
    
    $similarity = (1 - ($differences / strlen($hash1))) * 100;
    return $similarity;
}
?>