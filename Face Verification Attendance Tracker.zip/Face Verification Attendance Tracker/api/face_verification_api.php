<?php
/**
 * Face Verification API
 * Handles all face verification related operations including:
 * - Getting teachers list
 * - Fetching attendance records with filters
 * - Getting verification details
 * - Overriding attendance verification
 * - Comparing faces
 * 
 * @package Attendance System
 * @author Your Name
 * @version 1.0
 */

// Enable error reporting for debugging (disable in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Set content type header
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Include database config
$db_path = dirname(__DIR__) . '/config/database.php';
if (!file_exists($db_path)) {
    echo json_encode(['success' => false, 'message' => 'Database configuration not found']);
    exit();
}

require_once $db_path;

// Start session if not started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check authentication
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit();
}

$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['user_role'] ?? 'teacher';

// Get action from request
$action = $_GET['action'] ?? $_POST['action'] ?? '';

if (empty($action)) {
    echo json_encode(['success' => false, 'message' => 'No action specified']);
    exit();
}

// Route to appropriate handler
switch ($action) {
    case 'get_teachers':
        getTeachers($mysqli);
        break;
    case 'get_attendances':
        getAttendances($mysqli, $user_role);
        break;
    case 'get_verification_details':
        getVerificationDetails($mysqli);
        break;
    case 'override_attendance':
        overrideAttendance($mysqli, $user_id);
        break;
    case 'compare_faces':
        compareFacesAPI($mysqli, $user_id);
        break;
    case 'get_stats':
        getStats($mysqli);
        break;
    case 'bulk_verify':
        bulkVerify($mysqli, $user_id);
        break;
    default:
        echo json_encode(['success' => false, 'message' => 'Invalid action: ' . $action]);
        break;
}

/**
 * Get all teachers for dropdown
 * 
 * @param mysqli $mysqli Database connection
 */
function getTeachers($mysqli) {
    try {
        $sql = $mysqli->prepare("
            SELECT id, fullname, email, subject, phone, photo, created_at 
            FROM teachers 
            ORDER BY fullname ASC
        ");
        
        if (!$sql) {
            throw new Exception($mysqli->error);
        }
        
        $sql->execute();
        $result = $sql->get_result();
        
        $teachers = [];
        while ($row = $result->fetch_assoc()) {
            // Add full image URL
            $row['photo_url'] = !empty($row['photo']) ? '/' . $row['photo'] : null;
            $teachers[] = $row;
        }
        
        echo json_encode([
            'success' => true,
            'teachers' => $teachers,
            'total' => count($teachers)
        ]);
        
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => 'Failed to fetch teachers: ' . $e->getMessage()
        ]);
    }
}

/**
 * Get attendance records with filtering options
 * 
 * @param mysqli $mysqli Database connection
 * @param string $user_role User role for permission checks
 */
function getAttendances($mysqli, $user_role) {
    try {
        // Get filter parameters
        $status = $_GET['status'] ?? 'all';
        $attendance_status = $_GET['attendance_status'] ?? 'all';
        $teacher_id = isset($_GET['teacher_id']) && $_GET['teacher_id'] !== '' ? intval($_GET['teacher_id']) : null;
        $date = $_GET['date'] ?? '';
        $start_date = $_GET['start_date'] ?? '';
        $end_date = $_GET['end_date'] ?? '';
        $limit = isset($_GET['limit']) ? intval($_GET['limit']) : 100;
        $offset = isset($_GET['offset']) ? intval($_GET['offset']) : 0;
        
        // Build base query
        $query = "
            SELECT 
                a.id,
                a.teacher_id,
                a.date,
                a.check_in,
                a.check_out,
                a.status as attendance_status,
                a.captured_image,
                a.created_at as attendance_created_at,
                t.fullname as teacher_name,
                t.email as teacher_email,
                t.subject as teacher_subject,
                t.photo as teacher_photo,
                f.id as verification_id,
                f.match_score,
                f.admin_override,
                f.admin_notes,
                f.verified_by,
                f.created_at as verified_at,
                u.fullname as verified_by_name,
                CASE 
                    WHEN f.admin_override = 1 THEN 'overridden'
                    WHEN f.match_score >= 70 THEN 'verified'
                    WHEN f.match_score IS NOT NULL AND f.match_score < 70 THEN 'unverified'
                    WHEN f.match_score IS NULL THEN 'unverified'
                    ELSE 'unverified'
                END as verification_status
            FROM attendance a
            INNER JOIN teachers t ON a.teacher_id = t.id
            LEFT JOIN face_verification_logs f ON a.id = f.attendance_id
            LEFT JOIN users u ON f.verified_by = u.id
            WHERE 1=1
        ";
        
        $params = [];
        $types = '';
        
        // Apply verification status filter
        if ($status !== 'all') {
            if ($status === 'verified') {
                $query .= " AND (f.match_score >= 70 OR f.match_score IS NOT NULL) AND (f.admin_override = 0 OR f.admin_override IS NULL)";
            } elseif ($status === 'unverified') {
                $query .= " AND (f.match_score < 70 OR f.match_score IS NULL) AND (f.admin_override = 0 OR f.admin_override IS NULL)";
            } elseif ($status === 'overridden') {
                $query .= " AND f.admin_override = 1";
            }
        }
        
        // Apply attendance status filter
        if ($attendance_status !== 'all') {
            $query .= " AND a.status = ?";
            $params[] = ucfirst($attendance_status);
            $types .= 's';
        }
        
        // Apply teacher filter
        if ($teacher_id) {
            $query .= " AND a.teacher_id = ?";
            $params[] = $teacher_id;
            $types .= 'i';
        }
        
        // Apply single date filter
        if ($date) {
            $query .= " AND a.date = ?";
            $params[] = $date;
            $types .= 's';
        }
        
        // Apply date range filter
        if ($start_date && $end_date) {
            $query .= " AND a.date BETWEEN ? AND ?";
            $params[] = $start_date;
            $params[] = $end_date;
            $types .= 'ss';
        } elseif ($start_date) {
            $query .= " AND a.date >= ?";
            $params[] = $start_date;
            $types .= 's';
        } elseif ($end_date) {
            $query .= " AND a.date <= ?";
            $params[] = $end_date;
            $types .= 's';
        }
        
        // Add ordering and limits
        $query .= " ORDER BY a.date DESC, a.created_at DESC LIMIT ? OFFSET ?";
        $params[] = $limit;
        $params[] = $offset;
        $types .= 'ii';
        
        // Prepare and execute query
        $stmt = $mysqli->prepare($query);
        if (!$stmt) {
            throw new Exception($mysqli->error);
        }
        
        if (!empty($params)) {
            $stmt->bind_param($types, ...$params);
        }
        
        $stmt->execute();
        $result = $stmt->get_result();
        
        $attendances = [];
        while ($row = $result->fetch_assoc()) {
            // Format match score
            $row['match_score'] = $row['match_score'] ? round($row['match_score'], 2) : null;
            
            // Format times
            $row['check_in'] = $row['check_in'] ? substr($row['check_in'], 0, 5) : null;
            $row['check_out'] = $row['check_out'] ? substr($row['check_out'], 0, 5) : null;
            
            // Add image URLs
            $row['captured_image_url'] = !empty($row['captured_image']) ? '/' . $row['captured_image'] : null;
            $row['teacher_photo_url'] = !empty($row['teacher_photo']) ? '/' . $row['teacher_photo'] : null;
            
            $attendances[] = $row;
        }
        
        // Get statistics
        $stats = getAttendanceStats($mysqli);
        
        echo json_encode([
            'success' => true,
            'attendances' => $attendances,
            'stats' => $stats,
            'total_returned' => count($attendances),
            'filters' => [
                'status' => $status,
                'attendance_status' => $attendance_status,
                'teacher_id' => $teacher_id,
                'date' => $date,
                'start_date' => $start_date,
                'end_date' => $end_date,
                'limit' => $limit,
                'offset' => $offset
            ]
        ]);
        
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => 'Failed to fetch attendances: ' . $e->getMessage()
        ]);
    }
}

/**
 * Get attendance statistics
 * 
 * @param mysqli $mysqli Database connection
 * @return array Statistics data
 */
function getAttendanceStats($mysqli) {
    try {
        $stats = [
            'total' => 0,
            'verified' => 0,
            'unverified' => 0,
            'overridden' => 0,
            'present' => 0,
            'absent' => 0,
            'late' => 0
        ];
        
        // Total records
        $total_sql = $mysqli->query("SELECT COUNT(*) as count FROM attendance");
        if ($total_sql) {
            $stats['total'] = $total_sql->fetch_object()->count ?? 0;
        }
        
        // Verified (match_score >= 70 and not overridden)
        $verified_sql = $mysqli->query("
            SELECT COUNT(DISTINCT a.id) as count 
            FROM attendance a
            INNER JOIN face_verification_logs f ON a.id = f.attendance_id
            WHERE f.match_score >= 70 AND (f.admin_override = 0 OR f.admin_override IS NULL)
        ");
        if ($verified_sql) {
            $stats['verified'] = $verified_sql->fetch_object()->count ?? 0;
        }
        
        // Overridden
        $overridden_sql = $mysqli->query("
            SELECT COUNT(DISTINCT a.id) as count 
            FROM attendance a
            INNER JOIN face_verification_logs f ON a.id = f.attendance_id
            WHERE f.admin_override = 1
        ");
        if ($overridden_sql) {
            $stats['overridden'] = $overridden_sql->fetch_object()->count ?? 0;
        }
        
        // Unverified (rest)
        $stats['unverified'] = $stats['total'] - $stats['verified'] - $stats['overridden'];
        
        // Attendance status counts
        $present_sql = $mysqli->query("SELECT COUNT(*) as count FROM attendance WHERE status = 'Present'");
        if ($present_sql) {
            $stats['present'] = $present_sql->fetch_object()->count ?? 0;
        }
        
        $absent_sql = $mysqli->query("SELECT COUNT(*) as count FROM attendance WHERE status = 'Absent'");
        if ($absent_sql) {
            $stats['absent'] = $absent_sql->fetch_object()->count ?? 0;
        }
        
        $late_sql = $mysqli->query("SELECT COUNT(*) as count FROM attendance WHERE status = 'Late'");
        if ($late_sql) {
            $stats['late'] = $late_sql->fetch_object()->count ?? 0;
        }
        
        return $stats;
        
    } catch (Exception $e) {
        error_log("Error getting stats: " . $e->getMessage());
        return [
            'total' => 0,
            'verified' => 0,
            'unverified' => 0,
            'overridden' => 0,
            'present' => 0,
            'absent' => 0,
            'late' => 0
        ];
    }
}

/**
 * Get verification details for a specific attendance record
 * 
 * @param mysqli $mysqli Database connection
 */
function getVerificationDetails($mysqli) {
    try {
        $attendance_id = intval($_GET['attendance_id'] ?? 0);
        $teacher_id = intval($_GET['teacher_id'] ?? 0);
        
        if ($attendance_id <= 0 || $teacher_id <= 0) {
            echo json_encode(['success' => false, 'message' => 'Invalid parameters']);
            return;
        }
        
        // Get attendance record with teacher info
        $att_sql = $mysqli->prepare("
            SELECT 
                a.*, 
                t.fullname as teacher_name, 
                t.photo as teacher_photo,
                t.email as teacher_email,
                t.subject as teacher_subject
            FROM attendance a
            INNER JOIN teachers t ON a.teacher_id = t.id
            WHERE a.id = ?
        ");
        
        if (!$att_sql) {
            throw new Exception($mysqli->error);
        }
        
        $att_sql->bind_param("i", $attendance_id);
        $att_sql->execute();
        $attendance = $att_sql->get_result()->fetch_assoc();
        
        if (!$attendance) {
            echo json_encode(['success' => false, 'message' => 'Attendance record not found']);
            return;
        }
        
        // Get face verification log
        $log_sql = $mysqli->prepare("
            SELECT 
                f.*, 
                u.fullname as verified_by_name,
                u.email as verified_by_email
            FROM face_verification_logs f
            LEFT JOIN users u ON f.verified_by = u.id
            WHERE f.attendance_id = ?
        ");
        
        if (!$log_sql) {
            throw new Exception($mysqli->error);
        }
        
        $log_sql->bind_param("i", $attendance_id);
        $log_sql->execute();
        $log = $log_sql->get_result()->fetch_assoc();
        
        // Format times
        $attendance['check_in'] = $attendance['check_in'] ? substr($attendance['check_in'], 0, 5) : null;
        $attendance['check_out'] = $attendance['check_out'] ? substr($attendance['check_out'], 0, 5) : null;
        
        // Build image URLs
        $captured_image_url = !empty($attendance['captured_image']) ? '/' . $attendance['captured_image'] : 'assets/images/no-image.png';
        $teacher_photo_url = !empty($attendance['teacher_photo']) ? '/' . $attendance['teacher_photo'] : 'assets/images/default-avatar.png';
        
        echo json_encode([
            'success' => true,
            'attendance_id' => $attendance_id,
            'teacher_id' => $teacher_id,
            'teacher_name' => $attendance['teacher_name'],
            'teacher_email' => $attendance['teacher_email'],
            'teacher_subject' => $attendance['teacher_subject'],
            'date' => $attendance['date'],
            'check_in' => $attendance['check_in'],
            'check_out' => $attendance['check_out'],
            'attendance_status' => $attendance['status'],
            'captured_image_url' => $captured_image_url,
            'teacher_photo_url' => $teacher_photo_url,
            'match_score' => $log['match_score'] ?? null,
            'admin_override' => $log['admin_override'] ?? 0,
            'admin_notes' => $log['admin_notes'] ?? '',
            'verified_by' => $log['verified_by'] ?? null,
            'verified_by_name' => $log['verified_by_name'] ?? null,
            'verified_by_email' => $log['verified_by_email'] ?? null,
            'verified_at' => $log['created_at'] ?? null
        ]);
        
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => 'Failed to fetch verification details: ' . $e->getMessage()
        ]);
    }
}

/**
 * Override attendance verification (admin only)
 * 
 * @param mysqli $mysqli Database connection
 * @param int $user_id Current admin user ID
 */
function overrideAttendance($mysqli, $user_id) {
    try {
        // Check if user is admin
        $user_check = $mysqli->prepare("SELECT role FROM users WHERE id = ?");
        $user_check->bind_param("i", $user_id);
        $user_check->execute();
        $user = $user_check->get_result()->fetch_assoc();
        
        if (!$user || $user['role'] !== 'admin') {
            echo json_encode(['success' => false, 'message' => 'Admin privileges required']);
            return;
        }
        
        $attendance_id = intval($_POST['attendance_id'] ?? 0);
        $teacher_id = intval($_POST['teacher_id'] ?? 0);
        $confirm_match = isset($_POST['confirm_match']) && $_POST['confirm_match'] == '1';
        $admin_notes = trim($_POST['admin_notes'] ?? '');
        
        if ($attendance_id <= 0 || $teacher_id <= 0) {
            echo json_encode(['success' => false, 'message' => 'Invalid parameters']);
            return;
        }
        
        if (!$confirm_match && empty($admin_notes)) {
            echo json_encode(['success' => false, 'message' => 'Please provide notes when marking as not matching']);
            return;
        }
        
        // Start transaction
        $mysqli->begin_transaction();
        
        // Check if verification log exists
        $check_sql = $mysqli->prepare("SELECT id FROM face_verification_logs WHERE attendance_id = ?");
        $check_sql->bind_param("i", $attendance_id);
        $check_sql->execute();
        $exists = $check_sql->get_result()->num_rows > 0;
        
        $new_attendance_status = null;
        
        if ($exists) {
            // Update existing log
            $update_sql = $mysqli->prepare("
                UPDATE face_verification_logs 
                SET admin_override = ?, 
                    admin_notes = ?, 
                    verified_by = ?,
                    match_score = CASE WHEN ? THEN 100 ELSE match_score END
                WHERE attendance_id = ?
            ");
            
            $admin_override = 1;
            $update_sql->bind_param("isiii", $admin_override, $admin_notes, $user_id, $confirm_match, $attendance_id);
            
            if (!$update_sql->execute()) {
                throw new Exception("Failed to update verification log");
            }
        } else {
            // Insert new log
            $insert_sql = $mysqli->prepare("
                INSERT INTO face_verification_logs (attendance_id, teacher_id, captured_image, match_score, admin_override, admin_notes, verified_by)
                SELECT ?, ?, captured_image, ?, ?, ?, ?
                FROM attendance WHERE id = ?
            ");
            
            $match_score = $confirm_match ? 100 : 0;
            $admin_override = 1;
            $insert_sql->bind_param("iiiiisi", $attendance_id, $teacher_id, $match_score, $admin_override, $admin_notes, $user_id, $attendance_id);
            
            if (!$insert_sql->execute()) {
                throw new Exception("Failed to create verification log");
            }
        }
        
        // Update attendance status based on verification
        if (!$confirm_match) {
            // Mark as absent if faces don't match
            $update_att = $mysqli->prepare("UPDATE attendance SET status = 'Absent' WHERE id = ?");
            $update_att->bind_param("i", $attendance_id);
            if (!$update_att->execute()) {
                throw new Exception("Failed to update attendance status");
            }
            $new_attendance_status = 'Absent';
        } elseif ($confirm_match && $exists) {
            // If confirming match and attendance was marked absent, update to present
            // But preserve 'Late' status if it was late
            $update_att = $mysqli->prepare("
                UPDATE attendance 
                SET status = CASE 
                    WHEN status = 'Absent' THEN 'Present'
                    ELSE status 
                END
                WHERE id = ?
            ");
            $update_att->bind_param("i", $attendance_id);
            if (!$update_att->execute()) {
                throw new Exception("Failed to update attendance status");
            }
            
            // Get current status
            $status_check = $mysqli->prepare("SELECT status FROM attendance WHERE id = ?");
            $status_check->bind_param("i", $attendance_id);
            $status_check->execute();
            $current = $status_check->get_result()->fetch_assoc();
            $new_attendance_status = $current['status'];
        }
        
        // Commit transaction
        $mysqli->commit();
        
        $message = $confirm_match ? 
            'Attendance confirmed as matching. Teacher marked as ' . $new_attendance_status : 
            'Attendance marked as not matching. Teacher marked as absent.';
        
        echo json_encode([
            'success' => true,
            'message' => $message,
            'attendance_status' => $new_attendance_status,
            'verification_status' => 'overridden'
        ]);
        
    } catch (Exception $e) {
        $mysqli->rollback();
        echo json_encode([
            'success' => false,
            'message' => 'Failed to override attendance: ' . $e->getMessage()
        ]);
    }
}

/**
 * Compare two faces and return match score
 * 
 * @param mysqli $mysqli Database connection
 * @param int $user_id Current user ID
 */
function compareFacesAPI($mysqli, $user_id) {
    try {
        if ($_SERVER['REQUEST_METHOD'] != 'POST') {
            echo json_encode(['success' => false, 'message' => 'Invalid request method']);
            return;
        }
        
        $teacher_id = intval($_POST['teacher_id'] ?? 0);
        
        if ($teacher_id <= 0) {
            echo json_encode(['success' => false, 'message' => 'Invalid teacher ID']);
            return;
        }
        
        // Get teacher info
        $teacher_sql = $mysqli->prepare("SELECT id, fullname, photo FROM teachers WHERE id = ?");
        $teacher_sql->bind_param("i", $teacher_id);
        $teacher_sql->execute();
        $teacher = $teacher_sql->get_result()->fetch_assoc();
        
        if (!$teacher) {
            echo json_encode(['success' => false, 'message' => 'Teacher not found']);
            return;
        }
        
        $teacher_photo = $teacher['photo'];
        if (empty($teacher_photo) || $teacher_photo == 'null') {
            echo json_encode(['success' => false, 'message' => 'Teacher has no profile photo']);
            return;
        }
        
        // Check if face image was uploaded
        if (!isset($_FILES['face_image']) || $_FILES['face_image']['error'] != 0) {
            echo json_encode(['success' => false, 'message' => 'No face image provided']);
            return;
        }
        
        $captured_image_tmp = $_FILES['face_image']['tmp_name'];
        $teacher_photo_path = dirname(__DIR__) . '/' . $teacher_photo;
        
        if (!file_exists($teacher_photo_path)) {
            echo json_encode(['success' => false, 'message' => 'Teacher photo not found on server']);
            return;
        }
        
        // Compare faces
        $match_score = compareFaces($captured_image_tmp, $teacher_photo_path);
        
        echo json_encode([
            'success' => true,
            'match_score' => round($match_score, 2),
            'teacher_name' => $teacher['fullname'],
            'teacher_id' => $teacher_id,
            'threshold' => 70,
            'is_match' => $match_score >= 70
        ]);
        
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => 'Face comparison failed: ' . $e->getMessage()
        ]);
    }
}

/**
 * Get statistics only
 * 
 * @param mysqli $mysqli Database connection
 */
function getStats($mysqli) {
    try {
        $stats = getAttendanceStats($mysqli);
        
        // Get today's stats
        $today = date('Y-m-d');
        $today_sql = $mysqli->prepare("
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN status = 'Present' THEN 1 ELSE 0 END) as present,
                SUM(CASE WHEN status = 'Absent' THEN 1 ELSE 0 END) as absent,
                SUM(CASE WHEN status = 'Late' THEN 1 ELSE 0 END) as late
            FROM attendance 
            WHERE date = ?
        ");
        $today_sql->bind_param("s", $today);
        $today_sql->execute();
        $today_stats = $today_sql->get_result()->fetch_assoc();
        
        echo json_encode([
            'success' => true,
            'overall' => $stats,
            'today' => $today_stats,
            'date' => $today
        ]);
        
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => 'Failed to fetch stats: ' . $e->getMessage()
        ]);
    }
}

/**
 * Bulk verify multiple attendance records
 * 
 * @param mysqli $mysqli Database connection
 * @param int $user_id Current admin user ID
 */
function bulkVerify($mysqli, $user_id) {
    try {
        // Check if user is admin
        $user_check = $mysqli->prepare("SELECT role FROM users WHERE id = ?");
        $user_check->bind_param("i", $user_id);
        $user_check->execute();
        $user = $user_check->get_result()->fetch_assoc();
        
        if (!$user || $user['role'] !== 'admin') {
            echo json_encode(['success' => false, 'message' => 'Admin privileges required']);
            return;
        }
        
        $attendance_ids = $_POST['attendance_ids'] ?? [];
        $confirm_match = isset($_POST['confirm_match']) && $_POST['confirm_match'] == '1';
        $admin_notes = trim($_POST['admin_notes'] ?? 'Bulk verification');
        
        if (empty($attendance_ids) || !is_array($attendance_ids)) {
            echo json_encode(['success' => false, 'message' => 'No attendance records selected']);
            return;
        }
        
        $success_count = 0;
        $failed_count = 0;
        
        $mysqli->begin_transaction();
        
        foreach ($attendance_ids as $attendance_id) {
            try {
                // Get teacher_id for this attendance
                $teacher_sql = $mysqli->prepare("SELECT teacher_id FROM attendance WHERE id = ?");
                $teacher_sql->bind_param("i", $attendance_id);
                $teacher_sql->execute();
                $teacher_result = $teacher_sql->get_result();
                $teacher = $teacher_result->fetch_assoc();
                
                if (!$teacher) {
                    $failed_count++;
                    continue;
                }
                
                $teacher_id = $teacher['teacher_id'];
                
                // Check if verification log exists
                $check_sql = $mysqli->prepare("SELECT id FROM face_verification_logs WHERE attendance_id = ?");
                $check_sql->bind_param("i", $attendance_id);
                $check_sql->execute();
                $exists = $check_sql->get_result()->num_rows > 0;
                
                if ($exists) {
                    $update_sql = $mysqli->prepare("
                        UPDATE face_verification_logs 
                        SET admin_override = 1, 
                            admin_notes = CONCAT(admin_notes, ' | Bulk: ', ?), 
                            verified_by = ?,
                            match_score = CASE WHEN ? THEN 100 ELSE match_score END
                        WHERE attendance_id = ?
                    ");
                    $update_sql->bind_param("siii", $admin_notes, $user_id, $confirm_match, $attendance_id);
                    $update_sql->execute();
                } else {
                    $insert_sql = $mysqli->prepare("
                        INSERT INTO face_verification_logs (attendance_id, teacher_id, captured_image, match_score, admin_override, admin_notes, verified_by)
                        SELECT ?, ?, captured_image, ?, 1, ?, ?
                        FROM attendance WHERE id = ?
                    ");
                    $match_score = $confirm_match ? 100 : 0;
                    $insert_sql->bind_param("iiissi", $attendance_id, $teacher_id, $match_score, $admin_notes, $user_id, $attendance_id);
                    $insert_sql->execute();
                }
                
                // Update attendance status
                if (!$confirm_match) {
                    $update_att = $mysqli->prepare("UPDATE attendance SET status = 'Absent' WHERE id = ?");
                    $update_att->bind_param("i", $attendance_id);
                    $update_att->execute();
                }
                
                $success_count++;
                
            } catch (Exception $e) {
                $failed_count++;
                error_log("Bulk verify failed for attendance {$attendance_id}: " . $e->getMessage());
            }
        }
        
        $mysqli->commit();
        
        echo json_encode([
            'success' => true,
            'message' => "Bulk verification completed: {$success_count} successful, {$failed_count} failed",
            'success_count' => $success_count,
            'failed_count' => $failed_count
        ]);
        
    } catch (Exception $e) {
        $mysqli->rollback();
        echo json_encode([
            'success' => false,
            'message' => 'Bulk verification failed: ' . $e->getMessage()
        ]);
    }
}

/**
 * Advanced face comparison function
 * Uses multiple algorithms for better accuracy
 * 
 * @param string $captured_image_path Path to captured face image
 * @param string $stored_image_path Path to stored teacher photo
 * @return float Match score between 0 and 100
 */
function compareFaces($captured_image_path, $stored_image_path) {
    if (!file_exists($captured_image_path) || !file_exists($stored_image_path)) {
        return 0;
    }
    
    try {
        // Method 1: Perceptual hash comparison (40% weight)
        $hash1 = simpleImageHash($captured_image_path);
        $hash2 = simpleImageHash($stored_image_path);
        $hashSimilarity = calculateHashSimilarity($hash1, $hash2);
        
        // Method 2: Histogram comparison (30% weight)
        $histSimilarity = compareHistograms($captured_image_path, $stored_image_path);
        
        // Method 3: Structural similarity (30% weight)
        $structSimilarity = compareStructural($captured_image_path, $stored_image_path);
        
        // Weighted average
        $finalScore = ($hashSimilarity * 0.4) + ($histSimilarity * 0.3) + ($structSimilarity * 0.3);
        
        // Boost score if images are very similar in multiple metrics
        if ($hashSimilarity > 80 && $histSimilarity > 70) {
            $finalScore = min(100, $finalScore * 1.1);
        }
        
        // Penalize if structural similarity is very low
        if ($structSimilarity < 30) {
            $finalScore = $finalScore * 0.7;
        }
        
        return min(100, max(0, $finalScore));
        
    } catch (Exception $e) {
        error_log("Face comparison error: " . $e->getMessage());
        return 0;
    }
}

/**
 * Generate perceptual hash of an image
 * 
 * @param string $image_path Path to image file
 * @return string Hash string
 */
function simpleImageHash($image_path) {
    $img = null;
    
    // Load image based on type
    $image_info = getimagesize($image_path);
    if ($image_info === false) {
        return '';
    }
    
    switch ($image_info['mime']) {
        case 'image/jpeg':
            $img = imagecreatefromjpeg($image_path);
            break;
        case 'image/png':
            $img = imagecreatefrompng($image_path);
            break;
        case 'image/gif':
            $img = imagecreatefromgif($image_path);
            break;
        default:
            return '';
    }
    
    if (!$img) {
        return '';
    }
    
    // Resize to 16x16 for better accuracy
    $resized = imagecreatetruecolor(16, 16);
    imagecopyresampled($resized, $img, 0, 0, 0, 0, 16, 16, imagesx($img), imagesy($img));
    
    // Convert to grayscale
    $pixels = [];
    for ($y = 0; $y < 16; $y++) {
        for ($x = 0; $x < 16; $x++) {
            $rgb = imagecolorat($resized, $x, $y);
            $r = ($rgb >> 16) & 0xFF;
            $g = ($rgb >> 8) & 0xFF;
            $b = $rgb & 0xFF;
            // Use weighted grayscale for better face recognition
            $gray = ($r * 0.299 + $g * 0.587 + $b * 0.114);
            $pixels[] = $gray;
        }
    }
    
    // Calculate average of top-left 8x8 (DCT approximation)
    $avg = array_sum(array_slice($pixels, 0, 64)) / 64;
    
    // Create hash
    $hash = '';
    for ($i = 0; $i < 64; $i++) {
        $hash .= ($pixels[$i] >= $avg) ? '1' : '0';
    }
    
    imagedestroy($img);
    imagedestroy($resized);
    
    return $hash;
}

/**
 * Calculate similarity between two hash strings
 * 
 * @param string $hash1 First hash
 * @param string $hash2 Second hash
 * @return float Similarity percentage
 */
function calculateHashSimilarity($hash1, $hash2) {
    if (strlen($hash1) != strlen($hash2) || strlen($hash1) == 0) {
        return 0;
    }
    
    $differences = 0;
    for ($i = 0; $i < strlen($hash1); $i++) {
        if ($hash1[$i] != $hash2[$i]) {
            $differences++;
        }
    }
    
    return (1 - ($differences / strlen($hash1))) * 100;
}

/**
 * Compare image histograms
 * 
 * @param string $img1_path First image path
 * @param string $img2_path Second image path
 * @return float Similarity percentage
 */
function compareHistograms($img1_path, $img2_path) {
    $img1 = loadImage($img1_path);
    $img2 = loadImage($img2_path);
    
    if (!$img1 || !$img2) {
        if ($img1) imagedestroy($img1);
        if ($img2) imagedestroy($img2);
        return 0;
    }
    
    // Create histograms (16 bins for R,G,B = 48 bins total)
    $hist1 = array_fill(0, 48, 0);
    $hist2 = array_fill(0, 48, 0);
    
    $w1 = imagesx($img1);
    $h1 = imagesy($img1);
    $w2 = imagesx($img2);
    $h2 = imagesy($img2);
    
    // Sample pixels (use step to improve performance)
    $step1 = max(1, floor(($w1 * $h1) / 5000));
    $step2 = max(1, floor(($w2 * $h2) / 5000));
    
    $count1 = 0;
    for ($y = 0; $y < $h1; $y += $step1) {
        for ($x = 0; $x < $w1; $x += $step1) {
            $rgb = imagecolorat($img1, $x, $y);
            $r = ($rgb >> 16) & 0xFF;
            $g = ($rgb >> 8) & 0xFF;
            $b = $rgb & 0xFF;
            
            $hist1[floor($r / 16)]++;
            $hist1[16 + floor($g / 16)]++;
            $hist1[32 + floor($b / 16)]++;
            $count1++;
        }
    }
    
    $count2 = 0;
    for ($y = 0; $y < $h2; $y += $step2) {
        for ($x = 0; $x < $w2; $x += $step2) {
            $rgb = imagecolorat($img2, $x, $y);
            $r = ($rgb >> 16) & 0xFF;
            $g = ($rgb >> 8) & 0xFF;
            $b = $rgb & 0xFF;
            
            $hist2[floor($r / 16)]++;
            $hist2[16 + floor($g / 16)]++;
            $hist2[32 + floor($b / 16)]++;
            $count2++;
        }
    }
    
    // Normalize histograms
    if ($count1 > 0) {
        foreach ($hist1 as $i => $v) {
            $hist1[$i] = $v / $count1;
        }
    }
    if ($count2 > 0) {
        foreach ($hist2 as $i => $v) {
            $hist2[$i] = $v / $count2;
        }
    }
    
    // Calculate intersection (Bhattacharyya coefficient)
    $intersection = 0;
    for ($i = 0; $i < 48; $i++) {
        $intersection += sqrt($hist1[$i] * $hist2[$i]);
    }
    
    imagedestroy($img1);
    imagedestroy($img2);
    
    return $intersection * 100;
}

/**
 * Simplified structural similarity comparison
 * 
 * @param string $img1_path First image path
 * @param string $img2_path Second image path
 * @return float Similarity percentage
 */
function compareStructural($img1_path, $img2_path) {
    $img1 = loadImage($img1_path);
    $img2 = loadImage($img2_path);
    
    if (!$img1 || !$img2) {
        if ($img1) imagedestroy($img1);
        if ($img2) imagedestroy($img2);
        return 0;
    }
    
    // Resize both images to same size for comparison
    $target_w = 100;
    $target_h = 100;
    
    $resized1 = imagecreatetruecolor($target_w, $target_h);
    $resized2 = imagecreatetruecolor($target_w, $target_h);
    
    imagecopyresampled($resized1, $img1, 0, 0, 0, 0, $target_w, $target_h, imagesx($img1), imagesy($img1));
    imagecopyresampled($resized2, $img2, 0, 0, 0, 0, $target_w, $target_h, imagesx($img2), imagesy($img2));
    
    // Calculate mean and variance
    $mean1 = 0;
    $mean2 = 0;
    $pixels1 = [];
    $pixels2 = [];
    
    for ($y = 0; $y < $target_h; $y++) {
        for ($x = 0; $x < $target_w; $x++) {
            $rgb1 = imagecolorat($resized1, $x, $y);
            $r1 = ($rgb1 >> 16) & 0xFF;
            $g1 = ($rgb1 >> 8) & 0xFF;
            $b1 = $rgb1 & 0xFF;
            $gray1 = ($r1 + $g1 + $b1) / 3;
            
            $rgb2 = imagecolorat($resized2, $x, $y);
            $r2 = ($rgb2 >> 16) & 0xFF;
            $g2 = ($rgb2 >> 8) & 0xFF;
            $b2 = $rgb2 & 0xFF;
            $gray2 = ($r2 + $g2 + $b2) / 3;
            
            $pixels1[] = $gray1;
            $pixels2[] = $gray2;
            $mean1 += $gray1;
            $mean2 += $gray2;
        }
    }
    
    $total = $target_w * $target_h;
    $mean1 /= $total;
    $mean2 /= $total;
    
    // Calculate covariance and variance
    $covariance = 0;
    $variance1 = 0;
    $variance2 = 0;
    
    for ($i = 0; $i < $total; $i++) {
        $diff1 = $pixels1[$i] - $mean1;
        $diff2 = $pixels2[$i] - $mean2;
        $covariance += $diff1 * $diff2;
        $variance1 += $diff1 * $diff1;
        $variance2 += $diff2 * $diff2;
    }
    
    $covariance /= $total;
    $variance1 /= $total;
    $variance2 /= $total;
    
    // SSIM constants (using standard values)
    $c1 = 6.5025;  // (0.01 * 255)^2
    $c2 = 58.5225; // (0.03 * 255)^2
    
    $numerator = (2 * $mean1 * $mean2 + $c1) * (2 * $covariance + $c2);
    $denominator = ($mean1 * $mean1 + $mean2 * $mean2 + $c1) * ($variance1 + $variance2 + $c2);
    
    $ssim = $denominator != 0 ? $numerator / $denominator : 0;
    
    imagedestroy($img1);
    imagedestroy($img2);
    imagedestroy($resized1);
    imagedestroy($resized2);
    
    return $ssim * 100;
}

/**
 * Load image from file based on type
 * 
 * @param string $path Image file path
 * @return resource|false Image resource or false on failure
 */
function loadImage($path) {
    if (!file_exists($path)) {
        return false;
    }
    
    $image_info = getimagesize($path);
    if ($image_info === false) {
        return false;
    }
    
    switch ($image_info['mime']) {
        case 'image/jpeg':
            return imagecreatefromjpeg($path);
        case 'image/png':
            return imagecreatefrompng($path);
        case 'image/gif':
            return imagecreatefromgif($path);
        default:
            return false;
    }
}
?>