<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Set content type header first
header('Content-Type: application/json');

// Try to include database file from config folder
$db_path = dirname(__DIR__) . '/config/database.php';
if (!file_exists($db_path)) {
    echo json_encode(['success' => false, 'message' => 'Database file not found at: ' . $db_path]);
    exit();
}

require_once $db_path;

// Check if session is started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check authentication
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'admin') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

// Check if POST request
if ($_SERVER['REQUEST_METHOD'] != 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit();
}

// Get teacher_id
if (!isset($_POST['teacher_id'])) {
    echo json_encode(['success' => false, 'message' => 'Teacher ID required']);
    exit();
}

$teacher_id = intval($_POST['teacher_id']);

// Check database connection
if (!isset($mysqli) || !$mysqli) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed']);
    exit();
}

// Check if teacher has attendance records
$check_stmt = $mysqli->prepare("SELECT COUNT(*) as count FROM attendance WHERE teacher_id = ?");
if (!$check_stmt) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $mysqli->error]);
    exit();
}

$check_stmt->bind_param("i", $teacher_id);
$check_stmt->execute();
$result = $check_stmt->get_result();
$row = $result->fetch_assoc();

if ($row['count'] > 0) {
    echo json_encode(['success' => false, 'message' => 'Cannot delete teacher with attendance records']);
    $check_stmt->close();
    exit();
}
$check_stmt->close();

// Delete teacher
$stmt = $mysqli->prepare("DELETE FROM teachers WHERE id = ?");
if (!$stmt) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $mysqli->error]);
    exit();
}

$stmt->bind_param("i", $teacher_id);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Teacher deleted successfully']);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to delete teacher: ' . $stmt->error]);
}

$stmt->close();
exit();
?>