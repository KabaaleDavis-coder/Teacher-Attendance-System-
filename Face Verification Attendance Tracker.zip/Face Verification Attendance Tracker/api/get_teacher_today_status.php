<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Set content type header first
header('Content-Type: application/json');

// Include database config
$db_path = dirname(__DIR__) . '/config/database.php';
if (!file_exists($db_path)) {
    echo json_encode(['success' => false, 'message' => 'Database file not found']);
    exit();
}

require_once $db_path;

// Start session if not started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check authentication
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

// Get teacher ID
$teacher_id = intval($_GET['teacher_id'] ?? 0);

if ($teacher_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid teacher ID']);
    exit();
}

$today = date('Y-m-d');

// Check attendance for today
$stmt = $mysqli->prepare("SELECT id, check_in, check_out, status FROM attendance WHERE teacher_id = ? AND date = ?");
$stmt->bind_param("is", $teacher_id, $today);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $record = $result->fetch_assoc();
    echo json_encode([
        'success' => true,
        'has_record' => true,
        'check_in' => $record['check_in'],
        'check_out' => $record['check_out'] && $record['check_out'] != '00:00:00' ? $record['check_out'] : null,
        'status' => $record['status']
    ]);
} else {
    echo json_encode([
        'success' => true,
        'has_record' => false,
        'check_in' => null,
        'check_out' => null,
        'status' => null
    ]);
}

$stmt->close();
$mysqli->close();
?>