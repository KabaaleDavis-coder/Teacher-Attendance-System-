<?php
// api/check_email.php - Real-time email availability check
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

if (!isset($_GET['email']) || empty($_GET['email'])) {
    echo json_encode(['available' => false, 'message' => 'Email is required']);
    exit;
}

$email = mysqli_real_escape_string($mysqli, trim($_GET['email']));

// Check if email already exists in users table
$check_stmt = $mysqli->prepare("SELECT id, role FROM users WHERE email = ?");
$check_stmt->bind_param("s", $email);
$check_stmt->execute();
$check_result = $check_stmt->get_result();
$existing_user = $check_result->fetch_assoc();

if ($existing_user) {
    if ($existing_user['role'] == 'admin') {
        echo json_encode(['available' => false, 'message' => 'Email already registered as admin']);
    } else {
        echo json_encode(['available' => false, 'message' => 'Email already exists']);
    }
    exit;
}

// Check for pending verification
$pending_check = $mysqli->prepare("
    SELECT av.*, u.email 
    FROM admin_verifications av 
    JOIN users u ON av.user_id = u.id 
    WHERE u.email = ? AND av.verified_at IS NULL AND av.expires_at > NOW()
");
$pending_check->bind_param("s", $email);
$pending_check->execute();
$pending_result = $pending_check->get_result();

if ($pending_result->num_rows > 0) {
    echo json_encode(['available' => false, 'message' => 'Pending verification exists. Check your email.']);
    exit;
}

echo json_encode(['available' => true, 'message' => 'Email available']);
?>