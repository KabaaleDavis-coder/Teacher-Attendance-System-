<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Set content type header first
header('Content-Type: application/json');

// Include database config
$db_path = dirname(__DIR__) . '/config/database.php';
if (!file_exists($db_path)) {
    echo json_encode(['success' => false, 'message' => 'Database file not found']);
    exit();
}

require_once $db_path;

// Start session if not started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check authentication
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

$today = date('Y-m-d');

// Get present count (teachers with attendance marked today)
$present_sql = $mysqli->prepare("SELECT COUNT(DISTINCT teacher_id) as count FROM attendance WHERE date = ? AND status != 'Absent'");
$present_sql->bind_param("s", $today);
$present_sql->execute();
$present_result = $present_sql->get_result();
$present_count = $present_result->fetch_object()->count ?? 0;

// Get late count
$late_sql = $mysqli->prepare("SELECT COUNT(*) as count FROM attendance WHERE date = ? AND status = 'Late'");
$late_sql->bind_param("s", $today);
$late_sql->execute();
$late_result = $late_sql->get_result();
$late_count = $late_result->fetch_object()->count ?? 0;

// Get checked out count
$checked_out_sql = $mysqli->prepare("SELECT COUNT(*) as count FROM attendance WHERE date = ? AND check_out IS NOT NULL AND check_out != '00:00:00'");
$checked_out_sql->bind_param("s", $today);
$checked_out_sql->execute();
$checked_out_result = $checked_out_sql->get_result();
$checked_out_count = $checked_out_result->fetch_object()->count ?? 0;

// Get total teachers
$total_teachers_sql = $mysqli->prepare("SELECT COUNT(*) as count FROM teachers");
$total_teachers_sql->execute();
$total_result = $total_teachers_sql->get_result();
$total_teachers = $total_result->fetch_object()->count ?? 0;

$absent_count = $total_teachers - $present_count;

$response = [
    'success' => true,
    'present_count' => $present_count,
    'absent_count' => $absent_count,
    'late_count' => $late_count,
    'checked_out_count' => $checked_out_count,
    'total_teachers' => $total_teachers
];

// Include attendance details if requested
if (isset($_GET['details']) && $_GET['details'] == '1') {
    $attendance_sql = $mysqli->prepare("
        SELECT a.id, a.teacher_id, a.date, a.check_in, a.check_out, a.status, a.captured_image, a.created_at,
               t.fullname, t.subject, t.photo
        FROM attendance a
        INNER JOIN teachers t ON a.teacher_id = t.id
        WHERE a.date = ?
        ORDER BY a.created_at DESC
    ");
    $attendance_sql->bind_param("s", $today);
    $attendance_sql->execute();
    $attendance_result = $attendance_sql->get_result();

    $attendance_list = [];
    while ($row = $attendance_result->fetch_assoc()) {
        $attendance_list[] = $row;
    }

    $response['attendance'] = $attendance_list;
}

// Include weekly stats if requested
if (isset($_GET['weekly']) && $_GET['weekly'] == '1') {
    $weekly_sql = $mysqli->prepare("
        SELECT DATE(date) as attendance_date, 
               COUNT(CASE WHEN status != 'Absent' THEN 1 END) as present_count,
               COUNT(CASE WHEN status = 'Absent' THEN 1 END) as absent_count,
               COUNT(CASE WHEN status = 'Late' THEN 1 END) as late_count
        FROM attendance 
        WHERE date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
        GROUP BY DATE(date)
        ORDER BY attendance_date ASC
    ");
    $weekly_sql->execute();
    $weekly_result = $weekly_sql->get_result();
    
    $weekly_data = [];
    while ($row = $weekly_result->fetch_assoc()) {
        $weekly_data[] = $row;
    }
    
    $response['weekly_data'] = $weekly_data;
}

// Close statements
$present_sql->close();
$late_sql->close();
$checked_out_sql->close();
$total_teachers_sql->close();
if (isset($attendance_sql)) $attendance_sql->close();
if (isset($weekly_sql)) $weekly_sql->close();

echo json_encode($response);
?>