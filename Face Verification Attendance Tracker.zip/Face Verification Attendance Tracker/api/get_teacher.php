<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Set content type header first
header('Content-Type: application/json');

// Try to include database file from config folder
$db_path = dirname(__DIR__) . '/config/database.php';
if (!file_exists($db_path)) {
    echo json_encode(['success' => false, 'message' => 'Database file not found at: ' . $db_path]);
    exit();
}

require_once $db_path;

// Check if session is started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check authentication
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'admin') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

// Check if teacher_id is provided
if (!isset($_GET['teacher_id'])) {
    echo json_encode(['success' => false, 'message' => 'Teacher ID required']);
    exit();
}

$teacher_id = intval($_GET['teacher_id']);

// Check database connection
if (!isset($mysqli) || !$mysqli) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed']);
    exit();
}

// Prepare and execute query
$stmt = $mysqli->prepare("SELECT id, fullname, email, phone, subject, photo, created_at FROM teachers WHERE id = ?");
if (!$stmt) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $mysqli->error]);
    exit();
}

$stmt->bind_param("i", $teacher_id);
$stmt->execute();
$result = $stmt->get_result();

if ($teacher = $result->fetch_assoc()) {
    echo json_encode(['success' => true, 'teacher' => $teacher]);
} else {
    echo json_encode(['success' => false, 'message' => 'Teacher not found']);
}

$stmt->close();
exit();
?>