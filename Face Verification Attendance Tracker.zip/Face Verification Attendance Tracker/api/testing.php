<?php
// api/mailer.php - Email helper using PHPMailer
require_once __DIR__ . '/../emailphp/PHPMailer-master/src/Exception.php';
require_once __DIR__ . '/../emailphp/PHPMailer-master/src/PHPMailer.php';
require_once __DIR__ . '/../emailphp/PHPMailer-master/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

/**
 * Send email using PHPMailer with actual SMTP server
 * 
 * @param string $to Recipient email
 * @param string $toName Recipient name
 * @param string $subject Email subject
 * @param string $htmlBody HTML email body
 * @param string $plainBody Plain text email body
 * @return array ['success' => bool, 'message' => string]
 */
function sendEmail($to, $toName, $subject, $htmlBody, $plainBody = '') {
    try {
        $mail = new PHPMailer(true);
        
        // Server settings - Using actual SMTP server
        $mail->SMTPDebug = 0; // Set to 2 for debugging
        $mail->isSMTP();
        $mail->Host = 'altechspheresolns.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'testing@altechspheresolns.com';
        $mail->Password = 'Secret@1234$$';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS; // SSL encryption
        $mail->Port = 465;
        
        // Set timeout values
        $mail->Timeout = 60;
        $mail->SMTPKeepAlive = false;
        
        // Set charset
        $mail->CharSet = 'UTF-8';
        $mail->Encoding = 'base64';
        
        // Sender info - Use the actual email account
        $companyName = 'Teacher Attendance System';
        $companyEmail = 'testing@altechspheresolns.com';
        
        $mail->setFrom($companyEmail, $companyName);
        $mail->addReplyTo($companyEmail, $companyName);
        
        // Add recipient
        $mail->addAddress($to, $toName);
        
        // Content
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->msgHTML($htmlBody);
        
        if (!empty($plainBody)) {
            $mail->AltBody = $plainBody;
        }
        
        $mail->send();
        
        return ['success' => true, 'message' => 'Email sent successfully'];
        
    } catch (Exception $e) {
        error_log("PHPMailer Error: " . $e->getMessage());
        error_log("PHPMailer Error Info: " . ($mail->ErrorInfo ?? 'No error info'));
        return ['success' => false, 'message' => 'Email could not be sent: ' . $e->getMessage()];
    }
}

/**
 * Send verification email for admin registration
 * 
 * @param string $email Recipient email
 * @param string $fullname Recipient name
 * @param string $verificationCode The verification code (id-code format)
 * @param string $systemName System name from settings
 * @param string $sidebarColor Sidebar color for styling
 * @return array ['success' => bool, 'message' => string]
 */
function sendVerificationEmail($email, $fullname, $verificationCode, $systemName = 'Teacher Attendance System', $sidebarColor = '#343a40') {
    $verificationUrl = (isset($_SERVER['HTTPS']) ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'] . '/verify_admin.php?code=' . urlencode($verificationCode);
    
    $htmlBody = "
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset='UTF-8'>
        <style>
            body { 
                font-family: Arial, Helvetica, sans-serif; 
                line-height: 1.5; 
                color: #333; 
                margin: 0;
                padding: 0;
            }
            .container { 
                max-width: 600px; 
                margin: 0 auto; 
                background: #ffffff;
                padding: 20px;
                border: 1px solid #e0e0e0;
                border-radius: 5px;
            }
            .header { 
                background: linear-gradient(135deg, $sidebarColor 0%, " . adjustBrightness($sidebarColor, -20) . " 100%);
                color: white; 
                padding: 30px; 
                text-align: center; 
                border-radius: 5px 5px 0 0;
                margin: -20px -20px 20px -20px;
            }
            .header h2 {
                margin: 0;
                font-size: 24px;
            }
            .content { 
                padding: 20px 0; 
            }
            .code-box {
                background: linear-gradient(135deg, $sidebarColor 0%, " . adjustBrightness($sidebarColor, -20) . " 100%);
                color: white;
                padding: 20px;
                text-align: center;
                border-radius: 5px;
                margin: 20px 0;
            }
            .code-box .code {
                font-size: 32px;
                font-weight: bold;
                letter-spacing: 3px;
                font-family: 'Courier New', monospace;
                background: rgba(255,255,255,0.2);
                padding: 10px 20px;
                border-radius: 5px;
                display: inline-block;
            }
            .button { 
                display: inline-block; 
                padding: 12px 30px; 
                background: $sidebarColor;
                color: white; 
                text-decoration: none; 
                border-radius: 50px; 
                margin: 20px 0; 
                font-weight: 600;
                box-shadow: 0 4px 6px rgba(50, 50, 93, 0.11), 0 1px 3px rgba(0, 0, 0, 0.08);
            }
            .button:hover {
                transform: translateY(-1px);
                box-shadow: 0 7px 14px rgba(50, 50, 93, 0.1), 0 3px 6px rgba(0, 0, 0, 0.08);
            }
            .footer { 
                font-size: 12px; 
                color: #6b7280; 
                text-align: center; 
                margin-top: 30px;
                padding-top: 20px;
                border-top: 1px solid #e0e0e0;
            }
            .warning {
                background: #fff3cd;
                border-left: 4px solid #ffc107;
                padding: 15px;
                margin: 20px 0;
                border-radius: 5px;
                font-size: 13px;
            }
            .details {
                background: #f8f9fa;
                padding: 15px;
                border-radius: 5px;
                margin: 15px 0;
            }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h2>Verify Your Admin Account</h2>
            </div>
            <div class='content'>
                <p>Dear <strong>" . htmlspecialchars($fullname) . "</strong>,</p>
                
                <p>Thank you for registering as an administrator for <strong>" . htmlspecialchars($systemName) . "</strong>.</p>
                
                <div class='details'>
                    <p><strong>Your Verification Code:</strong> <span style='font-size: 20px; font-weight: bold;'>" . htmlspecialchars($verificationCode) . "</span></p>
                    <p><strong>Expires:</strong> " . date('M d, Y H:i', strtotime('+24 hours')) . "</p>
                </div>
                
                <div class='code-box'>
                    <p style='margin-bottom: 10px; opacity: 0.9;'>Click the button below to verify your account:</p>
                    <a href='" . $verificationUrl . "' class='button'>Verify My Account</a>
                </div>
                
                <div class='warning'>
                    <p><strong>⚠️ Important:</strong> This verification code will expire in <strong>24 hours</strong>. If you did not register for an admin account, please ignore this email.</p>
                    <p style='margin-top: 10px;'><strong>Alternative verification:</strong> If the button doesn't work, copy and paste this link into your browser:<br>
                    <a href='" . $verificationUrl . "' style='word-break: break-all;'>" . $verificationUrl . "</a></p>
                    <p style='margin-top: 10px;'><strong>Or enter this code manually:</strong> " . htmlspecialchars($verificationCode) . "</p>
                </div>
                
                <p>After verification, you will be able to:</p>
                <ul>
                    <li>Log in to the Teacher Attendance System dashboard</li>
                    <li>Manage teacher attendance records</li>
                    <li>Generate attendance reports</li>
                    <li>Configure system settings</li>
                </ul>
            </div>
            <div class='footer'>
                <p>" . htmlspecialchars($systemName) . " - Automated Verification Message</p>
                <p>Copyright © " . date('Y') . " " . htmlspecialchars($systemName) . ". All rights reserved.</p>
            </div>
        </div>
    </body>
    </html>
    ";
    
    $plainBody = "Dear " . $fullname . ",\n\n";
    $plainBody .= "Thank you for registering as an administrator for " . $systemName . ".\n\n";
    $plainBody .= "Your Verification Code: " . $verificationCode . "\n";
    $plainBody .= "Expires: " . date('M d, Y H:i', strtotime('+24 hours')) . "\n\n";
    $plainBody .= "Verify your account by clicking this link:\n" . $verificationUrl . "\n\n";
    $plainBody .= "Or enter the code manually at the verification page.\n\n";
    $plainBody .= "This code will expire in 24 hours.\n\n";
    $plainBody .= "If you did not register for an admin account, please ignore this email.\n\n";
    $plainBody .= $systemName . " - Automated Verification Message\n";
    
    return sendEmail($email, $fullname, "Verify Your Admin Account - " . $systemName, $htmlBody, $plainBody);
}

/**
 * Helper function to adjust color brightness
 */
function adjustBrightness($hex, $percent) {
    $hex = ltrim($hex, '#');
    $r = hexdec(substr($hex, 0, 2));
    $g = hexdec(substr($hex, 2, 2));
    $b = hexdec(substr($hex, 4, 2));
    
    $r = max(0, min(255, $r + $percent));
    $g = max(0, min(255, $g + $percent));
    $b = max(0, min(255, $b + $percent));
    
    return sprintf("#%02x%02x%02x", $r, $g, $b);
}
?>