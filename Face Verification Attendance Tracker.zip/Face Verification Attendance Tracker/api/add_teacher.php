<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Set content type header first
header('Content-Type: application/json');

// Try to include database file from config folder
$db_path = dirname(__DIR__) . '/config/database.php';
if (!file_exists($db_path)) {
    echo json_encode(['success' => false, 'message' => 'Database file not found at: ' . $db_path]);
    exit();
}

require_once $db_path;

// Check if session is started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check authentication
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'admin') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

// Check if POST request
if ($_SERVER['REQUEST_METHOD'] != 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit();
}

// Get form data
$fullname = trim($_POST['fullname'] ?? '');
$email = trim($_POST['email'] ?? '');
$phone = trim($_POST['phone'] ?? '');
$subject = trim($_POST['subject'] ?? '');
$photo_base64 = $_POST['photo_base64'] ?? '';

// Validate required fields
if (empty($fullname) || empty($email)) {
    echo json_encode(['success' => false, 'message' => 'Full name and email are required']);
    exit();
}

// Check database connection
if (!isset($mysqli) || !$mysqli) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed']);
    exit();
}

// Check if email already exists
$check_stmt = $mysqli->prepare("SELECT id FROM teachers WHERE email = ?");
if (!$check_stmt) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $mysqli->error]);
    exit();
}

$check_stmt->bind_param("s", $email);
$check_stmt->execute();
$check_result = $check_stmt->get_result();

if ($check_result->num_rows > 0) {
    echo json_encode(['success' => false, 'message' => 'Email already exists']);
    $check_stmt->close();
    exit();
}
$check_stmt->close();

// Handle photo
$photo_path = null;

// Check for file upload
if (isset($_FILES['photo']) && $_FILES['photo']['error'] == 0) {
    $upload_dir = dirname(__DIR__) . '/uploads/teachers/';
    if (!file_exists($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }
    
    $file_extension = strtolower(pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION));
    $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
    
    if (in_array($file_extension, $allowed_extensions)) {
        $filename = time() . '_' . preg_replace('/[^a-zA-Z0-9]/', '_', $fullname) . '.' . $file_extension;
        $target_path = $upload_dir . $filename;
        
        if (move_uploaded_file($_FILES['photo']['tmp_name'], $target_path)) {
            $photo_path = 'uploads/teachers/' . $filename;
        }
    }
}
// Check for base64 image from camera
elseif (!empty($photo_base64)) {
    if (preg_match('/^data:image\/(\w+);base64,/', $photo_base64, $matches)) {
        $image_type = $matches[1];
        $image_data = substr($photo_base64, strpos($photo_base64, ',') + 1);
        $image_data = base64_decode($image_data);
        
        $upload_dir = dirname(__DIR__) . '/uploads/teachers/';
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        
        $filename = time() . '_' . preg_replace('/[^a-zA-Z0-9]/', '_', $fullname) . '.' . $image_type;
        $target_path = $upload_dir . $filename;
        
        if (file_put_contents($target_path, $image_data)) {
            $photo_path = 'uploads/teachers/' . $filename;
        }
    }
}

// Insert teacher
$stmt = $mysqli->prepare("INSERT INTO teachers (fullname, email, phone, subject, photo, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
if (!$stmt) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $mysqli->error]);
    exit();
}

$stmt->bind_param("sssss", $fullname, $email, $phone, $subject, $photo_path);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Teacher added successfully']);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to add teacher: ' . $stmt->error]);
}

$stmt->close();
exit();
?>