<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Teacher Attendance System - Project Manual</title>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Fira+Code:wght@400;500&display=swap');

    * { margin: 0; padding: 0; box-sizing: border-box; }

    :root {
      --primary: #1a56db;
      --primary-dark: #1e429f;
      --secondary: #374151;
      --accent: #0891b2;
      --success: #059669;
      --warning: #d97706;
      --danger: #dc2626;
      --neutral-50: #f9fafb;
      --neutral-100: #f3f4f6;
      --neutral-200: #e5e7eb;
      --neutral-300: #d1d5db;
      --neutral-400: #9ca3af;
      --neutral-500: #6b7280;
      --neutral-600: #4b5563;
      --neutral-700: #374151;
      --neutral-800: #1f2937;
      --neutral-900: #111827;
      --border: #e5e7eb;
    }

    body {
      font-family: 'Inter', sans-serif;
      color: var(--neutral-800);
      background: #fff;
      font-size: 14px;
      line-height: 1.6;
    }

    /* COVER PAGE */
    .cover {
      page-break-after: always;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      background: linear-gradient(160deg, #0f172a 0%, #1e3a5f 50%, #0e4d6a 100%);
      color: white;
      padding: 0;
      position: relative;
      overflow: hidden;
    }

    .cover::before {
      content: '';
      position: absolute;
      top: -80px;
      right: -80px;
      width: 400px;
      height: 400px;
      border-radius: 50%;
      background: rgba(255,255,255,0.04);
    }

    .cover::after {
      content: '';
      position: absolute;
      bottom: -100px;
      left: -60px;
      width: 350px;
      height: 350px;
      border-radius: 50%;
      background: rgba(255,255,255,0.03);
    }

    .cover-top {
      padding: 48px 64px 32px;
      border-bottom: 1px solid rgba(255,255,255,0.1);
    }

    .cover-org {
      font-size: 13px;
      font-weight: 500;
      letter-spacing: 2px;
      text-transform: uppercase;
      color: rgba(255,255,255,0.55);
    }

    .cover-body {
      flex: 1;
      display: flex;
      flex-direction: column;
      justify-content: center;
      padding: 64px;
    }

    .cover-label {
      display: inline-block;
      background: rgba(8,145,178,0.25);
      color: #67e8f9;
      border: 1px solid rgba(8,145,178,0.4);
      font-size: 11px;
      font-weight: 600;
      letter-spacing: 2.5px;
      text-transform: uppercase;
      padding: 5px 14px;
      border-radius: 4px;
      margin-bottom: 28px;
    }

    .cover h1 {
      font-size: 52px;
      font-weight: 700;
      line-height: 1.1;
      margin-bottom: 10px;
      letter-spacing: -1px;
    }

    .cover h1 span {
      color: #38bdf8;
    }

    .cover-sub {
      font-size: 20px;
      font-weight: 300;
      color: rgba(255,255,255,0.65);
      margin-bottom: 48px;
    }

    .cover-divider {
      width: 80px;
      height: 3px;
      background: linear-gradient(90deg, #38bdf8, transparent);
      margin-bottom: 40px;
    }

    .cover-meta {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 32px;
      max-width: 600px;
    }

    .cover-meta-item label {
      font-size: 10px;
      font-weight: 600;
      letter-spacing: 1.5px;
      text-transform: uppercase;
      color: rgba(255,255,255,0.4);
      display: block;
      margin-bottom: 4px;
    }

    .cover-meta-item span {
      font-size: 14px;
      font-weight: 500;
      color: rgba(255,255,255,0.85);
    }

    .cover-bottom {
      padding: 32px 64px;
      border-top: 1px solid rgba(255,255,255,0.08);
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 12px;
      color: rgba(255,255,255,0.35);
    }

    /* MAIN CONTENT */
    .page-wrapper {
      max-width: 900px;
      margin: 0 auto;
      padding: 0 48px;
    }

    /* TOC */
    .toc-page {
      page-break-after: always;
      padding: 72px 0 48px;
    }

    .toc-page h2 {
      font-size: 11px;
      font-weight: 600;
      letter-spacing: 2px;
      text-transform: uppercase;
      color: var(--neutral-400);
      margin-bottom: 40px;
    }

    .toc-list {
      list-style: none;
    }

    .toc-list > li {
      border-bottom: 1px solid var(--neutral-100);
    }

    .toc-list > li > a {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 14px 0;
      text-decoration: none;
      color: var(--neutral-700);
      font-weight: 600;
      font-size: 14px;
      transition: color 0.2s;
    }

    .toc-list > li > a:hover { color: var(--primary); }

    .toc-list > li > a .toc-num {
      font-size: 11px;
      font-weight: 700;
      color: var(--neutral-300);
      margin-right: 14px;
      min-width: 24px;
    }

    .toc-list > li > a .toc-dots {
      flex: 1;
      border-bottom: 1px dotted var(--neutral-200);
      margin: 0 12px;
    }

    .toc-list > li > a .toc-page-num {
      font-size: 12px;
      color: var(--neutral-400);
      font-weight: 500;
    }

    /* SECTION STYLES */
    .section {
      page-break-before: always;
      padding: 72px 0 24px;
    }

    .section-label {
      font-size: 10px;
      font-weight: 700;
      letter-spacing: 2px;
      text-transform: uppercase;
      color: var(--primary);
      margin-bottom: 10px;
    }

    .section > h2 {
      font-size: 32px;
      font-weight: 700;
      color: var(--neutral-900);
      margin-bottom: 6px;
      line-height: 1.2;
    }

    .section-intro {
      font-size: 15px;
      color: var(--neutral-500);
      margin-bottom: 40px;
      max-width: 680px;
      line-height: 1.7;
    }

    h3 {
      font-size: 17px;
      font-weight: 600;
      color: var(--neutral-800);
      margin-top: 36px;
      margin-bottom: 14px;
    }

    h4 {
      font-size: 13px;
      font-weight: 700;
      letter-spacing: 0.5px;
      color: var(--neutral-600);
      text-transform: uppercase;
      margin-top: 24px;
      margin-bottom: 10px;
    }

    p {
      margin-bottom: 14px;
      color: var(--neutral-700);
      line-height: 1.75;
    }

    /* CARDS & BOXES */
    .card {
      background: var(--neutral-50);
      border: 1px solid var(--border);
      border-radius: 10px;
      padding: 24px;
      margin-bottom: 20px;
    }

    .card-blue {
      background: #eff6ff;
      border-color: #bfdbfe;
    }

    .card-green {
      background: #f0fdf4;
      border-color: #bbf7d0;
    }

    .card-amber {
      background: #fffbeb;
      border-color: #fde68a;
    }

    .card-red {
      background: #fef2f2;
      border-color: #fecaca;
    }

    .card-cyan {
      background: #ecfeff;
      border-color: #a5f3fc;
    }

    .info-box {
      display: flex;
      gap: 14px;
      align-items: flex-start;
    }

    .info-box-icon {
      width: 32px;
      height: 32px;
      border-radius: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 15px;
      flex-shrink: 0;
      margin-top: 2px;
    }

    .info-box-icon.blue { background: #dbeafe; }
    .info-box-icon.green { background: #d1fae5; }
    .info-box-icon.amber { background: #fef3c7; }
    .info-box-icon.red { background: #fee2e2; }
    .info-box-icon.cyan { background: #cffafe; }

    /* TABLES */
    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 24px;
      font-size: 13px;
    }

    thead th {
      background: var(--neutral-800);
      color: white;
      padding: 11px 14px;
      text-align: left;
      font-weight: 600;
      font-size: 12px;
      letter-spacing: 0.3px;
    }

    thead th:first-child { border-radius: 6px 0 0 0; }
    thead th:last-child { border-radius: 0 6px 0 0; }

    tbody tr:nth-child(even) { background: var(--neutral-50); }
    tbody tr:hover { background: #eff6ff; }

    tbody td {
      padding: 10px 14px;
      border-bottom: 1px solid var(--neutral-100);
      color: var(--neutral-700);
    }

    /* CODE BLOCKS */
    pre, code {
      font-family: 'Fira Code', monospace;
    }

    pre {
      background: #0f172a;
      color: #e2e8f0;
      padding: 20px 24px;
      border-radius: 8px;
      overflow-x: auto;
      font-size: 12.5px;
      line-height: 1.7;
      margin-bottom: 20px;
    }

    code {
      background: var(--neutral-100);
      color: #be185d;
      padding: 2px 6px;
      border-radius: 4px;
      font-size: 12.5px;
    }

    pre code {
      background: none;
      color: inherit;
      padding: 0;
      font-size: inherit;
    }

    .code-comment { color: #64748b; }
    .code-keyword { color: #93c5fd; }
    .code-string { color: #86efac; }
    .code-value { color: #fca5a5; }
    .code-func { color: #c4b5fd; }

    /* BADGES & TAGS */
    .badge {
      display: inline-block;
      padding: 3px 10px;
      border-radius: 100px;
      font-size: 11px;
      font-weight: 600;
      letter-spacing: 0.3px;
    }

    .badge-blue { background: #dbeafe; color: #1d4ed8; }
    .badge-green { background: #d1fae5; color: #065f46; }
    .badge-amber { background: #fef3c7; color: #92400e; }
    .badge-red { background: #fee2e2; color: #991b1b; }
    .badge-gray { background: var(--neutral-100); color: var(--neutral-600); }
    .badge-cyan { background: #cffafe; color: #0e7490; }

    /* GRID LAYOUTS */
    .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 20px; }
    .grid-3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 16px; margin-bottom: 20px; }

    .stat-card {
      background: white;
      border: 1px solid var(--border);
      border-radius: 10px;
      padding: 20px;
      text-align: center;
    }

    .stat-card .stat-icon {
      font-size: 24px;
      margin-bottom: 8px;
    }

    .stat-card .stat-value {
      font-size: 24px;
      font-weight: 700;
      color: var(--neutral-900);
    }

    .stat-card .stat-label {
      font-size: 12px;
      color: var(--neutral-500);
      margin-top: 2px;
    }

    /* FLOW DIAGRAM */
    .flow {
      display: flex;
      flex-direction: column;
      gap: 0;
      margin: 20px 0;
    }

    .flow-item {
      display: flex;
      align-items: flex-start;
      gap: 16px;
      padding: 0;
    }

    .flow-connector {
      display: flex;
      flex-direction: column;
      align-items: center;
      flex-shrink: 0;
    }

    .flow-dot {
      width: 14px;
      height: 14px;
      border-radius: 50%;
      background: var(--primary);
      border: 2px solid white;
      box-shadow: 0 0 0 2px var(--primary);
      margin-top: 4px;
    }

    .flow-line {
      width: 2px;
      flex: 1;
      min-height: 32px;
      background: var(--neutral-200);
      margin: 4px 0;
    }

    .flow-content {
      background: var(--neutral-50);
      border: 1px solid var(--border);
      border-radius: 8px;
      padding: 12px 16px;
      flex: 1;
      margin-bottom: 4px;
    }

    .flow-content strong {
      display: block;
      font-size: 13px;
      color: var(--neutral-800);
      margin-bottom: 2px;
    }

    .flow-content span {
      font-size: 12px;
      color: var(--neutral-500);
    }

    /* FILE TREE */
    .file-tree {
      background: #0f172a;
      border-radius: 10px;
      padding: 24px;
      font-family: 'Fira Code', monospace;
      font-size: 12.5px;
      color: #94a3b8;
      line-height: 1.9;
      margin-bottom: 20px;
    }

    .file-tree .dir { color: #60a5fa; font-weight: 500; }
    .file-tree .file-php { color: #86efac; }
    .file-tree .file-js { color: #fbbf24; }
    .file-tree .file-css { color: #c4b5fd; }
    .file-tree .file-html { color: #f87171; }
    .file-tree .file-sql { color: #67e8f9; }
    .file-tree .file-other { color: #94a3b8; }
    .file-tree .comment { color: #475569; }

    /* SECURITY ITEMS */
    .security-item {
      display: flex;
      gap: 12px;
      align-items: flex-start;
      padding: 14px;
      border-radius: 8px;
      margin-bottom: 10px;
    }

    .security-item.secure { background: #f0fdf4; border: 1px solid #bbf7d0; }
    .security-item.warning { background: #fffbeb; border: 1px solid #fde68a; }
    .security-item.risk { background: #fef2f2; border: 1px solid #fecaca; }

    .security-item .icon { font-size: 16px; margin-top: 1px; flex-shrink: 0; }
    .security-item .text strong { display: block; font-size: 13px; font-weight: 600; color: var(--neutral-800); }
    .security-item .text span { font-size: 12px; color: var(--neutral-500); }

    /* LIST STYLES */
    ul.styled, ol.styled {
      padding-left: 20px;
      margin-bottom: 16px;
    }

    ul.styled li, ol.styled li {
      padding: 4px 0;
      color: var(--neutral-700);
      line-height: 1.65;
    }

    /* PAGE BREAKS */
    .no-break { page-break-inside: avoid; }

    /* HORIZONTAL RULE */
    .hr { border: none; border-top: 1px solid var(--border); margin: 36px 0; }

    /* PRINT STYLES */
    @media print {
      body { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
      .cover { min-height: 100vh; }
      .page-break { page-break-before: always; }
    }

    /* DOWNLOAD BUTTON (screen only) */
    .download-bar {
      position: fixed;
      bottom: 0;
      left: 0;
      right: 0;
      background: var(--neutral-900);
      color: white;
      padding: 14px 32px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      z-index: 9999;
      font-size: 13px;
    }

    @media print { .download-bar { display: none; } }

    .download-bar button {
      background: var(--primary);
      color: white;
      border: none;
      padding: 9px 22px;
      border-radius: 6px;
      font-size: 13px;
      font-weight: 600;
      cursor: pointer;
      font-family: 'Inter', sans-serif;
      transition: background 0.2s;
    }

    .download-bar button:hover { background: #1e429f; }

    /* HEADER STRIPE on sections */
    .section-stripe {
      height: 4px;
      border-radius: 2px;
      margin-bottom: 40px;
      background: linear-gradient(90deg, var(--primary), var(--accent));
    }

    /* HIGHLIGHT ROW */
    .highlight-row {
      background: #eff6ff !important;
      font-weight: 500;
    }

    .api-method {
      display: inline-block;
      padding: 2px 8px;
      border-radius: 4px;
      font-size: 11px;
      font-weight: 700;
      font-family: 'Fira Code', monospace;
    }
    .method-get { background: #d1fae5; color: #065f46; }
    .method-post { background: #dbeafe; color: #1d4ed8; }

    .endpoint-table td:first-child { font-family: 'Fira Code', monospace; font-size: 12px; color: #be185d; }
  </style>
</head>
<body>

<!-- DOWNLOAD BAR (screen only) -->
<div class="download-bar">
  <span>Teacher Attendance System &mdash; Project Manual v2.0</span>
  <button onclick="window.print()">Download as PDF (Print > Save as PDF)</button>
</div>

<!-- ===================== COVER PAGE ===================== -->
<div class="cover">
  <div class="cover-top">
    <div class="cover-org">Software Project Documentation</div>
  </div>
  <div class="cover-body">
    <div class="cover-label">Project Manual &bull; Rev 2.0</div>
    <h1>Face Verification<br/><span>Attendance Tracker</span></h1>
    <p class="cover-sub">Full-Stack Web Application Documentation</p>
    <div class="cover-divider"></div>
    <div class="cover-meta">
      <div class="cover-meta-item">
        <label>Version</label>
        <span>2.0.0</span>
      </div>
      <div class="cover-meta-item">
        <label>Document Type</label>
        <span>Technical Manual</span>
      </div>
      <div class="cover-meta-item">
        <label>Date</label>
        <span>April 2026</span>
      </div>
    </div>
  </div>
  <div class="cover-bottom">
    <span>Teacher Attendance System &mdash; Confidential Project Documentation</span>
    <span>All rights reserved &copy; 2026</span>
  </div>
</div>

<!-- ===================== TABLE OF CONTENTS ===================== -->
<div class="page-wrapper">
<div class="toc-page">
  <h2>Table of Contents</h2>
  <ul class="toc-list">
    <li><a href="#s1"><span class="toc-num">01</span>Project Overview<span class="toc-dots"></span><span class="toc-page-num">3</span></a></li>
    <li><a href="#s2"><span class="toc-num">02</span>System Architecture<span class="toc-dots"></span><span class="toc-page-num">4</span></a></li>
    <li><a href="#s3"><span class="toc-num">03</span>Technology Stack<span class="toc-dots"></span><span class="toc-page-num">5</span></a></li>
    <li><a href="#s4"><span class="toc-num">04</span>Project File Structure<span class="toc-dots"></span><span class="toc-page-num">6</span></a></li>
    <li><a href="#s5"><span class="toc-num">05</span>Database Design<span class="toc-dots"></span><span class="toc-page-num">7</span></a></li>
    <li><a href="#s6"><span class="toc-num">06</span>Frontend Documentation<span class="toc-dots"></span><span class="toc-page-num">9</span></a></li>
    <li><a href="#s7"><span class="toc-num">07</span>Backend &amp; Face Verification API<span class="toc-dots"></span><span class="toc-page-num">11</span></a></li>
    <li><a href="#s8"><span class="toc-num">08</span>Face Verification Module<span class="toc-dots"></span><span class="toc-page-num">13</span></a></li>
    <li><a href="#s9"><span class="toc-num">09</span>API Reference<span class="toc-dots"></span><span class="toc-page-num">15</span></a></li>
    <li><a href="#s10"><span class="toc-num">10</span>Authentication &amp; Security<span class="toc-dots"></span><span class="toc-page-num">17</span></a></li>
    <li><a href="#s11"><span class="toc-num">11</span>Real-Time System<span class="toc-dots"></span><span class="toc-page-num">19</span></a></li>
    <li><a href="#s12"><span class="toc-num">12</span>Data Flow Diagrams<span class="toc-dots"></span><span class="toc-page-num">20</span></a></li>
    <li><a href="#s13"><span class="toc-num">13</span>Deployment Guide<span class="toc-dots"></span><span class="toc-page-num">22</span></a></li>
    <li><a href="#s14"><span class="toc-num">14</span>Security Audit &amp; Recommendations<span class="toc-dots"></span><span class="toc-page-num">23</span></a></li>
    <li><a href="#s15"><span class="toc-num">15</span>Future Enhancements<span class="toc-dots"></span><span class="toc-page-num">25</span></a></li>
  </ul>
</div>

<!-- ===================== SECTION 1: OVERVIEW ===================== -->
<div class="section" id="s1">
  <div class="section-stripe"></div>
  <div class="section-label">Section 01</div>
  <h2>Project Overview</h2>
  <p class="section-intro">A comprehensive web-based system designed to manage, track, and verify teacher attendance using face recognition and administrative overrides.</p>

  <div class="grid-3">
    <div class="stat-card">
      <div class="stat-icon">&#128104;&#8205;&#127979;</div>
      <div class="stat-value">6</div>
      <div class="stat-label">Database Tables</div>
    </div>
    <div class="stat-card">
      <div class="stat-icon">&#128194;</div>
      <div class="stat-value">8</div>
      <div class="stat-label">REST API Endpoints</div>
    </div>
    <div class="stat-card">
      <div class="stat-icon">&#128200;</div>
      <div class="stat-value">6</div>
      <div class="stat-label">Core Modules</div>
    </div>
  </div>

  <h3>Purpose & Goals</h3>
  <p>The system automates attendance tracking with face-based verification, provides administrators with manual override capabilities, and includes comprehensive reporting features.</p>

  <h3>Key Features</h3>
  <div class="grid-2">
    <div class="card card-blue no-break">
      <div class="info-box">
        <div class="info-box-icon blue">&#128247;</div>
        <div>
          <strong>Camera-Based Check-In</strong>
          <p>WebRTC capture with face recognition hook for identity verification.</p>
        </div>
      </div>
    </div>
    <div class="card card-green no-break">
      <div class="info-box">
        <div class="info-box-icon green">&#128293;</div>
        <div>
          <strong>Live Dashboard + Compare.php</strong>
          <p>Statistics auto-refresh every 15s; face verification page with match scoring and admin overrides.</p>
        </div>
      </div>
    </div>
    <div class="card card-cyan no-break">
      <div class="info-box">
        <div class="info-box-icon cyan">&#128196;</div>
        <div>
          <strong>Monthly Reports</strong>
          <p>Per-teacher attendance rates with visual progress bars.</p>
        </div>
      </div>
    </div>
    <div class="card card-amber no-break">
      <div class="info-box">
        <div class="info-box-icon amber">&#128100;</div>
        <div>
          <strong>Role-Based Access + Override</strong>
          <p>Admins can manually verify/override face recognition mismatches with notes.</p>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- ===================== SECTION 2: ARCHITECTURE ===================== -->
<div class="section" id="s2">
  <div class="section-stripe"></div>
  <div class="section-label">Section 02</div>
  <h2>System Architecture</h2>
  <p class="section-intro">SSR + REST API hybrid architecture with face verification as a core module.</p>

  <h3>Layer Overview</h3>
  <table>
    <thead><tr><th>Layer</th><th>Technology</th><th>Responsibility</th></tr></thead>
    <tbody>
      <tr><td><strong>Presentation</strong></td><td>PHP templates, Bootstrap 5</td><td>Render HTML pages</td></tr>
      <tr><td><strong>Face Verification UI</strong></td><td>compare.php</td><td>Admin verification interface with match scoring</td></tr>
      <tr><td><strong>Application</strong></td><td>PHP 7.x/8.x</td><td>Business logic, authentication, file handling</td></tr>
      <tr><td><strong>Face Verification API</strong></td><td>face_verification_api.php</td><td>All verification operations (get_attendances, override, etc.)</td></tr>
      <tr><td><strong>Data</strong></td><td>MySQL / MariaDB</td><td>Persistent storage with 6 tables</td></tr>
    </tbody>
  </table>
</div>

<!-- ===================== SECTION 3: TECH STACK ===================== -->
<div class="section" id="s3">
  <div class="section-stripe"></div>
  <div class="section-label">Section 03</div>
  <h2>Technology Stack</h2>
  
  <h3>Frontend</h3>
  <table>
    <thead><tr><th>Technology</th><th>Role</th></tr></thead>
    <tbody>
      <tr><td>Vanilla JavaScript (ES6)</td><td>DOM, Fetch API, camera, canvas</td></tr>
      <tr><td>Bootstrap 5</td><td>Responsive layout, UI components</td></tr>
      <tr><td>HTML5 Canvas / WebRTC</td><td>Camera frame capture as image blob</td></tr>
    </tbody>
  </table>

  <h3>Backend</h3>
  <table>
    <thead><tr><th>Technology</th><th>Role</th></tr></thead>
    <tbody>
      <tr><td>PHP 7.4+ / 8.x</td><td>Server-side scripting, API endpoints</td></tr>
      <tr><td>MySQLi Extension</td><td>Prepared statements, transactions</td></tr>
      <tr><td>password_hash()</td><td>bcrypt password hashing</td></tr>
    </tbody>
  </table>
</div>

<!-- ===================== SECTION 4: FILE STRUCTURE ===================== -->
<div class="section" id="s4">
  <div class="section-stripe"></div>
  <div class="section-label">Section 04</div>
  <h2>Project File Structure</h2>
  <div class="file-tree">
<span class="dir">/project</span>
&#9500;&#9472;&#9472; <span class="dir">/api</span>
&#9474;   &#9492;&#9472;&#9472; <span class="file-php">face_verification_api.php</span>     <span class="comment"># All verification operations</span>
&#9500;&#9472;&#9472; <span class="file-php">compare.php</span>                       <span class="comment"># Admin verification interface</span>
&#9500;&#9472;&#9472; <span class="file-php">dashboard.php</span>                     <span class="comment"># Live statistics</span>
&#9500;&#9472;&#9472; <span class="file-php">attendance.php</span>                    <span class="comment"># Webcam check-in</span>
&#9500;&#9472;&#9472; <span class="file-php">teachers.php</span>                      <span class="comment"># Teacher management</span>
&#9500;&#9472;&#9472; <span class="file-php">reports.php</span>                       <span class="comment"># Monthly reports</span>
&#9492;&#9472;&#9472; <span class="dir">/uploads</span>
    &#9500;&#9472;&#9472; <span class="dir">/teachers</span>                     <span class="comment"># Teacher profile photos</span>
    &#9492;&#9472;&#9472; <span class="dir">/attendance</span>                   <span class="comment"># Check-in snapshots</span>
  </div>
</div>

<!-- ===================== SECTION 5: DATABASE DESIGN ===================== -->
<div class="section" id="s5">
  <div class="section-stripe"></div>
  <div class="section-label">Section 05</div>
  <h2>Database Design</h2>
  <p class="section-intro">Six relational tables with foreign key constraints ensure data integrity.</p>

  <h3>Table: attendance</h3>
  <table>
    <thead><tr><th>Column</th><th>Type</th><th>Description</th></tr></thead>
    <tbody>
      <tr><td><code>id</code></td><td>INT PK</td><td>Primary key</td></tr>
      <tr><td><code>teacher_id</code></td><td>INT FK</td><td>References teachers(id) ON DELETE CASCADE</td></tr>
      <tr><td><code>date</code></td><td>DATE</td><td>Attendance date</td></tr>
      <tr><td><code>check_in</code></td><td>TIME</td><td>Check-in time</td></tr>
      <tr><td><code>check_out</code></td><td>TIME</td><td>Check-out time (fully supported in compare.php)</td></tr>
      <tr><td><code>status</code></td><td>VARCHAR(50)</td><td>'Present', 'Late', 'Absent'</td></tr>
      <tr><td><code>captured_image</code></td><td>VARCHAR(255)</td><td>Path to captured face image</td></tr>
    </tbody>
  </table>

  <h3>Table: face_verification_logs</h3>
  <table>
    <thead><tr><th>Column</th><th>Type</th><th>Description</th></tr></thead>
    <tbody>
      <tr><td><code>id</code></td><td>INT PK</td><td class="highlight-row"> Verification record ID</td></tr>
      <tr><td><code>attendance_id</code></td><td>INT FK</td><td>References attendance(id) ON DELETE CASCADE</td></tr>
      <tr><td><code>teacher_id</code></td><td>INT FK</td><td>References teachers(id)</td></tr>
      <tr><td><code>match_score</code></td><td>FLOAT</td><td>Face matching confidence (0-100)</td></tr>
      <tr><td><code>admin_override</code></td><td>TINYINT</td><td>1 if admin manually overrode</td></tr>
      <tr><td><code>admin_notes</code></td><td>TEXT</td><td>Optional notes from admin</td></tr>
      <tr><td><code>verified_by</code></td><td>INT FK</td><td>References users(id) for audit trail</td></tr>
    </tbody>
  </table>

  <h3>Table: admin_verifications</h3>
  <p>Stores email verification codes for admin account creation.</p>
  <table>
    <thead><tr><th>Column</th><th>Type</th><th>Description</th></tr></thead>
    <tbody>
      <tr><td><code>verification_code</code></td><td>VARCHAR(50) UNIQUE</td><td>Temporary code</td></tr>
      <tr><td><code>expires_at</code></td><td>DATETIME</td><td>Code expiration timestamp</td></tr>
    </tbody>
  </table>
</div>

<!-- ===================== SECTION 6: FRONTEND ===================== -->
<div class="section" id="s6">
  <div class="section-stripe"></div>
  <div class="section-label">Section 06</div>
  <h2>Frontend Documentation</h2>
  
  <h3>compare.php &ndash; Face Verification Interface</h3>
  <p>The admin verification page includes:</p>
  <ul class="styled">
    <li><strong>Filtering</strong> &mdash; By verification status (unverified/verified/overridden), attendance status (present/absent/late), teacher, and date.</li>
    <li><strong>Statistics Cards</strong> &mdash; Total records, needs verification, verified, admin overridden.</li>
    <li><strong>Attendance Table</strong> &mdash; Displays <strong>Date, Teacher, Check In, Check Out, Duration, Attendance Status, Match Score, Verification Status, Verified By, Actions.</strong></li>
    <li><strong>Verification Modal</strong> &mdash; Shows captured face vs teacher database photo, match score, current status, admin notes, and override buttons.</li>
  </ul>

  <div class="card card-blue no-break">
    <strong>Check-Out and Duration Features</strong><br>
    The attendance table now includes a <strong>Check Out</strong> column and calculates the <strong>Duration</strong> (e.g., "8h 30m") between check-in and check-out. The verification modal also displays check-out time for reference.
  </div>

  <h3>JavaScript Functions in compare.php</h3>
  <table>
    <thead><tr><th>Function</th><th>Purpose</th></tr></thead>
    <tbody>
      <tr><td><code>loadUnverifiedAttendances()</code></td><td>Fetches attendance records with current filters</tr>
      <tr><td><code>displayAttendanceList()</code></td><td>Renders table with check-out and duration columns</tr>
      <tr><td><code>calculateDuration(checkIn, checkOut)</code></td><td>Computes duration between check-in and check-out times</tr>
      <tr><td><code>openVerificationModal()</code></td><td>Loads verification details into modal</tr>
      <tr><td><code>overrideAttendance(confirmMatch)</code><td>Submits admin verification decision (match/not match)</tr>
    </tbody>
  </table>
</div>

<!-- ===================== SECTION 7: BACKEND & API ===================== -->
<div class="section" id="s7">
  <div class="section-stripe"></div>
  <div class="section-label">Section 07</div>
  <h2>Face Verification API</h2>
  <p class="section-intro">A comprehensive JSON API handling all face verification operations.</p>

  <h3>API Endpoints (face_verification_api.php)</h3>
  <table class="endpoint-table">
    <thead><tr><th>Action</th><th>Method</th><th>Description</th></tr></thead>
    <tbody>
      <tr><td><code>get_teachers</code></td><td><span class="api-method method-get">GET</span></td><td>Returns all teachers for filter dropdown</td></tr>
      <tr><td><code>get_attendances</code></td><td><span class="api-method method-get">GET</span></td><td>Paginated attendance records with filters, includes check_out and duration calculation support</td></tr>
      <tr><td><code>get_verification_details</code></td><td><span class="api-method method-get">GET</span></td><td>Returns captured image, teacher photo, match score, and check_out for modal</td></tr>
      <tr><td><code>override_attendance</code></td><td><span class="api-method method-post">POST</span></td><td>Admin override with notes; updates attendance status based on decision</td></tr>
    </tbody>
  </table>

  <h3>Face Comparison Algorithm</h3>
  <p>The API implements a three-method weighted scoring system:</p>
  <ul class="styled">
    <li><strong>Perceptual Hash (40%)</strong> &mdash; Generates 64-bit hash, calculates Hamming distance.</li>
    <li><strong>Histogram Comparison (30%)</strong> &mdash; 48-bin RGB histogram with Bhattacharyya coefficient.</li>
    <li><strong>Structural Similarity (30%)</strong> &mdash; SSIM index on resized 100x100 images.</li>
  </ul>
  <p>Final score: weighted average, boosted if hash and histogram scores are high, penalized if structural similarity is low.</p>
</div>

<!-- ===================== SECTION 8: FACE VERIFICATION MODULE ===================== -->
<div class="section" id="s8">
  <div class="section-stripe"></div>
  <div class="section-label">Section 08</div>
  <h2>Face Verification Workflow</h2>
  
  <div class="flow">
    <div class="flow-item"><div class="flow-connector"><div class="flow-dot"></div><div class="flow-line"></div></div><div class="flow-content"><strong>Attendance captured</strong><span>When a teacher checks in, captured_image saved and face_verification_logs record created with initial match_score.</span></div></div>
    <div class="flow-item"><div class="flow-connector"><div class="flow-dot"></div><div class="flow-line"></div></div><div class="flow-content"><strong>Admin opens compare.php</strong><span>Filters display unverified records (match_score &lt; 70). Each row shows match score, verification status.</span></div></div>
    <div class="flow-item"><div class="flow-connector"><div class="flow-dot"></div><div class="flow-line"></div></div><div class="flow-content"><strong>Admin verifies</strong><span>Clicks "Verify" button, modal shows side-by-side face comparison with match score.</span></div></div>
    <div class="flow-item"><div class="flow-connector"><div class="flow-dot"></div><div class="flow-line"></div></div><div class="flow-content"><strong>Admin decision</strong><span>Chooses "Confirm Match (Present)" or "Mark as Not Matching (Absent)". Optionally adds notes.</span></div></div>
    <div class="flow-item"><div class="flow-connector"><div class="flow-dot"></div></div><div class="flow-content"><strong>Database updated</strong><span>face_verification_logs updated with admin_override=1, notes, verified_by. Attendance status updated if needed.</span></div></div>
  </div>
</div>

<!-- ===================== SECTION 9: API REFERENCE ===================== -->
<div class="section" id="s9">
  <div class="section-stripe"></div>
  <div class="section-label">Section 09</div>
  <h2>API Reference</h2>
  
  <h3>GET get_attendances (with check_out support)</h3>
  <pre><code><span class="code-comment">// Request</span>
GET api/face_verification_api.php?action=get_attendances&status=unverified&teacher_id=5

<span class="code-comment">// Response includes check_out and calculated duration</span>
{
  "attendances": [{
    "id": 101,
    "check_in": "08:15",
    "check_out": "16:45",
    "duration": "8h 30m",
    "match_score": 65.2,
    "attendance_status": "Present"
  }]
}</code></pre>

  <h3>POST override_attendance</h3>
  <pre><code><span class="code-comment">// Request (multipart/form-data)</span>
action: override_attendance
attendance_id: 101
teacher_id: 5
confirm_match: 1
admin_notes: "Face matches teacher photo. Verified."

<span class="code-comment">// Response</span>
{
  "success": true,
  "message": "Attendance confirmed as matching. Teacher marked as Present",
  "attendance_status": "Present",
  "verification_status": "overridden"
}</code></pre>
</div>

<!-- ===================== SECTION 10: SECURITY ===================== -->
<div class="section" id="s10">
  <div class="section-stripe"></div>
  <div class="section-label">Section 10</div>
  <h2>Authentication &amp; Security</h2>

  <div class="security-item secure">
    <div class="icon">&#10003;</div>
    <div class="text"><strong>Prepared Statements</strong><span>All queries in face_verification_api.php use bind_param() for SQL injection prevention.</span></div>
  </div>
  <div class="security-item secure">
    <div class="icon">&#10003;</div>
    <div class="text"><strong>Role-Based Access</strong><span>override_attendance action checks admin role before allowing changes.</span></div>
  </div>
  <div class="security-item secure">
    <div class="icon">&#10003;</div>
    <div class="text"><strong>Admin Notes Validation</strong><span>Requires notes when marking as not matching, mandatory for audit trail.</span></div>
  </div>
  <div class="security-item warning">
    <div class="icon">&#9651;</div>
    <div class="text"><strong>Face recognition algorithm</strong><span>Uses deterministic algorithms only; no external API calls, but not neural-network accurate.</span></div>
  </div>
</div>

<!-- ===================== SECTION 11: REAL-TIME ===================== -->
<div class="section" id="s11">
  <div class="section-stripe"></div>
  <div class="section-label">Section 11</div>
  <h2>Real-Time System</h2>
  
  <h3>Polling Implementation</h3>
  <ul class="styled">
    <li><strong>dashboard.php</strong> &mdash; Polls every 15 seconds for stats counts.</li>
    <li><strong>compare.php</strong> &mdash; Polls every 30 seconds for updated records (setInterval).</li>
    <li><strong>Manual refresh</strong> &mdash; "Refresh" button and filter changes trigger immediate load.</li>
  </ul>
</div>

<!-- ===================== SECTION 12: DATA FLOWS ===================== -->
<div class="section" id="s12">
  <div class="section-stripe"></div>
  <div class="section-label">Section 12</div>
  <h2>Data Flow Diagrams</h2>
  
  <h3>Face Verification Flow</h3>
  <div class="flow">
    <div class="flow-item"><div class="flow-connector"><div class="flow-dot"></div><div class="flow-line"></div></div><div class="flow-content"><strong>Admin filters records</strong><span>GET request to get_attendances with status=unverified</span></div></div>
    <div class="flow-item"><div class="flow-connector"><div class="flow-dot"></div><div class="flow-line"></div></div><div class="flow-content"><strong>Select record to verify</strong><span>get_verification_details loads images, match_score, check_out</span></div></div>
    <div class="flow-item"><div class="flow-connector"><div class="flow-dot"></div><div class="flow-line"></div></div><div class="flow-content"><strong>Admin submits decision</strong><span>POST override_attendance with confirm_match, notes</span></div></div>
    <div class="flow-item"><div class="flow-connector"><div class="flow-dot"></div></div><div class="flow-content"><strong>Transaction updates</strong><span>face_verification_logs SET admin_override=1, notes, verified_by; attendance status updated if confirm_match=0 sets to 'Absent'</span></div></div>
  </div>
</div>

<!-- ===================== SECTION 13: DEPLOYMENT ===================== -->
<div class="section" id="s13">
  <div class="section-stripe"></div>
  <div class="section-label">Section 13</div>
  <h2>Deployment Guide</h2>
  
  <h3>Requirements</h3>
  <ul class="styled">
    <li>PHP 7.4+ with MySQLi, GD extension (for image hashing/histograms)</li>
    <li>MySQL 5.7+ with InnoDB support for transactions</li>
    <li>Write permissions on <code>/uploads/teachers/</code> and <code>/uploads/attendance/</code></li>
  </ul>

  <h3>Database Initialization</h3>
  <pre><code>mysql -u root -p &lt; database/schema.sql

<span class="code-comment">-- Insert default system settings</span>
INSERT INTO system_settings (id, system_name, sidebar_color) 
VALUES (1, 'Teacher Attendance System', '#2c3e50');</code></pre>

  <div class="card card-amber">
    <strong>Face Directory Permissions</strong><br>
    The face comparison functions require temporary file access. Ensure <code>/tmp</code> is writable for uploaded face images during comparison.
  </div>
</div>

<!-- ===================== SECTION 14: SECURITY AUDIT ===================== -->
<div class="section" id="s14">
  <div class="section-stripe"></div>
  <div class="section-label">Section 14</div>
  <h2>Security Audit &amp; Recommendations</h2>

  <div class="grid-3">
    <div class="stat-card">
      <div class="stat-value text-success">7</div>
      <div class="stat-label">Controls Implemented</div>
    </div>
    <div class="stat-card">
      <div class="stat-value text-warning">2</div>
      <div class="stat-label">Warnings</div>
    </div>
    <div class="stat-card">
      <div class="stat-value text-danger">2</div>
      <div class="stat-label">Critical Risks</div>
    </div>
  </div>

  <h3>Prioritized Recommendations</h3>
  <ul class="styled">
    <li><strong>CSRF Protection &mdash;</strong> Add tokens to POST endpoints.</li>
    <li><strong>Rate Limiting &mdash;</strong> Implement on login and API endpoints.</li>
    <li><strong>Upload Validation &mdash;</strong> Add MIME type checking for face images.</li>
    <li><strong>Session Regeneration &mdash;</strong> Call session_regenerate_id(true) after login.</li>
  </ul>
</div>

<!-- ===================== SECTION 15: FUTURE ENHANCEMENTS ===================== -->
<div class="section" id="s15">
  <div class="section-stripe"></div>
  <div class="section-label">Section 15</div>
  <h2>Future Enhancements</h2>

  <h3>Immediate Priorities</h3>
  <ul class="styled">
    <li><strong>Real Face Recognition &mdash;</strong> Replace deterministic algorithms with face-api.js or AWS Rekognition.</li>
    <li><strong>Bulk Verification &mdash;</strong> Already partially implemented in API, add UI to compare.php for batch operations.</li>
    <li><strong>Check-Out Enforcement &mdash;</strong> Add check-out button to attendance.php; log departure time with face re-verification.</li>
    <li><strong>Email Alerts &mdash;</strong> Notify admin of low match scores requiring verification.</li>
  </ul>

  <div class="card card-cyan no-break">
    <strong>Check-Out Enhancement Roadmap</strong><br>
    - Add "Check Out" button on attendance.php for logged-in teacher.<br>
    - Record check_out timestamp in attendance table.<br>
    - Optionally require face re-verification on check-out for high security.<br>
    - Extend compare.php to show matching verification status for both check-in and check-out events.
  </div>

  <hr class="hr"/>
  <div class="card" style="text-align:center;background:var(--neutral-900);color:white;">
    <p>Teacher Attendance System &mdash; Project Manual v2.0 &mdash; April 2026</p>
    <p style="font-size:12px;">Includes check-out support, face verification logs, and admin override workflow.</p>
  </div>
</div>

</div>

<script>
  document.querySelector('.download-bar button').addEventListener('click', function() {
    window.print();
  });
</script>

</body>
</html>