<?php
session_start();
require_once 'config/database.php';
require_once 'api/mailer.php';

$error = '';
$success = '';
$verificationCode = isset($_GET['code']) ? trim($_GET['code']) : '';

// If code is provided via URL, auto-verify
if (!empty($verificationCode)) {
    try {
        $pdo = Database::getInstance()->getConnection();
        
        // Check if verification code exists and is not expired
        $stmt = $pdo->prepare("
            SELECT av.*, u.fullname, u.email, u.password 
            FROM admin_verifications av 
            JOIN users u ON av.user_id = u.id 
            WHERE av.verification_code = ? AND av.verified_at IS NULL AND av.expires_at > NOW()
        ");
        $stmt->execute([$verificationCode]);
        $verification = $stmt->fetch();
        
        if ($verification) {
            // Mark as verified
            $updateStmt = $pdo->prepare("UPDATE admin_verifications SET verified_at = NOW() WHERE id = ?");
            $updateStmt->execute([$verification['id']]);
            
            // Update user to verified status (you can add a 'verified' column if needed)
            // For now, we'll just mark verification as complete
            
            $success = "Your email has been successfully verified! You can now login to your admin account.";
            
            // Optional: Set session for auto-login
            // $_SESSION['user_id'] = $verification['user_id'];
            // $_SESSION['fullname'] = $verification['fullname'];
            // $_SESSION['role'] = 'admin';
            
        } else {
            $error = "Invalid or expired verification code. Please request a new registration.";
        }
    } catch (Exception $e) {
        $error = "Verification failed: " . $e->getMessage();
    }
}

// Handle manual code submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['verify_code'])) {
    $code = trim($_POST['verification_code']);
    
    if (empty($code)) {
        $error = "Please enter your verification code.";
    } else {
        try {
            $pdo = Database::getInstance()->getConnection();
            
            $stmt = $pdo->prepare("
                SELECT av.*, u.fullname, u.email 
                FROM admin_verifications av 
                JOIN users u ON av.user_id = u.id 
                WHERE av.verification_code = ? AND av.verified_at IS NULL AND av.expires_at > NOW()
            ");
            $stmt->execute([$code]);
            $verification = $stmt->fetch();
            
            if ($verification) {
                $updateStmt = $pdo->prepare("UPDATE admin_verifications SET verified_at = NOW() WHERE id = ?");
                $updateStmt->execute([$verification['id']]);
                $success = "Your email has been successfully verified! You can now login.";
            } else {
                $error = "Invalid or expired verification code. Please request a new registration.";
            }
        } catch (Exception $e) {
            $error = "Verification failed: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify Admin Account - Teacher Attendance System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Inter', sans-serif;
            padding: 1.5rem;
        }
        .verify-card {
            background: white;
            border-radius: 1rem;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            padding: 2rem;
            width: 100%;
            max-width: 450px;
        }
        .success-icon {
            font-size: 4rem;
            color: #28a745;
        }
        .error-icon {
            font-size: 4rem;
            color: #dc3545;
        }
    </style>
</head>
<body>
    <div class="verify-card">
        <div class="text-center mb-4">
            <i class="fas fa-envelope fa-3x text-primary"></i>
            <h2 class="mt-3">Verify Your Account</h2>
            <p class="text-muted">Enter the verification code sent to your email</p>
        </div>
        
        <?php if($success): ?>
        <div class="alert alert-success text-center">
            <i class="fas fa-check-circle fa-2x mb-2"></i>
            <p><?php echo htmlspecialchars($success); ?></p>
            <a href="login.php" class="btn btn-primary mt-2">Go to Login</a>
        </div>
        <?php elseif($error): ?>
        <div class="alert alert-danger text-center">
            <i class="fas fa-exclamation-circle fa-2x mb-2"></i>
            <p><?php echo htmlspecialchars($error); ?></p>
            <a href="register_admin.php" class="btn btn-primary mt-2">Register Again</a>
        </div>
        <?php else: ?>
        <form method="POST" action="">
            <div class="mb-3">
                <label for="verification_code" class="form-label">Verification Code</label>
                <input type="text" class="form-control" id="verification_code" name="verification_code" 
                       placeholder="Enter code (e.g., 1-1234)" required value="<?php echo htmlspecialchars($verificationCode); ?>">
                <div class="form-text">Enter the verification code sent to your email address.</div>
            </div>
            <button type="submit" name="verify_code" class="btn btn-primary w-100 py-2">
                <i class="fas fa-check me-2"></i> Verify Account
            </button>
        </form>
        
        <div class="text-center mt-4">
            <p class="text-muted small">Didn't receive the email? <a href="register_admin.php">Register again</a></p>
        </div>
        <?php endif; ?>
    </div>
</body>
</html>