<?php
// Database Configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'altevtcj_Morgan');
define('DB_PASS', 'Secret@123$$');
define('DB_NAME', 'altevtcj_z_at');

// Create connection
$mysqli = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Check connection
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Set charset to utf8
$mysqli->set_charset("utf8");
?>
