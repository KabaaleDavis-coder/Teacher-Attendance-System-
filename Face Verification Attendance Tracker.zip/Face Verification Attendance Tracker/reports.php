<?php
require_once 'includes/header.php';
requireLogin();

// Define adjustBrightness function if not already defined
if (!function_exists('adjustBrightness')) {
    function adjustBrightness($hex, $percent) {
        $hex = ltrim($hex, '#');
        $r = hexdec(substr($hex, 0, 2));
        $g = hexdec(substr($hex, 2, 2));
        $b = hexdec(substr($hex, 4, 2));
        
        $r = max(0, min(255, $r + $percent));
        $g = max(0, min(255, $g + $percent));
        $b = max(0, min(255, $b + $percent));
        
        return sprintf("#%02x%02x%02x", $r, $g, $b);
    }
}

// Get filter parameters
$filter_type = isset($_GET['filter']) ? mysqli_real_escape_string($mysqli, $_GET['filter']) : 'this_month';
$start_date = isset($_GET['start_date']) ? mysqli_real_escape_string($mysqli, $_GET['start_date']) : '';
$end_date = isset($_GET['end_date']) ? mysqli_real_escape_string($mysqli, $_GET['end_date']) : '';

// Calculate date ranges based on filter type
$today = date('Y-m-d');
$yesterday = date('Y-m-d', strtotime('-1 day'));
$this_week_start = date('Y-m-d', strtotime('monday this week'));
$this_week_end = date('Y-m-d', strtotime('sunday this week'));
$last_week_start = date('Y-m-d', strtotime('monday last week'));
$last_week_end = date('Y-m-d', strtotime('sunday last week'));
$this_month_start = date('Y-m-01');
$this_month_end = date('Y-m-t');
$last_month_start = date('Y-m-01', strtotime('first day of last month'));
$last_month_end = date('Y-m-t', strtotime('last day of last month'));
$this_year_start = date('Y-01-01');
$this_year_end = date('Y-12-31');
$last_year_start = date('Y-01-01', strtotime('-1 year'));
$last_year_end = date('Y-12-31', strtotime('-1 year'));

// Set date range based on filter
switch($filter_type) {
    case 'today':
        $start_date = $today;
        $end_date = $today;
        break;
    case 'yesterday':
        $start_date = $yesterday;
        $end_date = $yesterday;
        break;
    case 'this_week':
        $start_date = $this_week_start;
        $end_date = $this_week_end;
        break;
    case 'last_week':
        $start_date = $last_week_start;
        $end_date = $last_week_end;
        break;
    case 'this_month':
        $start_date = $this_month_start;
        $end_date = $this_month_end;
        break;
    case 'last_month':
        $start_date = $last_month_start;
        $end_date = $last_month_end;
        break;
    case 'this_year':
        $start_date = $this_year_start;
        $end_date = $this_year_end;
        break;
    case 'last_year':
        $start_date = $last_year_start;
        $end_date = $last_year_end;
        break;
    case 'custom':
        if (empty($start_date) || empty($end_date)) {
            $start_date = $this_month_start;
            $end_date = $this_month_end;
            $filter_type = 'this_month';
        }
        break;
    default:
        $start_date = $this_month_start;
        $end_date = $this_month_end;
        $filter_type = 'this_month';
}

// Get date range display text
function getDateRangeDisplay($start, $end, $filter_type) {
    $start_date = new DateTime($start);
    $end_date = new DateTime($end);
    
    $range_texts = [
        'today' => 'Today',
        'yesterday' => 'Yesterday',
        'this_week' => 'This Week',
        'last_week' => 'Last Week',
        'this_month' => 'This Month',
        'last_month' => 'Last Month',
        'this_year' => 'This Year',
        'last_year' => 'Last Year',
        'custom' => $start_date->format('M d, Y') . ' - ' . $end_date->format('M d, Y')
    ];
    
    return $range_texts[$filter_type] ?? $start_date->format('M d, Y') . ' - ' . $end_date->format('M d, Y');
}

// Fetch report data with date range
$report_sql = $mysqli->prepare("
    SELECT 
        t.id,
        t.fullname,
        t.email,
        t.subject,
        t.photo,
        COUNT(DISTINCT CASE WHEN a.status != 'Absent' AND a.date BETWEEN ? AND ? THEN a.date END) as present_days,
        COUNT(DISTINCT CASE WHEN a.status = 'Late' AND a.date BETWEEN ? AND ? THEN a.date END) as late_days,
        COUNT(DISTINCT CASE WHEN a.status = 'Absent' AND a.date BETWEEN ? AND ? THEN a.date END) as absent_days,
        COUNT(DISTINCT a.date) as total_days_recorded
    FROM teachers t
    LEFT JOIN attendance a ON t.id = a.teacher_id AND a.date BETWEEN ? AND ?
    GROUP BY t.id
    ORDER BY present_days DESC, late_days ASC
");

$report_sql->bind_param("ssssssss", $start_date, $end_date, $start_date, $end_date, $start_date, $end_date, $start_date, $end_date);
$report_sql->execute();
$reports = $report_sql->get_result();

// Calculate total working days in date range
$date_diff = (new DateTime($end_date))->diff(new DateTime($start_date))->days + 1;
$total_working_days = $date_diff;

// Calculate overall statistics
$total_teachers = 0;
$total_present = 0;
$total_late = 0;
$total_absent = 0;
$teacher_stats = [];

while($report = $reports->fetch_object()) {
    $total_teachers++;
    $total_present += $report->present_days;
    $total_late += $report->late_days;
    $total_absent += $report->absent_days;
    $teacher_stats[] = $report;
}
$reports->data_seek(0);

$overall_attendance_rate = $total_teachers > 0 && $total_working_days > 0 
    ? round(($total_present / ($total_teachers * $total_working_days)) * 100, 1) 
    : 0;

// Get daily trend data
$trend_sql = $mysqli->prepare("
    SELECT 
        a.date,
        COUNT(DISTINCT a.teacher_id) as present_count,
        COUNT(CASE WHEN a.status = 'Late' THEN 1 END) as late_count
    FROM attendance a
    WHERE a.date BETWEEN ? AND ?
    GROUP BY a.date
    ORDER BY a.date ASC
");
$trend_sql->bind_param("ss", $start_date, $end_date);
$trend_sql->execute();
$trend_data = $trend_sql->get_result();

$trend_dates = [];
$trend_present = [];
$trend_late = [];
while($row = $trend_data->fetch_object()) {
    $trend_dates[] = date('M d', strtotime($row->date));
    $trend_present[] = $row->present_count;
    $trend_late[] = $row->late_count;
}

// AI Insights - Analyze patterns and generate recommendations
function generateAIInsights($total_teachers, $total_working_days, $overall_rate, $teacher_stats, $trend_dates, $trend_present, $total_late) {
    $insights = [];
    
    // Overall performance insight
    if ($overall_rate >= 90) {
        $insights[] = [
            'type' => 'success',
            'icon' => '🏆',
            'title' => 'Excellent Attendance!',
            'message' => "Overall attendance rate is {$overall_rate}%. This is outstanding performance!",
            'recommendation' => 'Maintain this momentum and consider recognizing top performers.'
        ];
    } elseif ($overall_rate >= 75) {
        $insights[] = [
            'type' => 'info',
            'icon' => '📊',
            'title' => 'Good Attendance',
            'message' => "Overall attendance rate is {$overall_rate}%. Above average performance.",
            'recommendation' => 'Continue monitoring and address any emerging patterns.'
        ];
    } elseif ($overall_rate >= 60) {
        $insights[] = [
            'type' => 'warning',
            'icon' => '⚠️',
            'title' => 'Needs Improvement',
            'message' => "Overall attendance rate is {$overall_rate}%. Below target.",
            'recommendation' => 'Review attendance patterns and identify at-risk teachers.'
        ];
    } else {
        $insights[] = [
            'type' => 'danger',
            'icon' => '🔴',
            'title' => 'Critical Alert',
            'message' => "Overall attendance rate is {$overall_rate}%. Significantly below acceptable levels.",
            'recommendation' => 'Immediate intervention required. Schedule meetings with affected teachers.'
        ];
    }
    
    // Top performers
    $top_performers = array_slice($teacher_stats, 0, 3);
    if (!empty($top_performers) && $total_working_days > 0) {
        $top_names = [];
        foreach($top_performers as $teacher) {
            $rate = round(($teacher->present_days / $total_working_days) * 100, 1);
            $top_names[] = $teacher->fullname . " ({$rate}%)";
        }
        $insights[] = [
            'type' => 'success',
            'icon' => '⭐',
            'title' => 'Top Performers',
            'message' => 'Highest attendance rates: ' . implode(', ', $top_names),
            'recommendation' => 'Consider recognizing these teachers for their consistency.'
        ];
    }
    
    // Late arrival analysis
    $avg_late = $total_teachers > 0 ? round(($total_late / $total_teachers), 1) : 0;
    if ($avg_late > 5) {
        $insights[] = [
            'type' => 'warning',
            'icon' => '⏰',
            'title' => 'Late Arrival Pattern',
            'message' => "Average late arrivals: {$avg_late} days per teacher.",
            'recommendation' => 'Consider flexible start times or early bird incentives.'
        ];
    }
    
    // Trend analysis
    if (count($trend_present) >= 7) {
        $recent_avg = array_slice($trend_present, -7);
        $recent_avg_val = array_sum($recent_avg) / count($recent_avg);
        $overall_avg = array_sum($trend_present) / count($trend_present);
        
        if ($recent_avg_val > $overall_avg) {
            $insights[] = [
                'type' => 'success',
                'icon' => '📈',
                'title' => 'Improving Trend',
                'message' => "Attendance has improved by " . round(($recent_avg_val - $overall_avg), 1) . "% in the last 7 days.",
                'recommendation' => 'Continue current strategies that are showing positive results.'
            ];
        } elseif ($recent_avg_val < $overall_avg) {
            $insights[] = [
                'type' => 'danger',
                'icon' => '📉',
                'title' => 'Declining Trend',
                'message' => "Attendance has declined by " . round(($overall_avg - $recent_avg_val), 1) . "% in the last 7 days.",
                'recommendation' => 'Investigate recent changes and address issues promptly.'
            ];
        }
    }
    
    return $insights;
}

$ai_insights = generateAIInsights($total_teachers, $total_working_days, $overall_attendance_rate, $teacher_stats, $trend_dates, $trend_present, $total_late);

$sidebar_color = $settings->sidebar_color ?? '#2c3e50';
?>

<style>
.stat-card {
    background: white;
    border-radius: 20px;
    padding: 1.5rem;
    box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
}
.stat-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 25px rgba(0,0,0,0.1);
}
.stat-card .stat-icon {
    position: absolute;
    right: 1rem;
    top: 50%;
    transform: translateY(-50%);
    font-size: 3rem;
    opacity: 0.2;
}
.insight-card {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    border-radius: 15px;
    padding: 1.5rem;
    margin-bottom: 1rem;
}
.insight-card.success { background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%); }
.insight-card.warning { background: linear-gradient(135deg, #f2994a 0%, #f2c94c 100%); }
.insight-card.danger { background: linear-gradient(135deg, #eb3349 0%, #f45c43 100%); }
.insight-card.info { background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); }
.chart-card {
    background: white;
    border-radius: 20px;
    padding: 1.5rem;
    box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    margin-bottom: 1.5rem;
}
.filter-badge {
    padding: 8px 16px;
    border-radius: 20px;
    background: #f8f9fa;
    cursor: pointer;
    transition: all 0.3s;
    display: inline-block;
    margin: 5px;
    text-decoration: none;
    color: #333;
}
.filter-badge:hover {
    background: <?php echo $sidebar_color; ?>;
    color: white;
}
.filter-badge.active {
    background: <?php echo $sidebar_color; ?>;
    color: white;
}
.welcome-banner {
    background: linear-gradient(135deg, <?php echo $sidebar_color; ?> 0%, <?php echo adjustBrightness($sidebar_color, 40); ?> 100%);
    color: white;
    padding: 25px;
    border-radius: 15px;
    margin-bottom: 25px;
}
.attendance-table {
    background: white;
    border-radius: 15px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    overflow: hidden;
}
.table-header {
    padding: 15px 20px;
    border-bottom: 1px solid #e9ecef;
    background: white;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 10px;
}
.status-badge {
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 500;
    display: inline-block;
}
.status-badge.present { background: #d4edda; color: #155724; }
.status-badge.late { background: #fff3cd; color: #856404; }
.status-badge.absent { background: #f8d7da; color: #721c24; }
.teacher-avatar {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    object-fit: cover;
}
.fade-in-up {
    animation: fadeInUp 0.5s ease-out;
}
@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}
.search-box {
    position: relative;
    width: 250px;
}
.search-box i {
    position: absolute;
    left: 10px;
    top: 50%;
    transform: translateY(-50%);
    color: #6c757d;
    z-index: 1;
}
.search-box input {
    padding-left: 35px;
}
@media print {
    .no-print, .filter-badge, .btn, .search-box, .sidebar-toggle, .sidebar, .overlay {
        display: none !important;
    }
    .main-content, .col-md-9, .col-lg-10 {
        width: 100% !important;
        margin-left: 0 !important;
        padding: 0 !important;
    }
    .stat-card, .insight-card, .chart-card, .attendance-table {
        break-inside: avoid;
        page-break-inside: avoid;
    }
}
</style>

<div class="p-4" id="report-content">
    <div class="welcome-banner fade-in-up">
        <div class="row align-items-center">
            <div class="col-md-8">
                <h1>Attendance Reports & Analytics</h1>
                <p>Business intelligence dashboard with AI-powered insights</p>
            </div>
            <div class="col-md-4 text-md-end no-print">
                <button class="btn btn-light me-2" onclick="exportToPDF(event)">
                    <i class="bi bi-file-pdf me-2"></i> Export PDF
                </button>
                <button class="btn btn-light" onclick="window.print()">
                    <i class="bi bi-printer me-2"></i> Print
                </button>
            </div>
        </div>
    </div>

    <!-- Quick Filter Buttons -->
    <div class="row mb-4 no-print">
        <div class="col-12">
            <div class="attendance-table fade-in-up">
                <div class="table-header">
                    <h5 class="mb-0"><i class="bi bi-funnel me-2"></i> Time Period Filters</h5>
                </div>
                <div class="p-3">
                    <div class="d-flex flex-wrap">
                        <a href="?filter=today" class="filter-badge <?php echo $filter_type == 'today' ? 'active' : ''; ?>">Today</a>
                        <a href="?filter=yesterday" class="filter-badge <?php echo $filter_type == 'yesterday' ? 'active' : ''; ?>">Yesterday</a>
                        <a href="?filter=this_week" class="filter-badge <?php echo $filter_type == 'this_week' ? 'active' : ''; ?>">This Week</a>
                        <a href="?filter=last_week" class="filter-badge <?php echo $filter_type == 'last_week' ? 'active' : ''; ?>">Last Week</a>
                        <a href="?filter=this_month" class="filter-badge <?php echo $filter_type == 'this_month' ? 'active' : ''; ?>">This Month</a>
                        <a href="?filter=last_month" class="filter-badge <?php echo $filter_type == 'last_month' ? 'active' : ''; ?>">Last Month</a>
                        <a href="?filter=this_year" class="filter-badge <?php echo $filter_type == 'this_year' ? 'active' : ''; ?>">This Year</a>
                        <a href="?filter=last_year" class="filter-badge <?php echo $filter_type == 'last_year' ? 'active' : ''; ?>">Last Year</a>
                    </div>
                    
                    <!-- Custom Date Range Picker -->
                    <form method="GET" class="mt-3">
                        <input type="hidden" name="filter" value="custom">
                        <div class="row g-3">
                            <div class="col-md-4">
                                <label class="form-label">From Date</label>
                                <input type="date" class="form-control" name="start_date" value="<?php echo $start_date; ?>">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">To Date</label>
                                <input type="date" class="form-control" name="end_date" value="<?php echo $end_date; ?>">
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">&nbsp;</label>
                                <button type="submit" class="btn btn-primary w-100">Apply Range</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="row mb-4">
        <div class="col-md-3 mb-3">
            <div class="stat-card fade-in-up">
                <div class="stat-icon"><i class="bi bi-calendar-range"></i></div>
                <div class="stat-title">Selected Period</div>
                <div class="stat-value h5"><?php echo getDateRangeDisplay($start_date, $end_date, $filter_type); ?></div>
                <div class="stat-trend mt-2"><?php echo $total_working_days; ?> days</div>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="stat-card fade-in-up">
                <div class="stat-icon"><i class="bi bi-person-check"></i></div>
                <div class="stat-title">Overall Attendance Rate</div>
                <div class="stat-value h2"><?php echo $overall_attendance_rate; ?>%</div>
                <div class="stat-trend mt-2"><?php echo $total_present; ?> / <?php echo $total_teachers * $total_working_days; ?> days</div>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="stat-card fade-in-up">
                <div class="stat-icon"><i class="bi bi-clock"></i></div>
                <div class="stat-title">Total Late Arrivals</div>
                <div class="stat-value h2"><?php echo $total_late; ?></div>
                <div class="stat-trend mt-2">Across all teachers</div>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="stat-card fade-in-up">
                <div class="stat-icon"><i class="bi bi-person-x"></i></div>
                <div class="stat-title">Total Absences</div>
                <div class="stat-value h2"><?php echo $total_absent; ?></div>
                <div class="stat-trend mt-2">Unmarked attendance</div>
            </div>
        </div>
    </div>

    <!-- AI Insights Section -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="attendance-table fade-in-up">
                <div class="table-header">
                    <h5 class="mb-0"><i class="bi bi-robot me-2"></i> AI-Powered Insights</h5>
                    <span class="badge bg-primary">Powered by Analytics</span>
                </div>
                <div class="p-3">
                    <div class="row">
                        <?php foreach($ai_insights as $insight): ?>
                        <div class="col-md-6 mb-3">
                            <div class="insight-card <?php echo $insight['type']; ?>">
                                <div class="d-flex align-items-start">
                                    <div class="fs-1 me-3"><?php echo $insight['icon']; ?></div>
                                    <div>
                                        <h6 class="mb-1"><?php echo $insight['title']; ?></h6>
                                        <p class="mb-2 small"><?php echo $insight['message']; ?></p>
                                        <small><i class="bi bi-lightbulb"></i> <?php echo $insight['recommendation']; ?></small>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Trend Chart -->
    <?php if(count($trend_dates) > 0): ?>
    <div class="row mb-4">
        <div class="col-12">
            <div class="chart-card fade-in-up">
                <h5 class="mb-3"><i class="bi bi-graph-up"></i> Attendance Trend</h5>
                <canvas id="trendChart" style="height: 300px; width: 100%;"></canvas>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Detailed Teacher Report -->
    <div class="attendance-table fade-in-up">
        <div class="table-header">
            <h5 class="mb-0"><i class="bi bi-table me-2"></i> Teacher Performance Report</h5>
            <div class="search-box no-print">
                <i class="bi bi-search"></i>
                <input type="text" id="searchTeacher" class="form-control form-control-sm" placeholder="Search teacher...">
            </div>
        </div>
        <div class="table-responsive p-3">
            <table class="table table-hover mb-0" id="reportTable">
                <thead>
                    <tr>
                        <th>Teacher</th>
                        <th>Subject</th>
                        <th>Present Days</th>
                        <th>Late Days</th>
                        <th>Absent Days</th>
                        <th>Attendance Rate</th>
                        <th>Performance</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $reports->data_seek(0);
                    if($total_teachers > 0):
                    while($report = $reports->fetch_object()): 
                        $attendance_rate = $total_working_days > 0 ? round(($report->present_days / $total_working_days) * 100, 1) : 0;
                        $rate_color = $attendance_rate >= 90 ? 'success' : ($attendance_rate >= 75 ? 'info' : ($attendance_rate >= 60 ? 'warning' : 'danger'));
                    ?>
                    <tr>
                        <td>
                            <div class="d-flex align-items-center">
                                <?php if($report->photo && file_exists($report->photo)): ?>
                                <img src="<?php echo htmlspecialchars($report->photo); ?>" class="teacher-avatar me-2" alt="">
                                <?php else: ?>
                                <div class="teacher-avatar bg-secondary text-white d-flex align-items-center justify-content-center me-2">
                                    <i class="bi bi-person"></i>
                                </div>
                                <?php endif; ?>
                                <div>
                                    <span class="fw-semibold"><?php echo htmlspecialchars($report->fullname); ?></span>
                                    <small class="d-block text-muted"><?php echo htmlspecialchars($report->email); ?></small>
                                </div>
                            </div>
                        </td>
                        <td><?php echo htmlspecialchars($report->subject ?? 'N/A'); ?></td>
                        <td><span class="status-badge present"><?php echo $report->present_days; ?></span></td>
                        <td><span class="status-badge late"><?php echo $report->late_days; ?></span></td>
                        <td><span class="status-badge absent"><?php echo $report->absent_days; ?></span></td>
                        <td>
                            <div class="progress" style="height: 25px;">
                                <div class="progress-bar bg-<?php echo $rate_color; ?>" 
                                     style="width: <?php echo $attendance_rate; ?>%">
                                    <?php echo $attendance_rate; ?>%
                                </div>
                            </div>
                        </td>
                        <td>
                            <?php if($attendance_rate >= 90): ?>
                            <i class="bi bi-star-fill text-warning"></i> Excellent
                            <?php elseif($attendance_rate >= 75): ?>
                            <i class="bi bi-check-circle-fill text-success"></i> Good
                            <?php elseif($attendance_rate >= 60): ?>
                            <i class="bi bi-exclamation-triangle-fill text-warning"></i> Needs Improvement
                            <?php else: ?>
                            <i class="bi bi-x-circle-fill text-danger"></i> Critical
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                    <?php else: ?>
                    <tr>
                        <td colspan="7" class="text-center py-5">
                            <i class="bi bi-inbox" style="font-size: 48px; color: #ccc;"></i>
                            <p class="mt-3 text-muted">No attendance records found for this period.</p>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Include html2pdf library -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>

<script>
// Search functionality
const searchInput = document.getElementById('searchTeacher');
if(searchInput) {
    searchInput.addEventListener('keyup', function() {
        let searchValue = this.value.toLowerCase();
        let rows = document.querySelectorAll('#reportTable tbody tr');
        
        rows.forEach(row => {
            let text = row.textContent.toLowerCase();
            if(text.includes(searchValue)) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    });
}

// Trend Chart
<?php if(count($trend_dates) > 0): ?>
const trendCtx = document.getElementById('trendChart')?.getContext('2d');
if(trendCtx) {
    new Chart(trendCtx, {
        type: 'line',
        data: {
            labels: <?php echo json_encode($trend_dates); ?>,
            datasets: [
                {
                    label: 'Present Teachers',
                    data: <?php echo json_encode($trend_present); ?>,
                    borderColor: '#28a745',
                    backgroundColor: 'rgba(40, 167, 69, 0.1)',
                    tension: 0.4,
                    fill: true
                },
                {
                    label: 'Late Arrivals',
                    data: <?php echo json_encode($trend_late); ?>,
                    borderColor: '#ffc107',
                    backgroundColor: 'rgba(255, 193, 7, 0.1)',
                    tension: 0.4,
                    fill: true
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: { position: 'top' },
                tooltip: { mode: 'index', intersect: false }
            },
            scales: {
                y: { 
                    beginAtZero: true, 
                    title: { display: true, text: 'Number of Teachers' },
                    ticks: { stepSize: 1 }
                }
            }
        }
    });
}
<?php endif; ?>

// PDF Export Function
function exportToPDF(event) {
    const element = document.getElementById('report-content');
    const btn = event.target.closest('button');
    const originalText = btn.innerHTML;
    
    const opt = {
        margin:        [0.5, 0.5, 0.5, 0.5],
        filename:     'attendance_report_<?php echo date('Y-m-d'); ?>.pdf',
        image:        { type: 'jpeg', quality: 0.98 },
        html2canvas:  { scale: 2, letterRendering: true },
        jsPDF:        { unit: 'in', format: 'a4', orientation: 'portrait' }
    };
    
    btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Generating PDF...';
    btn.disabled = true;
    
    html2pdf().set(opt).from(element).save()
        .then(() => {
            btn.innerHTML = originalText;
            btn.disabled = false;
        })
        .catch(err => {
            console.error('PDF generation error:', err);
            btn.innerHTML = originalText;
            btn.disabled = false;
            alert('Error generating PDF. Please try again.');
        });
}
</script>

<?php require_once 'includes/footer.php'; ?>