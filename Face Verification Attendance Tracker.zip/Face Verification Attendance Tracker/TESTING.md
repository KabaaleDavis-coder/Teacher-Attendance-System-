# Teacher Attendance System - Testing Guide

## Prerequisites

1. XAMPP/WAMP/LAMP server running
2. Apache with mod_rewrite enabled
3. PHP 7.4 or higher
4. MySQL database

## Setup Instructions

### 1. Database Setup

```bash
# Create the database and tables
mysql -u root -p < database/schema.sql
```

Or manually:
1. Open phpMyAdmin
2. Create a new database named `teacher_attendance`
3. Import `database/schema.sql`

### 2. Configure Database Connection

Check `config/database.php` for correct credentials:
- Host: localhost
- User: root
- Password: (your MySQL password)
- Database: teacher_attendance

### 3. Create Required Directories

```bash
mkdir -p uploads/teachers
mkdir -p uploads/attendance
chmod -R 777 uploads
```

## Testing Checklist

### Phase 1: Database Connection
- [ ] Database created successfully
- [ ] All tables created (users, teachers, attendance, reports, system_settings)
- [ ] System settings initialized with default values

### Phase 2: User Authentication

#### Registration Testing
1. Navigate to `register_admin.php`
2. Test cases:
   - [ ] Register with valid data
   - [ ] Try registering with existing email (should fail)
   - [ ] Try mismatched passwords (should fail)
   - [ ] Try empty fields (should fail)

#### Login Testing
1. Navigate to `login.php`
2. Test cases:
   - [ ] Login with correct credentials
   - [ ] Login with incorrect password (should fail)
   - [ ] Login with non-existent email (should fail)
   - [ ] Try accessing dashboard without login (should redirect to login)

### Phase 3: Dashboard Access
- [ ] Dashboard displays correctly after login
- [ ] Statistics cards show correct counts (0 initially)
- [ ] Sidebar navigation is visible
- [ ] User session is maintained

### Phase 4: Teacher Management (Admin Only)

#### Add Teacher
1. Navigate to `teachers.php`
2. Click "Add Teacher" button
3. Test cases:
   - [ ] Add teacher with all fields
   - [ ] Add teacher without photo
   - [ ] Try adding duplicate email (should fail)
   - [ ] Upload different image formats (jpg, png, gif)

#### View Teachers
- [ ] Teachers list displays correctly
- [ ] Photos display properly
- [ ] All teacher information is visible

#### Delete Teacher
- [ ] Delete button works
- [ ] Confirmation prompt appears
- [ ] Teacher is removed from database
- [ ] Associated attendance records are handled

### Phase 5: Attendance System

#### Mark Attendance
1. Navigate to `attendance.php`
2. Test camera functionality:
   - [ ] Camera permission is requested
   - [ ] Video feed displays correctly
   - [ ] Capture button works

3. Test attendance marking:
   - [ ] Select teacher from dropdown
   - [ ] Capture and mark attendance
   - [ ] Check status (Present/Late based on time)
   - [ ] Try marking duplicate attendance (should fail)
   - [ ] Verify attendance appears in today's list

#### Real-time Updates
- [ ] Dashboard statistics update automatically
- [ ] Today's attendance list refreshes
- [ ] Counts are accurate

### Phase 6: Reports

1. Navigate to `reports.php`
2. Test cases:
   - [ ] Select current month and view report
   - [ ] Select previous month
   - [ ] Verify attendance rate calculations
   - [ ] Check present/late/absent counts
   - [ ] Verify report displays all teachers

### Phase 7: Settings (Admin Only)

1. Navigate to `settings.php`
2. Test cases:
   - [ ] Change system name
   - [ ] Change sidebar color
   - [ ] Change font family
   - [ ] Change font size
   - [ ] Verify changes apply immediately

### Phase 8: Security Testing

#### Access Control
- [ ] Non-admin users cannot access teacher management
- [ ] Non-admin users cannot access settings
- [ ] Logged-out users are redirected to login
- [ ] API endpoints check authentication

#### File Upload Security
- [ ] Only image files can be uploaded
- [ ] File size limits are enforced
- [ ] Uploaded files are stored securely
- [ ] PHP files cannot be uploaded as images

#### SQL Injection Prevention
- [ ] Test login with SQL injection attempts
- [ ] Test teacher search with SQL injection
- [ ] Verify prepared statements are used

### Phase 9: .htaccess Testing

- [ ] URL rewriting works correctly
- [ ] Direct access to config files is blocked
- [ ] Directory listing is disabled
- [ ] Static file caching works
- [ ] Compression is enabled

## Common Issues and Solutions

### Issue: Camera not working
**Solution:** Ensure HTTPS is enabled or test on localhost

### Issue: Images not uploading
**Solution:** Check uploads directory permissions (chmod 777)

### Issue: Database connection failed
**Solution:** Verify credentials in config/database.php

### Issue: Attendance not marking
**Solution:** Check that teacher exists and no duplicate for today

### Issue: .htaccess not working
**Solution:** Enable mod_rewrite in Apache:
```bash
sudo a2enmod rewrite
sudo service apache2 restart
```

## Performance Testing

1. Add multiple teachers (10+)
2. Mark attendance for all teachers
3. Generate reports for multiple months
4. Check page load times
5. Test with multiple concurrent users

## Browser Compatibility

Test in:
- [ ] Chrome
- [ ] Firefox
- [ ] Safari
- [ ] Edge

## Mobile Responsiveness

- [ ] Layout adapts to mobile screens
- [ ] Camera works on mobile devices
- [ ] Touch interactions work properly
- [ ] Forms are usable on mobile

## Final Checks

- [ ] All forms validate input
- [ ] Error messages are clear
- [ ] Success messages display correctly
- [ ] Logout works properly
- [ ] Session management is secure
- [ ] No console errors
- [ ] No PHP warnings/errors

## Test Data

### Sample Admin Account
- Email: admin@test.com
- Password: admin123

### Sample Teacher Data
- Name: John Doe
- Email: john@test.com
- Phone: 1234567890
- Subject: Mathematics

## Automation Testing (Optional)

Consider using:
- PHPUnit for unit tests
- Selenium for browser automation
- Postman for API testing
