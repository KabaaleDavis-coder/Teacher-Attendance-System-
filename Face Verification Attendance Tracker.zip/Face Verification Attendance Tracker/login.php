<?php
session_start();
require_once 'config/database.php';
require_once 'api/mailer.php';

if(isset($_SESSION['user_id'])){
    header("Location: dashboard.php");
    exit();
}

$error = '';
$success = '';
$show_verification = false;
$unverified_email = '';
$unverified_user_id = '';

// Handle resend verification code
if(isset($_POST['resend_code'])){
    $email = mysqli_real_escape_string($mysqli, $_POST['email']);
    
    // Check if user exists and is unverified
    $check_stmt = $mysqli->prepare("
        SELECT u.id, u.fullname, u.email, u.role, av.verified_at 
        FROM users u 
        LEFT JOIN admin_verifications av ON u.id = av.user_id 
        WHERE u.email = ? AND u.role = 'admin'
    ");
    $check_stmt->bind_param("s", $email);
    $check_stmt->execute();
    $result = $check_stmt->get_result();
    $user = $result->fetch_assoc();
    
    if($user && !$user['verified_at']){
        // Generate new verification code
        $randomCode = str_pad(mt_rand(1, 9999), 4, '0', STR_PAD_LEFT);
        $verificationCode = $user['id'] . '-' . $randomCode;
        $expiresAt = date('Y-m-d H:i:s', strtotime('+24 hours'));
        
        // Update or insert verification record
        $update_stmt = $mysqli->prepare("
            UPDATE admin_verifications 
            SET verification_code = ?, expires_at = ?, verified_at = NULL 
            WHERE user_id = ?
        ");
        $update_stmt->bind_param("ssi", $verificationCode, $expiresAt, $user['id']);
        
        if($update_stmt->execute() && $update_stmt->affected_rows > 0){
            // Send new verification email
            $settings_sql = $mysqli->prepare("SELECT * FROM system_settings LIMIT 1");
            $settings_sql->execute();
            $settings_result = $settings_sql->get_result();
            $settings = $settings_result->fetch_object();
            $system_name = $settings->system_name ?? 'Teacher Attendance System';
            $sidebar_color = $settings->sidebar_color ?? '#343a40';
            
            $emailResult = sendVerificationEmail($user['email'], $user['fullname'], $verificationCode, $system_name, $sidebar_color);
            
            if($emailResult['success']){
                $success = "A new verification code has been sent to <strong>" . htmlspecialchars($user['email']) . "</strong>. Please check your email.";
                $show_verification = true;
                $unverified_email = $user['email'];
                $unverified_user_id = $user['id'];
            } else {
                $error = "Failed to send verification email. Please try again later.";
            }
        } else {
            // Insert new verification record if update didn't work
            $insert_stmt = $mysqli->prepare("
                INSERT INTO admin_verifications (user_id, verification_code, email, expires_at) 
                VALUES (?, ?, ?, ?)
            ");
            $insert_stmt->bind_param("isss", $user['id'], $verificationCode, $user['email'], $expiresAt);
            
            if($insert_stmt->execute()){
                $settings_sql = $mysqli->prepare("SELECT * FROM system_settings LIMIT 1");
                $settings_sql->execute();
                $settings_result = $settings_sql->get_result();
                $settings = $settings_result->fetch_object();
                $system_name = $settings->system_name ?? 'Teacher Attendance System';
                $sidebar_color = $settings->sidebar_color ?? '#343a40';
                
                $emailResult = sendVerificationEmail($user['email'], $user['fullname'], $verificationCode, $system_name, $sidebar_color);
                
                if($emailResult['success']){
                    $success = "A new verification code has been sent to <strong>" . htmlspecialchars($user['email']) . "</strong>. Please check your email.";
                    $show_verification = true;
                    $unverified_email = $user['email'];
                    $unverified_user_id = $user['id'];
                } else {
                    $error = "Failed to send verification email. Please try again later.";
                }
            } else {
                $error = "Failed to generate verification code. Please try again.";
            }
        }
    } else {
        $error = "No unverified account found with this email address.";
    }
}

// Handle verification submission
if(isset($_POST['verify_account'])){
    $verification_code = trim($_POST['verification_code']);
    $email = trim($_POST['email']);
    
    if(empty($verification_code)){
        $error = "Please enter your verification code.";
    } else {
        try {
            // Check if verification code exists and is valid
            $verify_stmt = $mysqli->prepare("
                SELECT av.*, u.id as user_id, u.fullname, u.email 
                FROM admin_verifications av 
                JOIN users u ON av.user_id = u.id 
                WHERE av.verification_code = ? 
                AND u.email = ?
                AND av.verified_at IS NULL 
                AND av.expires_at > NOW()
            ");
            $verify_stmt->bind_param("ss", $verification_code, $email);
            $verify_stmt->execute();
            $verify_result = $verify_stmt->get_result();
            $verification = $verify_result->fetch_assoc();
            
            if($verification){
                // Mark as verified
                $update_stmt = $mysqli->prepare("UPDATE admin_verifications SET verified_at = NOW() WHERE id = ?");
                $update_stmt->bind_param("i", $verification['id']);
                $update_stmt->execute();
                
                $success = "Account verified successfully! You can now login.";
                $show_verification = false;
                
                // Clear the verification form
                unset($_POST);
            } else {
                $error = "Invalid or expired verification code. Please request a new code.";
                $show_verification = true;
                $unverified_email = $email;
            }
        } catch (Exception $e) {
            $error = "Verification failed: " . $e->getMessage();
            error_log("Verification error: " . $e->getMessage());
        }
    }
}

// Handle normal login
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login'])){
    $email = mysqli_real_escape_string($mysqli, $_POST['email']);
    $password = $_POST['password'];

    $stmt = $mysqli->prepare("SELECT id, fullname, email, password, role FROM users WHERE email = ? AND role = 'admin'");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if($result->num_rows == 1){
        $user = $result->fetch_object();
        
        // Check if admin is verified
        $verify_check = $mysqli->prepare("SELECT verified_at FROM admin_verifications WHERE user_id = ?");
        $verify_check->bind_param("i", $user->id);
        $verify_check->execute();
        $verify_result = $verify_check->get_result();
        $verification = $verify_result->fetch_assoc();
        
        if(!$verification || is_null($verification['verified_at'])){
            $error = "Your admin account is not verified. Please check your email for verification code or request a new one below.";
            $show_verification = true;
            $unverified_email = $email;
            $unverified_user_id = $user->id;
        } else if(password_verify($password, $user->password)){
            $_SESSION['user_id'] = $user->id;
            $_SESSION['user_name'] = $user->fullname;
            $_SESSION['user_email'] = $user->email;
            $_SESSION['user_role'] = $user->role;
            header("Location: dashboard.php");
            exit();
        } else {
            $error = "Invalid email or password";
        }
    } else {
        $error = "Invalid email or password";
    }
}

// Get system settings for styling
$settings_sql = $mysqli->prepare("SELECT * FROM system_settings LIMIT 1");
$settings_sql->execute();
$settings_result = $settings_sql->get_result();
$settings = $settings_result->fetch_object();

$system_name = $settings->system_name ?? 'Teacher Attendance System';
$sidebar_color = $settings->sidebar_color ?? '#343a40';
$font_family = $settings->font_family ?? 'Inter, sans-serif';
$font_size = $settings->font_size ?? '14px';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - <?php echo htmlspecialchars($system_name); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&family=Poppins:wght@500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: linear-gradient(145deg, 
                <?php echo htmlspecialchars($sidebar_color); ?>CC 0%, 
                <?php echo htmlspecialchars($sidebar_color); ?> 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: <?php echo htmlspecialchars($font_family); ?>;
            font-size: <?php echo htmlspecialchars($font_size); ?>;
            padding: 1.5rem;
            position: relative;
        }

        /* Background overlay with logo pattern */
        body::before {
            content: "";
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-image: url('images/logo.jpg');
            background-repeat: repeat;
            background-size: 60px;
            background-position: center;
            opacity: 0.08;
            pointer-events: none;
            z-index: 0;
        }

        body::after {
            content: "";
            position: absolute;
            width: 100%;
            height: 100%;
            background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="rgba(255,255,255,0.08)" fill-opacity="0.5" d="M0,96L48,112C96,128,192,160,288,160C384,160,480,128,576,122.7C672,117,768,139,864,154.7C960,171,1056,181,1152,165.3C1248,149,1344,107,1392,85.3L1440,64L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path></svg>');
            background-repeat: no-repeat;
            background-position: bottom;
            background-size: cover;
            opacity: 0.3;
            bottom: 0;
            left: 0;
            pointer-events: none;
            z-index: 0;
        }

        .login-wrapper {
            width: 100%;
            max-width: 500px;
            position: relative;
            z-index: 2;
            animation: fadeSlideUp 0.6s ease-out;
        }

        @keyframes fadeSlideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .login-card {
            background: rgba(255, 255, 255, 0.98);
            border-radius: 2rem;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.35);
            padding: 2rem 2rem 2.2rem;
            transition: transform 0.2s ease;
            border: 1px solid rgba(255,255,255,0.3);
        }

        .login-card:hover {
            transform: translateY(-4px);
        }

        .logo-area {
            text-align: center;
            margin-bottom: 1.5rem;
        }

        .logo-img {
            width: 85px;
            height: 85px;
            object-fit: cover;
            border-radius: 50%;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
            border: 3px solid white;
            background: #f8f9fc;
            padding: 4px;
            transition: all 0.3s;
        }

        .logo-img:hover {
            transform: scale(1.02);
            box-shadow: 0 12px 24px rgba(0, 0, 0, 0.2);
        }

        .brand-title {
            font-family: 'Poppins', sans-serif;
            font-weight: 700;
            font-size: 1.75rem;
            margin-top: 0.75rem;
            margin-bottom: 0.25rem;
            background: linear-gradient(135deg, 
                <?php echo htmlspecialchars($sidebar_color); ?>, 
                <?php echo htmlspecialchars($sidebar_color); ?>dd);
            background-clip: text;
            -webkit-background-clip: text;
            color: transparent;
            letter-spacing: -0.3px;
        }

        .badge-admin {
            background: <?php echo htmlspecialchars($sidebar_color); ?>15;
            color: <?php echo htmlspecialchars($sidebar_color); ?>;
            font-size: 0.75rem;
            font-weight: 600;
            padding: 0.25rem 0.9rem;
            border-radius: 40px;
            display: inline-block;
            margin-top: 6px;
        }

        .form-label {
            font-weight: 600;
            font-size: 0.85rem;
            margin-bottom: 0.4rem;
            color: <?php echo htmlspecialchars($sidebar_color); ?>;
            letter-spacing: -0.2px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .form-label i {
            color: <?php echo htmlspecialchars($sidebar_color); ?>;
            font-size: 0.9rem;
            width: 20px;
        }

        .input-group-custom {
            position: relative;
        }

        .form-control {
            border-radius: 1rem;
            border: 1px solid #e2e8f0;
            padding: 0.7rem 1rem;
            font-size: <?php echo htmlspecialchars($font_size); ?>;
            transition: all 0.2s;
            background-color: #ffffff;
            font-weight: 500;
        }

        .form-control:focus {
            border-color: <?php echo htmlspecialchars($sidebar_color); ?>;
            box-shadow: 0 0 0 4px <?php echo htmlspecialchars($sidebar_color); ?>25;
            outline: none;
        }

        .password-toggle {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #8ba0ae;
            background: white;
            padding-left: 6px;
            z-index: 5;
        }

        .password-toggle:hover {
            color: <?php echo htmlspecialchars($sidebar_color); ?>;
        }

        .btn-login, .btn-verify, .btn-resend {
            background: linear-gradient(95deg, 
                <?php echo htmlspecialchars($sidebar_color); ?>, 
                <?php echo htmlspecialchars($sidebar_color); ?>cc);
            border: none;
            border-radius: 2rem;
            padding: 0.8rem;
            font-weight: 700;
            font-size: 1rem;
            transition: all 0.25s;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            letter-spacing: 0.3px;
            color: white;
        }

        .btn-login:hover, .btn-verify:hover, .btn-resend:hover {
            background: linear-gradient(95deg, 
                <?php echo htmlspecialchars($sidebar_color); ?>dd, 
                <?php echo htmlspecialchars($sidebar_color); ?>);
            transform: scale(1.01);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
            color: white;
        }
        
        .btn-outline-resend {
            background: transparent;
            border: 2px solid <?php echo htmlspecialchars($sidebar_color); ?>;
            color: <?php echo htmlspecialchars($sidebar_color); ?>;
        }
        
        .btn-outline-resend:hover {
            background: <?php echo htmlspecialchars($sidebar_color); ?>;
            color: white;
        }

        .register-link {
            text-decoration: none;
            font-weight: 600;
            color: <?php echo htmlspecialchars($sidebar_color); ?>;
            transition: 0.2s;
        }

        .register-link:hover {
            color: <?php echo htmlspecialchars($sidebar_color); ?>cc;
            text-decoration: underline;
        }

        hr {
            background: #dee2e6;
            opacity: 0.5;
        }

        .alert {
            border-radius: 1.2rem;
            border: none;
            font-weight: 500;
            font-size: 0.85rem;
            padding: 0.8rem 1rem;
        }

        .alert-danger {
            background: #ffe6e5;
            color: #b13e3e;
        }

        .alert-success {
            background: #e0f7ef;
            color: #1d6f4c;
        }

        .alert-info {
            background: #e3f2fd;
            color: #0c5460;
            border-left: 4px solid <?php echo htmlspecialchars($sidebar_color); ?>;
        }

        .verification-section {
            animation: slideDown 0.5s ease-out;
            background: #f8f9fa;
            padding: 1.5rem;
            border-radius: 1rem;
            margin-top: 1rem;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .resend-options {
            margin-top: 1rem;
            padding-top: 1rem;
            border-top: 1px solid #dee2e6;
        }

        @media (max-width: 480px) {
            .login-card {
                padding: 1.5rem;
            }
            .brand-title {
                font-size: 1.5rem;
            }
            .logo-img {
                width: 70px;
                height: 70px;
            }
        }

        .verification-code-input {
            font-family: monospace;
            font-size: 1.2rem;
            letter-spacing: 2px;
        }
    </style>
</head>
<body>

<div class="login-wrapper">
    <div class="login-card">
        
        <div class="logo-area">
            <img src="images/logo.jpg" alt="<?php echo htmlspecialchars($system_name); ?> Logo" class="logo-img" onerror="this.onerror=null; this.src='https://placehold.co/200x200?text=Logo';">
            <div class="brand-title"><?php echo htmlspecialchars($system_name); ?></div>
            <div class="badge-admin"><i class="fas fa-shield-alt me-1"></i> Admin Login</div>
        </div>

        <?php if(!empty($error)): ?>
        <div class="alert alert-danger d-flex align-items-center" role="alert">
            <i class="fas fa-exclamation-circle me-2"></i>
            <div><?php echo $error; ?></div>
        </div>
        <?php endif; ?>

        <?php if(!empty($success)): ?>
        <div class="alert alert-success d-flex align-items-center" role="alert">
            <i class="fas fa-check-circle me-2"></i>
            <div><?php echo $success; ?></div>
        </div>
        <?php endif; ?>

        <!-- Normal Login Form -->
        <?php if(!$show_verification): ?>
        <form method="POST" action="" id="loginForm">
            <div class="mb-3">
                <label for="email" class="form-label">
                    <i class="fas fa-envelope"></i> Email Address
                </label>
                <div class="input-group-custom">
                    <input type="email" class="form-control" id="email" name="email" 
                           placeholder="admin@school.edu" required autocomplete="off">
                </div>
            </div>
            <div class="mb-4">
                <label for="password" class="form-label">
                    <i class="fas fa-lock"></i> Password
                </label>
                <div class="input-group-custom position-relative">
                    <input type="password" class="form-control" id="password" name="password" 
                           placeholder="Enter your password" required>
                    <span class="password-toggle" id="togglePassword">
                        <i class="far fa-eye-slash"></i>
                    </span>
                </div>
            </div>
            <input type="hidden" name="login" value="1">
            <button type="submit" class="btn btn-login w-100 py-2" id="loginBtn">
                <i class="fas fa-sign-in-alt me-2"></i> Login
            </button>
        </form>
        <?php endif; ?>

        <!-- Verification Section -->
        <?php if($show_verification): ?>
        <div class="verification-section">
            <div class="alert alert-info mb-3">
                <i class="fas fa-info-circle me-2"></i>
                <strong>Account Not Verified!</strong><br>
                Please verify your admin account to continue.
            </div>
            
            <form method="POST" action="">
                <div class="mb-3">
                    <label for="verification_code" class="form-label">
                        <i class="fas fa-key"></i> Verification Code
                    </label>
                    <div class="input-group-custom">
                        <input type="text" class="form-control verification-code-input" 
                               id="verification_code" name="verification_code" 
                               placeholder="Enter code (e.g., 1-1234)" required autocomplete="off">
                    </div>
                    <div class="form-text" style="font-size: 0.7rem;">
                        Enter the verification code sent to your email address. Format: UserID-XXXX
                    </div>
                </div>
                
                <input type="hidden" name="email" value="<?php echo htmlspecialchars($unverified_email); ?>">
                <button type="submit" name="verify_account" class="btn btn-verify w-100 py-2 mb-2">
                    <i class="fas fa-check-circle me-2"></i> Verify Account
                </button>
            </form>
            
            <div class="resend-options">
                <form method="POST" action="">
                    <input type="hidden" name="email" value="<?php echo htmlspecialchars($unverified_email); ?>">
                    <button type="submit" name="resend_code" class="btn btn-outline-resend w-100 py-2">
                        <i class="fas fa-paper-plane me-2"></i> Resend Verification Code
                    </button>
                </form>
                
                <div class="text-center mt-3">
                    <p class="text-muted small mb-0">
                        <i class="fas fa-envelope me-1"></i> Didn't receive the email? 
                        <a href="register_admin.php" class="register-link">Register again</a>
                    </p>
                </div>
            </div>
        </div>
        
        <hr class="my-4">
        
        <div class="text-center">
            <p class="text-muted mb-0" style="font-size: 0.9rem;">
                <i class="fas fa-arrow-left me-1"></i> Back to 
                <a href="login.php" class="register-link">Login</a>
            </p>
        </div>
        <?php else: ?>
        <hr class="my-4">

        <div class="text-center">
            <p class="text-muted mb-0" style="font-size: 0.9rem;">
                <i class="fas fa-user-plus me-1"></i> Don't have an account? 
                <a href="register_admin.php" class="register-link">Register as Admin</a>
            </p>
        </div>
        <?php endif; ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Password visibility toggle
    const togglePassword = document.getElementById('togglePassword');
    const passwordInput = document.getElementById('password');
    
    if(togglePassword && passwordInput) {
        togglePassword.addEventListener('click', function() {
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
            const icon = this.querySelector('i');
            icon.classList.toggle('fa-eye');
            icon.classList.toggle('fa-eye-slash');
        });
    }
    
    // Optional: Auto-focus on verification code field if showing
    <?php if($show_verification): ?>
    const verificationInput = document.getElementById('verification_code');
    if(verificationInput) {
        verificationInput.focus();
    }
    <?php endif; ?>
    
    // Simple form validation for login
    const loginForm = document.getElementById('loginForm');
    if(loginForm) {
        loginForm.addEventListener('submit', function(e) {
            const email = document.getElementById('email').value.trim();
            const password = document.getElementById('password').value.trim();
            
            if(!email || !password) {
                e.preventDefault();
                alert('Please enter both email and password.');
            }
        });
    }
</script>
</body>
</html>