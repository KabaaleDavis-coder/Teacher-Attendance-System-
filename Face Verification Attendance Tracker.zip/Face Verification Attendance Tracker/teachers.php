<?php
require_once 'includes/header.php';
requireAdmin();

// Fetch teachers from database
$teachers_sql = $mysqli->prepare("SELECT * FROM teachers ORDER BY created_at DESC");
if (!$teachers_sql) {
    die("Error preparing query: " . $mysqli->error);
}
$teachers_sql->execute();
$teachers = $teachers_sql->get_result();

// Get statistics for teachers
$total_teachers = $teachers->num_rows;
$active_teachers = $total_teachers;

// Get recent teachers (last 30 days)
$recent_sql = $mysqli->prepare("SELECT COUNT(*) as count FROM teachers WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)");
$recent_sql->execute();
$recent_result = $recent_sql->get_result();
$recent_teachers = $recent_result->fetch_object()->count ?? 0;

// Reset pointer for the main query
$teachers->data_seek(0);

$sidebar_color = $settings->sidebar_color ?? '#2c3e50';
?>

<style>
.camera-container {
    background: #f8f9fa;
    border-radius: 10px;
    padding: 15px;
    border: 1px solid #e9ecef;
}
.camera-preview {
    width: 100%;
    border-radius: 8px;
    background: #000;
}
.current-photo {
    margin-top: 10px;
    padding: 10px;
    background: #f8f9fa;
    border-radius: 8px;
}
.search-box {
    position: relative;
    width: 250px;
}
.search-box i {
    position: absolute;
    left: 10px;
    top: 50%;
    transform: translateY(-50%);
    color: #6c757d;
    z-index: 1;
}
.search-box input {
    padding-left: 35px;
}
.teacher-avatar {
    width: 45px;
    height: 45px;
    border-radius: 50%;
    object-fit: cover;
}
.table-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 1rem 1.5rem;
    background: white;
    border-bottom: 1px solid #e9ecef;
}
@media (max-width: 768px) {
    .table-header {
        flex-direction: column;
        gap: 1rem;
    }
    .search-box {
        width: 100%;
    }
}
</style>

<div class="p-4">
    <!-- Header Section -->
    <div class="welcome-banner fade-in-up mb-4">
        <div class="row align-items-center">
            <div class="col-md-8">
                <h1>Manage Teachers</h1>
                <p>View and manage all teachers in the system. Add new teachers or update existing ones.</p>
            </div>
            <div class="col-md-4 text-md-end">
                <button class="btn btn-primary btn-lg" data-bs-toggle="modal" data-bs-target="#addTeacherModal">
                    <i class="bi bi-plus-circle me-2"></i>Add New Teacher
                </button>
            </div>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="row mb-4">
        <div class="col-sm-6 col-lg-4 mb-3">
            <div class="stat-card total fade-in-up" style="animation-delay: 0.1s">
                <div class="stat-icon">
                    <i class="bi bi-people"></i>
                </div>
                <div class="stat-title">Total Teachers</div>
                <div class="stat-value h2 mb-0"><?php echo $total_teachers; ?></div>
                <div class="stat-trend mt-2">
                    <i class="bi bi-person-badge"></i> Registered Members
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-lg-4 mb-3">
            <div class="stat-card present fade-in-up" style="animation-delay: 0.2s">
                <div class="stat-icon">
                    <i class="bi bi-person-check"></i>
                </div>
                <div class="stat-title">Active Teachers</div>
                <div class="stat-value h2 mb-0"><?php echo $active_teachers; ?></div>
                <div class="stat-trend text-success mt-2">
                    <i class="bi bi-arrow-up"></i> All Teachers Active
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-lg-4 mb-3">
            <div class="stat-card late fade-in-up" style="animation-delay: 0.3s">
                <div class="stat-icon">
                    <i class="bi bi-calendar-plus"></i>
                </div>
                <div class="stat-title">New This Month</div>
                <div class="stat-value h2 mb-0"><?php echo $recent_teachers; ?></div>
                <div class="stat-trend text-warning mt-2">
                    <i class="bi bi-calendar-range"></i> Last 30 Days
                </div>
            </div>
        </div>
    </div>

    <!-- Teachers Table -->
    <div class="attendance-table fade-in-up" style="animation-delay: 0.4s">
        <div class="table-header">
            <h5 class="mb-0"><i class="bi bi-person-badge me-2"></i> Teachers Directory</h5>
            <div class="search-box">
                <i class="bi bi-search"></i>
                <input type="text" id="searchTeacher" class="form-control form-control-sm" placeholder="Search teachers...">
            </div>
        </div>
        <div class="table-responsive p-3">
            <table class="table table-hover mb-0" id="teachersTable">
                <thead>
                    <tr>
                        <th>Teacher</th>
                        <th>Contact Info</th>
                        <th>Subject</th>
                        <th>Registered</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($teacher = $teachers->fetch_object()): ?>
                    <tr class="teacher-row" data-teacher-id="<?php echo $teacher->id; ?>">
                        <td>
                            <div class="d-flex align-items-center">
                                <?php if($teacher->photo && file_exists($teacher->photo)): ?>
                                <img src="<?php echo htmlspecialchars($teacher->photo); ?>" class="teacher-avatar me-2" alt="">
                                <?php else: ?>
                                <div class="teacher-avatar bg-secondary text-white d-flex align-items-center justify-content-center me-2">
                                    <i class="bi bi-person"></i>
                                </div>
                                <?php endif; ?>
                                <div>
                                    <span class="fw-semibold"><?php echo htmlspecialchars($teacher->fullname); ?></span>
                                    <small class="d-block text-muted">ID: <?php echo $teacher->id; ?></small>
                                </div>
                            </div>
                        </td>
                        <td>
                            <div>
                                <i class="bi bi-envelope me-1"></i> <?php echo htmlspecialchars($teacher->email); ?><br>
                                <?php if($teacher->phone): ?>
                                <i class="bi bi-telephone me-1"></i> <?php echo htmlspecialchars($teacher->phone); ?>
                                <?php endif; ?>
                            </div>
                        </td>
                        <td>
                            <?php if($teacher->subject): ?>
                            <span class="status-badge present"><?php echo htmlspecialchars($teacher->subject); ?></span>
                            <?php else: ?>
                            <span class="text-muted">Not Assigned</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php echo date('M d, Y', strtotime($teacher->created_at)); ?>
                            <small class="d-block text-muted"><?php echo time_elapsed_string($teacher->created_at); ?></small>
                        </td>
                        <td>
                            <button class="btn btn-sm btn-info me-1" onclick="viewTeacher(<?php echo $teacher->id; ?>)" title="View Details">
                                <i class="bi bi-eye"></i>
                            </button>
                            <button class="btn btn-sm btn-warning me-1" onclick="editTeacher(<?php echo $teacher->id; ?>)" title="Edit Teacher">
                                <i class="bi bi-pencil"></i>
                            </button>
                            <button class="btn btn-sm btn-danger" onclick="deleteTeacher(<?php echo $teacher->id; ?>)" title="Delete Teacher">
                                <i class="bi bi-trash"></i>
                            </button>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                    
                    <?php if($total_teachers == 0): ?>
                    <tr>
                        <td colspan="5" class="text-center py-5">
                            <i class="bi bi-person-x" style="font-size: 48px; color: #ccc;"></i>
                            <p class="mt-3 text-muted">No teachers found. Click "Add New Teacher" to get started.</p>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add Teacher Modal with Camera -->
<div class="modal fade" id="addTeacherModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-person-plus me-2"></i>Add New Teacher</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="addTeacherForm" enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Full Name *</label>
                                <input type="text" class="form-control" name="fullname" id="add_fullname" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Email Address *</label>
                                <input type="email" class="form-control" name="email" id="add_email" required>
                            </div>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Phone Number</label>
                                    <input type="text" class="form-control" name="phone" id="add_phone">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Subject/Specialization</label>
                                    <input type="text" class="form-control" name="subject" id="add_subject">
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Upload Photo (File)</label>
                                <input type="file" class="form-control" name="photo" accept="image/*" id="photoInput">
                                <small class="text-muted">Supported formats: JPG, PNG, GIF. Max size: 5MB</small>
                                <div id="photoPreview" class="mt-2" style="display: none;">
                                    <img id="previewImage" src="#" alt="Preview" style="max-width: 100px; border-radius: 10px;">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Or Take Photo with Camera</label>
                                <div class="camera-container">
                                    <video id="addCamera" autoplay playsinline style="width: 100%; border-radius: 8px; display: none;"></video>
                                    <canvas id="addCanvas" style="display: none;"></canvas>
                                    <div id="addCameraPlaceholder" class="text-center py-4">
                                        <i class="bi bi-camera" style="font-size: 48px; color: #ccc;"></i>
                                        <p class="mt-2">Click "Start Camera" to take a photo</p>
                                    </div>
                                    <div class="mt-2 text-center">
                                        <button type="button" class="btn btn-sm btn-primary" id="startAddCameraBtn">
                                            <i class="bi bi-camera-video"></i> Start Camera
                                        </button>
                                        <button type="button" class="btn btn-sm btn-success" id="addCaptureBtn" style="display: none;">
                                            <i class="bi bi-camera"></i> Capture Photo
                                        </button>
                                        <button type="button" class="btn btn-sm btn-secondary" id="addStopBtn" style="display: none;">
                                            <i class="bi bi-stop-circle"></i> Stop Camera
                                        </button>
                                    </div>
                                    <div id="addCapturedPhoto" class="mt-2 text-center" style="display: none;">
                                        <img id="addCapturedImg" src="#" style="max-width: 100%; border-radius: 8px;">
                                        <button type="button" class="btn btn-sm btn-warning mt-2" id="retakeAddBtn">
                                            <i class="bi bi-arrow-repeat"></i> Retake
                                        </button>
                                    </div>
                                    <input type="hidden" name="photo_base64" id="addPhotoBase64">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Add Teacher</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- View Teacher Modal -->
<div class="modal fade" id="viewTeacherModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-person-badge me-2"></i>Teacher Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="viewTeacherContent">
                <div class="text-center">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Edit Teacher Modal with Camera -->
<div class="modal fade" id="editTeacherModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-pencil-square me-2"></i>Edit Teacher</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="editTeacherForm" enctype="multipart/form-data">
                <input type="hidden" name="teacher_id" id="edit_teacher_id">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Full Name *</label>
                                <input type="text" class="form-control" name="fullname" id="edit_fullname" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Email Address *</label>
                                <input type="email" class="form-control" name="email" id="edit_email" required>
                            </div>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Phone Number</label>
                                    <input type="text" class="form-control" name="phone" id="edit_phone">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Subject/Specialization</label>
                                    <input type="text" class="form-control" name="subject" id="edit_subject">
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Upload Photo (File)</label>
                                <input type="file" class="form-control" name="photo" accept="image/*" id="edit_photoInput">
                                <small class="text-muted">Leave empty to keep current photo</small>
                                <div id="edit_photoPreview" class="mt-2"></div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Or Take New Photo with Camera</label>
                                <div class="camera-container">
                                    <video id="editCamera" autoplay playsinline style="width: 100%; border-radius: 8px; display: none;"></video>
                                    <canvas id="editCanvas" style="display: none;"></canvas>
                                    <div id="editCameraPlaceholder" class="text-center py-4">
                                        <i class="bi bi-camera" style="font-size: 48px; color: #ccc;"></i>
                                        <p class="mt-2">Click "Start Camera" to take a new photo</p>
                                    </div>
                                    <div class="mt-2 text-center">
                                        <button type="button" class="btn btn-sm btn-primary" id="startEditCameraBtn">
                                            <i class="bi bi-camera-video"></i> Start Camera
                                        </button>
                                        <button type="button" class="btn btn-sm btn-success" id="editCaptureBtn" style="display: none;">
                                            <i class="bi bi-camera"></i> Capture Photo
                                        </button>
                                        <button type="button" class="btn btn-sm btn-secondary" id="editStopBtn" style="display: none;">
                                            <i class="bi bi-stop-circle"></i> Stop Camera
                                        </button>
                                    </div>
                                    <div id="editCapturedPhoto" class="mt-2 text-center" style="display: none;">
                                        <img id="editCapturedImg" src="#" style="max-width: 100%; border-radius: 8px;">
                                        <button type="button" class="btn btn-sm btn-warning mt-2" id="retakeEditBtn">
                                            <i class="bi bi-arrow-repeat"></i> Retake
                                        </button>
                                    </div>
                                    <input type="hidden" name="photo_base64" id="editPhotoBase64">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Update Teacher</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Global variables for camera streams
let addStream = null;
let editStream = null;

// ==================== SEARCH FUNCTIONALITY ====================
document.getElementById('searchTeacher').addEventListener('keyup', function() {
    let searchValue = this.value.toLowerCase();
    let rows = document.querySelectorAll('#teachersTable tbody tr');
    
    rows.forEach(row => {
        let text = row.textContent.toLowerCase();
        if(text.includes(searchValue)) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
});

// ==================== FILE UPLOAD PREVIEW ====================
document.getElementById('photoInput').addEventListener('change', function(e) {
    const preview = document.getElementById('photoPreview');
    const previewImage = document.getElementById('previewImage');
    
    if(this.files && this.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            previewImage.src = e.target.result;
            preview.style.display = 'block';
        }
        reader.readAsDataURL(this.files[0]);
    } else {
        preview.style.display = 'none';
    }
});

// ==================== ADD TEACHER CAMERA FUNCTIONS ====================
const addVideo = document.getElementById('addCamera');
const addCanvas = document.getElementById('addCanvas');
const addPlaceholder = document.getElementById('addCameraPlaceholder');
const startAddBtn = document.getElementById('startAddCameraBtn');
const addCaptureBtn = document.getElementById('addCaptureBtn');
const addStopBtn = document.getElementById('addStopBtn');
const addCapturedDiv = document.getElementById('addCapturedPhoto');
const addCapturedImg = document.getElementById('addCapturedImg');
const retakeAddBtn = document.getElementById('retakeAddBtn');
const addPhotoBase64 = document.getElementById('addPhotoBase64');

async function startAddCamera() {
    try {
        if (addStream) {
            stopAddCamera();
        }
        addStream = await navigator.mediaDevices.getUserMedia({ video: true });
        addVideo.srcObject = addStream;
        addVideo.style.display = 'block';
        addPlaceholder.style.display = 'none';
        addCaptureBtn.style.display = 'inline-block';
        addStopBtn.style.display = 'inline-block';
        startAddBtn.style.display = 'none';
    } catch (err) {
        console.error('Error accessing camera:', err);
        alert('Unable to access camera. Please make sure you have granted camera permissions.');
    }
}

function stopAddCamera() {
    if (addStream) {
        addStream.getTracks().forEach(track => track.stop());
        addStream = null;
    }
    addVideo.style.display = 'none';
    addPlaceholder.style.display = 'block';
    addCaptureBtn.style.display = 'none';
    addStopBtn.style.display = 'none';
    startAddBtn.style.display = 'inline-block';
}

function captureAddPhoto() {
    if (!addStream) {
        alert('Please start the camera first');
        return;
    }
    
    const context = addCanvas.getContext('2d');
    addCanvas.width = addVideo.videoWidth;
    addCanvas.height = addVideo.videoHeight;
    context.drawImage(addVideo, 0, 0, addCanvas.width, addCanvas.height);
    
    const imageData = addCanvas.toDataURL('image/jpeg', 0.8);
    addCapturedImg.src = imageData;
    addCapturedDiv.style.display = 'block';
    addPhotoBase64.value = imageData;
    
    // Stop camera after capture
    stopAddCamera();
}

function retakeAddPhoto() {
    addCapturedDiv.style.display = 'none';
    addPhotoBase64.value = '';
    startAddCamera();
}

startAddBtn.addEventListener('click', startAddCamera);
addCaptureBtn.addEventListener('click', captureAddPhoto);
addStopBtn.addEventListener('click', stopAddCamera);
retakeAddBtn.addEventListener('click', retakeAddPhoto);

// ==================== EDIT TEACHER CAMERA FUNCTIONS ====================
const editVideo = document.getElementById('editCamera');
const editCanvas = document.getElementById('editCanvas');
const editPlaceholder = document.getElementById('editCameraPlaceholder');
const startEditBtn = document.getElementById('startEditCameraBtn');
const editCaptureBtn = document.getElementById('editCaptureBtn');
const editStopBtn = document.getElementById('editStopBtn');
const editCapturedDiv = document.getElementById('editCapturedPhoto');
const editCapturedImg = document.getElementById('editCapturedImg');
const retakeEditBtn = document.getElementById('retakeEditBtn');
const editPhotoBase64 = document.getElementById('editPhotoBase64');

async function startEditCamera() {
    try {
        if (editStream) {
            stopEditCamera();
        }
        editStream = await navigator.mediaDevices.getUserMedia({ video: true });
        editVideo.srcObject = editStream;
        editVideo.style.display = 'block';
        editPlaceholder.style.display = 'none';
        editCaptureBtn.style.display = 'inline-block';
        editStopBtn.style.display = 'inline-block';
        startEditBtn.style.display = 'none';
    } catch (err) {
        console.error('Error accessing camera:', err);
        alert('Unable to access camera. Please make sure you have granted camera permissions.');
    }
}

function stopEditCamera() {
    if (editStream) {
        editStream.getTracks().forEach(track => track.stop());
        editStream = null;
    }
    editVideo.style.display = 'none';
    editPlaceholder.style.display = 'block';
    editCaptureBtn.style.display = 'none';
    editStopBtn.style.display = 'none';
    startEditBtn.style.display = 'inline-block';
}

function captureEditPhoto() {
    if (!editStream) {
        alert('Please start the camera first');
        return;
    }
    
    const context = editCanvas.getContext('2d');
    editCanvas.width = editVideo.videoWidth;
    editCanvas.height = editVideo.videoHeight;
    context.drawImage(editVideo, 0, 0, editCanvas.width, editCanvas.height);
    
    const imageData = editCanvas.toDataURL('image/jpeg', 0.8);
    editCapturedImg.src = imageData;
    editCapturedDiv.style.display = 'block';
    editPhotoBase64.value = imageData;
    
    // Stop camera after capture
    stopEditCamera();
}

function retakeEditPhoto() {
    editCapturedDiv.style.display = 'none';
    editPhotoBase64.value = '';
    startEditCamera();
}

startEditBtn.addEventListener('click', startEditCamera);
editCaptureBtn.addEventListener('click', captureEditPhoto);
editStopBtn.addEventListener('click', stopEditCamera);
retakeEditBtn.addEventListener('click', retakeEditPhoto);

// ==================== ADD TEACHER FORM SUBMISSION ====================
document.getElementById('addTeacherForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const submitBtn = this.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Adding...';
    submitBtn.disabled = true;
    
    let formData = new FormData(this);
    
    try {
        const response = await fetch('api/add_teacher.php', {
            method: 'POST',
            body: formData
        });
        
        const text = await response.text();
        let data;
        try {
            data = JSON.parse(text);
        } catch (e) {
            console.error('Invalid JSON response:', text);
            throw new Error('Server returned invalid response');
        }
        
        if (data.success) {
            showNotification('Teacher added successfully!', 'success');
            setTimeout(() => location.reload(), 1500);
        } else {
            showNotification('Error: ' + (data.message || 'Unknown error'), 'error');
            submitBtn.innerHTML = originalText;
            submitBtn.disabled = false;
        }
    } catch (error) {
        console.error('Error:', error);
        showNotification('Error adding teacher: ' + error.message, 'error');
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
    }
});

// ==================== VIEW TEACHER DETAILS ====================
async function viewTeacher(id) {
    const modalContent = document.getElementById('viewTeacherContent');
    modalContent.innerHTML = '<div class="text-center"><div class="spinner-border text-primary" role="status"></div></div>';
    
    const modal = new bootstrap.Modal(document.getElementById('viewTeacherModal'));
    modal.show();
    
    try {
        const response = await fetch(`api/get_teacher.php?teacher_id=${id}`);
        const text = await response.text();
        let data;
        try {
            data = JSON.parse(text);
        } catch (e) {
            console.error('Invalid JSON response:', text);
            throw new Error('Server returned invalid response');
        }
        
        if (data.success && data.teacher) {
            const teacher = data.teacher;
            let content = `
                <div class="text-center mb-4">
                    ${teacher.photo ? 
                        `<img src="${escapeHtml(teacher.photo)}" class="rounded-circle" style="width: 120px; height: 120px; object-fit: cover;">` : 
                        `<div class="rounded-circle bg-secondary mx-auto d-flex align-items-center justify-content-center" style="width: 120px; height: 120px;">
                            <i class="bi bi-person" style="font-size: 48px; color: white;"></i>
                        </div>`
                    }
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="text-muted fw-bold">Full Name</label>
                        <h6 class="mt-1">${escapeHtml(teacher.fullname)}</h6>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="text-muted fw-bold">Email</label>
                        <h6 class="mt-1">${escapeHtml(teacher.email)}</h6>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="text-muted fw-bold">Phone</label>
                        <h6 class="mt-1">${escapeHtml(teacher.phone || 'N/A')}</h6>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="text-muted fw-bold">Subject</label>
                        <h6 class="mt-1">${escapeHtml(teacher.subject || 'Not Assigned')}</h6>
                    </div>
                    <div class="col-md-12 mb-3">
                        <label class="text-muted fw-bold">Registered On</label>
                        <h6 class="mt-1">${new Date(teacher.created_at).toLocaleDateString()}</h6>
                    </div>
                </div>
            `;
            modalContent.innerHTML = content;
        } else {
            modalContent.innerHTML = `<div class="alert alert-danger">${data.message || 'Teacher not found'}</div>`;
        }
    } catch (error) {
        console.error('Error:', error);
        modalContent.innerHTML = `<div class="alert alert-danger">Error loading teacher details: ${error.message}</div>`;
    }
}

// ==================== EDIT TEACHER ====================
async function editTeacher(id) {
    // Reset camera and form
    if (editStream) {
        stopEditCamera();
    }
    document.getElementById('editCapturedPhoto').style.display = 'none';
    document.getElementById('editPhotoBase64').value = '';
    
    const modal = new bootstrap.Modal(document.getElementById('editTeacherModal'));
    modal.show();
    
    // Show loading in the form
    document.getElementById('edit_fullname').value = 'Loading...';
    document.getElementById('edit_email').value = 'Loading...';
    
    try {
        const response = await fetch(`api/get_teacher.php?teacher_id=${id}`);
        const text = await response.text();
        let data;
        try {
            data = JSON.parse(text);
        } catch (e) {
            console.error('Invalid JSON response:', text);
            throw new Error('Server returned invalid response');
        }
        
        if (data.success && data.teacher) {
            const teacher = data.teacher;
            document.getElementById('edit_teacher_id').value = teacher.id;
            document.getElementById('edit_fullname').value = teacher.fullname;
            document.getElementById('edit_email').value = teacher.email;
            document.getElementById('edit_phone').value = teacher.phone || '';
            document.getElementById('edit_subject').value = teacher.subject || '';
            
            if (teacher.photo) {
                document.getElementById('edit_photoPreview').innerHTML = `
                    <div class="current-photo">
                        <label class="text-muted fw-bold">Current Photo:</label><br>
                        <img src="${teacher.photo}" style="max-width: 100px; border-radius: 10px; margin-top: 5px;">
                    </div>
                `;
            } else {
                document.getElementById('edit_photoPreview').innerHTML = '<div class="text-muted">No current photo</div>';
            }
        } else {
            showNotification(data.message || 'Error loading teacher details', 'error');
            modal.hide();
        }
    } catch (error) {
        console.error('Error:', error);
        showNotification('Error loading teacher details: ' + error.message, 'error');
        modal.hide();
    }
}

// ==================== EDIT TEACHER FORM SUBMISSION ====================
document.getElementById('editTeacherForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const submitBtn = this.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Updating...';
    submitBtn.disabled = true;
    
    let formData = new FormData(this);
    
    try {
        const response = await fetch('api/edit_teacher.php', {
            method: 'POST',
            body: formData
        });
        
        const text = await response.text();
        let data;
        try {
            data = JSON.parse(text);
        } catch (e) {
            console.error('Invalid JSON response:', text);
            throw new Error('Server returned invalid response');
        }
        
        if (data.success) {
            showNotification('Teacher updated successfully!', 'success');
            setTimeout(() => location.reload(), 1500);
        } else {
            showNotification('Error: ' + (data.message || 'Unknown error'), 'error');
            submitBtn.innerHTML = originalText;
            submitBtn.disabled = false;
        }
    } catch (error) {
        console.error('Error:', error);
        showNotification('Error updating teacher: ' + error.message, 'error');
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
    }
});

// ==================== DELETE TEACHER ====================
async function deleteTeacher(id) {
    if (!confirm('Are you sure you want to delete this teacher? This action cannot be undone.')) {
        return;
    }
    
    try {
        const response = await fetch('api/delete_teacher.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'teacher_id=' + id
        });
        
        const text = await response.text();
        let data;
        try {
            data = JSON.parse(text);
        } catch (e) {
            console.error('Invalid JSON response:', text);
            throw new Error('Server returned invalid response');
        }
        
        if (data.success) {
            showNotification('Teacher deleted successfully!', 'success');
            setTimeout(() => location.reload(), 1500);
        } else {
            showNotification('Error: ' + (data.message || 'Unknown error'), 'error');
        }
    } catch (error) {
        console.error('Error:', error);
        showNotification('Error deleting teacher: ' + error.message, 'error');
    }
}

// ==================== HELPER FUNCTIONS ====================
function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function showNotification(message, type) {
    const notification = document.createElement('div');
    notification.className = `alert alert-${type === 'success' ? 'success' : 'danger'} alert-dismissible fade show position-fixed top-0 end-0 m-3`;
    notification.style.zIndex = '9999';
    notification.style.minWidth = '300px';
    notification.style.position = 'fixed';
    notification.style.top = '20px';
    notification.style.right = '20px';
    notification.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.remove();
    }, 3000);
}

// Clean up camera streams when modals are closed
document.getElementById('addTeacherModal').addEventListener('hidden.bs.modal', function() {
    if (addStream) {
        stopAddCamera();
    }
    document.getElementById('addCapturedPhoto').style.display = 'none';
    document.getElementById('addPhotoBase64').value = '';
});

document.getElementById('editTeacherModal').addEventListener('hidden.bs.modal', function() {
    if (editStream) {
        stopEditCamera();
    }
    document.getElementById('editCapturedPhoto').style.display = 'none';
    document.getElementById('editPhotoBase64').value = '';
});
</script>

<?php
// Helper function for time elapsed
function time_elapsed_string($datetime, $full = false) {
    $now = new DateTime();
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);
    
    $diff->w = floor($diff->d / 7);
    $diff->d -= $diff->w * 7;
    
    $string = array(
        'y' => 'year',
        'm' => 'month',
        'w' => 'week',
        'd' => 'day',
        'h' => 'hour',
        'i' => 'minute',
        's' => 'second',
    );
    
    foreach ($string as $k => &$v) {
        if ($diff->$k) {
            $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
        } else {
            unset($string[$k]);
        }
    }
    
    if (!$full) $string = array_slice($string, 0, 1);
    return $string ? implode(', ', $string) . ' ago' : 'just now';
}
?>

<?php require_once 'includes/footer.php'; ?>