<?php
require_once 'includes/header.php';
requireLogin();

$today = date('Y-m-d');
$current_month = date('Y-m');
$current_year = date('Y');
$user_role = $_SESSION['user_role'] ?? 'admin';

// Helper function for brightness
function adjustBrightness($hex, $percent) {
    $hex = ltrim($hex, '#');
    $r = hexdec(substr($hex, 0, 2));
    $g = hexdec(substr($hex, 2, 2));
    $b = hexdec(substr($hex, 4, 2));
    
    $r = max(0, min(255, $r + $percent));
    $g = max(0, min(255, $g + $percent));
    $b = max(0, min(255, $b + $percent));
    
    return sprintf("#%02x%02x%02x", $r, $g, $b);
}

// Fetch statistics based on user role
if($user_role == 'admin') {
    // Admin stats
    $present_sql = $mysqli->prepare("SELECT COUNT(DISTINCT teacher_id) as count FROM attendance WHERE date = ? AND status != 'Absent'");
    $present_sql->bind_param("s", $today);
    $present_sql->execute();
    $present_count = $present_sql->get_result()->fetch_object()->count ?? 0;

    $late_sql = $mysqli->prepare("SELECT COUNT(*) as count FROM attendance WHERE date = ? AND status = 'Late'");
    $late_sql->bind_param("s", $today);
    $late_sql->execute();
    $late_count = $late_sql->get_result()->fetch_object()->count ?? 0;

    $total_teachers_sql = $mysqli->prepare("SELECT COUNT(*) as count FROM teachers");
    $total_teachers_sql->execute();
    $total_teachers = $total_teachers_sql->get_result()->fetch_object()->count ?? 0;
    
    $absent_count = $total_teachers - $present_count;
    
    // Weekly attendance trend
    $weekly_sql = $mysqli->prepare("
        SELECT DATE(date) as attendance_date, 
               COUNT(CASE WHEN status != 'Absent' THEN 1 END) as present_count,
               COUNT(CASE WHEN status = 'Absent' THEN 1 END) as absent_count,
               COUNT(CASE WHEN status = 'Late' THEN 1 END) as late_count
        FROM attendance 
        WHERE date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
        GROUP BY DATE(date)
        ORDER BY attendance_date ASC
    ");
    $weekly_sql->execute();
    $weekly_data = $weekly_sql->get_result();
    
    $weekly_dates = [];
    $weekly_present = [];
    $weekly_absent = [];
    $weekly_late = [];
    
    while($row = $weekly_data->fetch_object()) {
        $weekly_dates[] = date('M d', strtotime($row->attendance_date));
        $weekly_present[] = $row->present_count;
        $weekly_absent[] = $row->absent_count;
        $weekly_late[] = $row->late_count;
    }
    
    // Teacher performance top 5
    $teacher_performance_sql = $mysqli->prepare("
        SELECT t.fullname, 
               COUNT(a.id) as total_days,
               SUM(CASE WHEN a.status != 'Absent' THEN 1 ELSE 0 END) as present_days,
               SUM(CASE WHEN a.status = 'Late' THEN 1 ELSE 0 END) as late_days,
               ROUND((SUM(CASE WHEN a.status != 'Absent' THEN 1 ELSE 0 END) / COUNT(a.id)) * 100, 1) as attendance_rate
        FROM teachers t
        LEFT JOIN attendance a ON t.id = a.teacher_id AND MONTH(a.date) = MONTH(CURDATE())
        GROUP BY t.id
        HAVING total_days > 0
        ORDER BY attendance_rate DESC
        LIMIT 5
    ");
    $teacher_performance_sql->execute();
    $teacher_performance = $teacher_performance_sql->get_result();
    
    $teacher_names = [];
    $teacher_rates = [];
    while($row = $teacher_performance->fetch_object()) {
        $teacher_names[] = $row->fullname;
        $teacher_rates[] = $row->attendance_rate;
    }
    
} else {
    // Teacher stats
    $teacher_id = $_SESSION['teacher_id'] ?? 0;
    
    if(!$teacher_id) {
        $teacher_stmt = $mysqli->prepare("SELECT id FROM teachers WHERE email = ?");
        $teacher_stmt->bind_param("s", $_SESSION['user_email']);
        $teacher_stmt->execute();
        $teacher_result = $teacher_stmt->get_result();
        if($teacher_row = $teacher_result->fetch_object()) {
            $teacher_id = $teacher_row->id;
            $_SESSION['teacher_id'] = $teacher_id;
        }
    }
    
    // Today's status
    $today_sql = $mysqli->prepare("SELECT * FROM attendance WHERE teacher_id = ? AND date = ?");
    $today_sql->bind_param("is", $teacher_id, $today);
    $today_sql->execute();
    $today_attendance = $today_sql->get_result()->fetch_object();
    
    $today_status = $today_attendance->status ?? 'Not Marked';
    $today_check_in = $today_attendance->check_in ?? '--:--';
    $today_check_out = $today_attendance->check_out ?? '--:--';
    
    // Monthly stats for teacher
    $month_stats_sql = $mysqli->prepare("
        SELECT 
            COUNT(*) as total_days,
            SUM(CASE WHEN status != 'Absent' THEN 1 ELSE 0 END) as present_days,
            SUM(CASE WHEN status = 'Absent' THEN 1 ELSE 0 END) as absent_days,
            SUM(CASE WHEN status = 'Late' THEN 1 ELSE 0 END) as late_days
        FROM attendance 
        WHERE teacher_id = ? AND MONTH(date) = MONTH(CURDATE()) AND YEAR(date) = YEAR(CURDATE())
    ");
    $month_stats_sql->bind_param("i", $teacher_id);
    $month_stats_sql->execute();
    $month_stats = $month_stats_sql->get_result()->fetch_object();
    
    $present_count = $month_stats->present_days ?? 0;
    $absent_count = $month_stats->absent_days ?? 0;
    $late_count = $month_stats->late_days ?? 0;
    $total_days = $month_stats->total_days ?? 0;
    
    // Weekly attendance for teacher
    $weekly_sql = $mysqli->prepare("
        SELECT DATE(date) as attendance_date, status
        FROM attendance 
        WHERE teacher_id = ? AND date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
        ORDER BY attendance_date ASC
    ");
    $weekly_sql->bind_param("i", $teacher_id);
    $weekly_sql->execute();
    $weekly_data = $weekly_sql->get_result();
    
    $weekly_dates = [];
    $weekly_status_values = [];
    
    while($row = $weekly_data->fetch_object()) {
        $weekly_dates[] = date('M d', strtotime($row->attendance_date));
        $status_value = 0;
        if($row->status == 'Present') $status_value = 100;
        elseif($row->status == 'Late') $status_value = 70;
        elseif($row->status == 'Absent') $status_value = 0;
        $weekly_status_values[] = $status_value;
    }
}

// Recent attendance
$recent_attendance_sql = $mysqli->prepare("
    SELECT a.*, t.fullname, t.photo, t.subject
    FROM attendance a 
    INNER JOIN teachers t ON a.teacher_id = t.id 
    ORDER BY a.date DESC, a.created_at DESC 
    LIMIT 15
");
$recent_attendance_sql->execute();
$recent_attendance = $recent_attendance_sql->get_result();

$sidebar_color = $settings->sidebar_color ?? '#2c3e50';
?>

<div class="p-4">
    <!-- Welcome Banner -->
    <div class="welcome-banner fade-in-up">
        <div class="row align-items-center">
            <div class="col-md-8">
                <h1>Welcome back, <?php echo htmlspecialchars($_SESSION['user_name']); ?>!</h1>
                <p>Here's what's happening with attendance today.</p>
            </div>
            <div class="col-md-4 text-md-end">
                <i class="bi bi-calendar-alt me-2"></i>
                <span id="current-date"></span><br>
                <i class="bi bi-clock me-2"></i>
                <span id="current-time"></span>
            </div>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="row mb-4">
        <div class="col-sm-6 col-lg-3 mb-3">
            <div class="stat-card present fade-in-up" style="animation-delay: 0.1s">
                <div class="stat-icon">
                    <i class="bi bi-person-check"></i>
                </div>
                <div class="stat-title">Present Today</div>
                <div class="stat-value h2 mb-0" id="present-count"><?php echo $present_count; ?></div>
                <div class="stat-trend text-success mt-2">
                    <i class="bi bi-arrow-up"></i> Attendance Rate
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-lg-3 mb-3">
            <div class="stat-card absent fade-in-up" style="animation-delay: 0.2s">
                <div class="stat-icon">
                    <i class="bi bi-person-x"></i>
                </div>
                <div class="stat-title">Absent Today</div>
                <div class="stat-value h2 mb-0" id="absent-count"><?php echo $absent_count ?? 0; ?></div>
                <div class="stat-trend text-danger mt-2">
                    <i class="bi bi-arrow-down"></i> Need Attention
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-lg-3 mb-3">
            <div class="stat-card late fade-in-up" style="animation-delay: 0.3s">
                <div class="stat-icon">
                    <i class="bi bi-clock"></i>
                </div>
                <div class="stat-title">Late Today</div>
                <div class="stat-value h2 mb-0" id="late-count"><?php echo $late_count; ?></div>
                <div class="stat-trend text-warning mt-2">
                    <i class="bi bi-exclamation-triangle"></i> Tardiness Alert
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-lg-3 mb-3">
            <div class="stat-card total fade-in-up" style="animation-delay: 0.4s">
                <div class="stat-icon">
                    <i class="bi bi-person-badge"></i>
                </div>
                <div class="stat-title">Total <?php echo $user_role == 'admin' ? 'Teachers' : 'Days This Month'; ?></div>
                <div class="stat-value h2 mb-0"><?php echo $user_role == 'admin' ? ($total_teachers ?? 0) : ($total_days ?? 0); ?></div>
                <div class="stat-trend mt-2">
                    <i class="bi bi-people"></i> Active Members
                </div>
            </div>
        </div>
    </div>

    <?php if($user_role == 'admin'): ?>
        <!-- Admin Charts -->
        <div class="row">
            <div class="col-lg-8 mb-4">
                <div class="chart-card fade-in-up" style="animation-delay: 0.5s">
                    <div class="card-header border-bottom pb-3 mb-3">
                        <h5 class="mb-0"><i class="bi bi-graph-up"></i> Weekly Attendance Trend</h5>
                    </div>
                    <canvas id="weeklyChart" style="height: 300px; width: 100%;"></canvas>
                </div>
            </div>
            <div class="col-lg-4 mb-4">
                <div class="chart-card fade-in-up" style="animation-delay: 0.6s">
                    <div class="card-header border-bottom pb-3 mb-3">
                        <h5 class="mb-0"><i class="bi bi-trophy"></i> Top Performers</h5>
                    </div>
                    <canvas id="teacherChart" style="height: 300px; width: 100%;"></canvas>
                </div>
            </div>
        </div>
    <?php else: ?>
        <!-- Teacher Charts -->
        <div class="row">
            <div class="col-lg-6 mb-4">
                <div class="chart-card fade-in-up" style="animation-delay: 0.5s">
                    <div class="card-header border-bottom pb-3 mb-3">
                        <h5 class="mb-0"><i class="bi bi-pie-chart"></i> Monthly Attendance Summary</h5>
                    </div>
                    <canvas id="attendancePieChart" style="height: 300px; width: 100%;"></canvas>
                </div>
            </div>
            <div class="col-lg-6 mb-4">
                <div class="chart-card fade-in-up" style="animation-delay: 0.6s">
                    <div class="card-header border-bottom pb-3 mb-3">
                        <h5 class="mb-0"><i class="bi bi-bar-chart"></i> Weekly Performance</h5>
                    </div>
                    <canvas id="weeklyPerformanceChart" style="height: 300px; width: 100%;"></canvas>
                </div>
            </div>
        </div>
        
        <!-- Today's Status Card -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="chart-card fade-in-up" style="animation-delay: 0.7s">
                    <div class="card-header border-bottom pb-3 mb-3">
                        <h5 class="mb-0"><i class="bi bi-calendar-day"></i> Today's Attendance Status</h5>
                    </div>
                    <div class="row text-center">
                        <div class="col-md-4 mb-3">
                            <div class="p-3 border rounded">
                                <h6 class="text-muted">Status</h6>
                                <h3 class="mb-0">
                                    <span class="status-badge <?php echo strtolower(str_replace(' ', '-', $today_status)); ?>">
                                        <?php echo $today_status; ?>
                                    </span>
                                </h3>
                            </div>
                        </div>
                        <div class="col-md-4 mb-3">
                            <div class="p-3 border rounded">
                                <h6 class="text-muted">Check In Time</h6>
                                <h3 class="mb-0"><?php echo $today_check_in; ?></h3>
                            </div>
                        </div>
                        <div class="col-md-4 mb-3">
                            <div class="p-3 border rounded">
                                <h6 class="text-muted">Check Out Time</h6>
                                <h3 class="mb-0"><?php echo $today_check_out; ?></h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <!-- Recent Attendance Table -->
    <div class="attendance-table fade-in-up" style="animation-delay: 0.7s">
        <div class="table-header">
            <h5 class="mb-0"><i class="bi bi-clock-history me-2"></i> Recent Attendance Records</h5>
        </div>
        <div class="table-responsive p-3">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>Teacher</th>
                        <th>Subject</th>
                        <th>Date</th>
                        <th>Check In</th>
                        <th>Check Out</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = $recent_attendance->fetch_object()): ?>
                    <tr>
                        <td>
                            <div class="d-flex align-items-center">
                                <?php if($row->photo && file_exists($row->photo)): ?>
                                <img src="<?php echo htmlspecialchars($row->photo); ?>" class="teacher-avatar me-2" alt="">
                                <?php else: ?>
                                <div class="teacher-avatar bg-secondary text-white d-flex align-items-center justify-content-center me-2">
                                    <i class="bi bi-person"></i>
                                </div>
                                <?php endif; ?>
                                <span class="fw-semibold"><?php echo htmlspecialchars($row->fullname); ?></span>
                            </div>
                        </td>
                        <td><?php echo htmlspecialchars($row->subject ?? 'N/A'); ?></td>
                        <td><?php echo date('M d, Y', strtotime($row->date)); ?></td>
                        <td><?php echo htmlspecialchars($row->check_in ?? '--:--'); ?></td>
                        <td><?php echo htmlspecialchars($row->check_out ?? '--:--'); ?></td>
                        <td>
                            <span class="status-badge <?php echo strtolower($row->status); ?>">
                                <?php echo htmlspecialchars($row->status); ?>
                            </span>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
// Update date and time
function updateDateTime() {
    const now = new Date();
    const dateElement = document.getElementById('current-date');
    const timeElement = document.getElementById('current-time');
    
    if(dateElement) {
        const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        dateElement.textContent = now.toLocaleDateString('en-US', options);
    }
    
    if(timeElement) {
        timeElement.textContent = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    }
}

updateDateTime();
setInterval(updateDateTime, 1000);

<?php if($user_role == 'admin'): ?>
// Weekly Attendance Chart
const weeklyCtx = document.getElementById('weeklyChart')?.getContext('2d');
if(weeklyCtx && <?php echo json_encode($weekly_dates); ?>.length > 0) {
    new Chart(weeklyCtx, {
        type: 'line',
        data: {
            labels: <?php echo json_encode($weekly_dates); ?>,
            datasets: [
                {
                    label: 'Present',
                    data: <?php echo json_encode($weekly_present); ?>,
                    borderColor: '#28a745',
                    backgroundColor: 'rgba(40, 167, 69, 0.1)',
                    tension: 0.4,
                    fill: true
                },
                {
                    label: 'Late',
                    data: <?php echo json_encode($weekly_late); ?>,
                    borderColor: '#ffc107',
                    backgroundColor: 'rgba(255, 193, 7, 0.1)',
                    tension: 0.4,
                    fill: true
                },
                {
                    label: 'Absent',
                    data: <?php echo json_encode($weekly_absent); ?>,
                    borderColor: '#dc3545',
                    backgroundColor: 'rgba(220, 53, 69, 0.1)',
                    tension: 0.4,
                    fill: true
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: { position: 'top' }
            },
            scales: {
                y: { beginAtZero: true, title: { display: true, text: 'Number of Teachers' } }
            }
        }
    });
}

// Teacher Performance Chart
const teacherCtx = document.getElementById('teacherChart')?.getContext('2d');
if(teacherCtx && <?php echo count($teacher_names); ?> > 0) {
    new Chart(teacherCtx, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($teacher_names); ?>,
            datasets: [{
                label: 'Attendance Rate (%)',
                data: <?php echo json_encode($teacher_rates); ?>,
                backgroundColor: 'rgba(52, 58, 64, 0.8)',
                borderColor: '<?php echo $sidebar_color; ?>',
                borderWidth: 1,
                borderRadius: 10
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: { legend: { position: 'top' } },
            scales: { y: { beginAtZero: true, max: 100, title: { display: true, text: 'Attendance Rate (%)' } } }
        }
    });
}

<?php else: ?>
// Teacher Pie Chart
const pieCtx = document.getElementById('attendancePieChart')?.getContext('2d');
if(pieCtx) {
    new Chart(pieCtx, {
        type: 'pie',
        data: {
            labels: ['Present', 'Late', 'Absent'],
            datasets: [{
                data: [<?php echo $present_count; ?>, <?php echo $late_count; ?>, <?php echo $absent_count; ?>],
                backgroundColor: ['#28a745', '#ffc107', '#dc3545'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: { position: 'bottom' },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const label = context.label || '';
                            const value = context.raw || 0;
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = total > 0 ? ((value / total) * 100).toFixed(1) : 0;
                            return `${label}: ${value} days (${percentage}%)`;
                        }
                    }
                }
            }
        }
    });
}

// Weekly Performance Chart
const weeklyPerfCtx = document.getElementById('weeklyPerformanceChart')?.getContext('2d');
if(weeklyPerfCtx && <?php echo count($weekly_dates); ?> > 0) {
    new Chart(weeklyPerfCtx, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($weekly_dates); ?>,
            datasets: [{
                label: 'Attendance Score',
                data: <?php echo json_encode($weekly_status_values); ?>,
                backgroundColor: 'rgba(52, 58, 64, 0.8)',
                borderColor: '<?php echo $sidebar_color; ?>',
                borderWidth: 1,
                borderRadius: 10
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: { position: 'top' },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const value = context.raw;
                            let status = '';
                            if(value === 100) status = 'Present';
                            else if(value === 70) status = 'Late';
                            else status = 'Absent';
                            return `Status: ${status}`;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    title: { display: true, text: 'Attendance Score' },
                    ticks: {
                        callback: function(value) {
                            if(value === 100) return 'Present';
                            if(value === 70) return 'Late';
                            if(value === 0) return 'Absent';
                            return '';
                        }
                    }
                }
            }
        }
    });
}
<?php endif; ?>
</script>

<?php require_once 'includes/footer.php'; ?>