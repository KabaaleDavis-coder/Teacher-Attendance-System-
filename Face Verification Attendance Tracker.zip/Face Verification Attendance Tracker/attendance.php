<?php
require_once 'includes/header.php';
requireLogin();

// Define adjustBrightness function
if (!function_exists('adjustBrightness')) {
    function adjustBrightness($hex, $percent) {
        $hex = ltrim($hex, '#');
        $r = hexdec(substr($hex, 0, 2));
        $g = hexdec(substr($hex, 2, 2));
        $b = hexdec(substr($hex, 4, 2));
        
        $r = max(0, min(255, $r + $percent));
        $g = max(0, min(255, $g + $percent));
        $b = max(0, min(255, $b + $percent));
        
        return sprintf("#%02x%02x%02x", $r, $g, $b);
    }
}

// Fetch teachers
$teachers_sql = $mysqli->prepare("SELECT id, fullname, subject, photo FROM teachers ORDER BY fullname ASC");
$teachers_sql->execute();
$teachers = $teachers_sql->get_result();

// Get today's stats
$today = date('Y-m-d');
$present_sql = $mysqli->prepare("SELECT COUNT(DISTINCT teacher_id) as count FROM attendance WHERE date = ? AND status != 'Absent'");
$present_sql->bind_param("s", $today);
$present_sql->execute();
$present_count = $present_sql->get_result()->fetch_object()->count ?? 0;

$late_sql = $mysqli->prepare("SELECT COUNT(*) as count FROM attendance WHERE date = ? AND status = 'Late'");
$late_sql->bind_param("s", $today);
$late_sql->execute();
$late_count = $late_sql->get_result()->fetch_object()->count ?? 0;

$checked_out_sql = $mysqli->prepare("SELECT COUNT(*) as count FROM attendance WHERE date = ? AND check_out IS NOT NULL");
$checked_out_sql->bind_param("s", $today);
$checked_out_sql->execute();
$checked_out_count = $checked_out_sql->get_result()->fetch_object()->count ?? 0;

$total_teachers_sql = $mysqli->prepare("SELECT COUNT(*) as count FROM teachers");
$total_teachers_sql->execute();
$total_teachers = $total_teachers_sql->get_result()->fetch_object()->count ?? 0;

$absent_count = $total_teachers - $present_count;
$sidebar_color = $settings->sidebar_color ?? '#2c3e50';
?>

<style>
.camera-container {
    background: #f8f9fa;
    border-radius: 10px;
    padding: 15px;
    border: 1px solid #e9ecef;
}
.camera-wrapper {
    position: relative;
    width: 100%;
    background: #000;
    border-radius: 8px;
    overflow: hidden;
    min-height: 300px;
    display: flex;
    align-items: center;
    justify-content: center;
}
#video {
    width: 100%;
    height: auto;
    background: #000;
    transform: scaleX(-1);
    object-fit: cover;
}
#captured-photo {
    width: 100%;
    max-height: 300px;
    object-fit: contain;
    background: #f8f9fa;
    border-radius: 8px;
    display: none;
}
.verification-container {
    background: #f8f9fa;
    border-radius: 10px;
    padding: 15px;
    border: 1px solid #e9ecef;
}
.photo-comparison {
    display: flex;
    justify-content: space-around;
    align-items: center;
    gap: 20px;
    flex-wrap: wrap;
}
.photo-box {
    text-align: center;
    flex: 1;
    min-width: 150px;
}
.photo-box img {
    width: 150px;
    height: 150px;
    border-radius: 50%;
    object-fit: cover;
    border: 3px solid <?php echo $sidebar_color; ?>;
    margin-bottom: 10px;
}
.photo-box .label {
    font-size: 12px;
    color: #6c757d;
    margin-top: 5px;
}
.match-badge {
    font-size: 24px;
    font-weight: bold;
    padding: 10px 20px;
    border-radius: 10px;
}
.match-badge.high { background: #d4edda; color: #155724; }
.match-badge.low { background: #f8d7da; color: #721c24; }
.attendance-timeline {
    max-height: 500px;
    overflow-y: auto;
}
.timeline-item {
    border-left: 3px solid;
    margin-bottom: 15px;
    padding-left: 15px;
}
.timeline-item.present { border-left-color: #28a745; }
.timeline-item.late { border-left-color: #ffc107; }
.timeline-item.absent { border-left-color: #dc3545; }
.timeline-item.checked-out { border-left-color: #17a2b8; }
.timeline-time {
    font-size: 12px;
    color: #6c757d;
}
.status-badge {
    display: inline-block;
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 500;
}
.status-badge.present { background: #d4edda; color: #155724; }
.status-badge.late { background: #fff3cd; color: #856404; }
.status-badge.absent { background: #f8d7da; color: #721c24; }
.status-badge.checked-out { background: #d1ecf1; color: #0c5460; }
.current-time-card {
    background: rgba(0,0,0,0.05);
    padding: 10px 15px;
    border-radius: 10px;
    display: inline-block;
}
.welcome-banner {
    background: linear-gradient(135deg, <?php echo $sidebar_color; ?> 0%, <?php echo adjustBrightness($sidebar_color, 40); ?> 100%);
    color: white;
    padding: 25px;
    border-radius: 15px;
    margin-bottom: 25px;
}
.stat-card {
    background: white;
    border-radius: 15px;
    padding: 20px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    position: relative;
    overflow: hidden;
    transition: transform 0.2s;
}
.stat-card:hover {
    transform: translateY(-5px);
}
.stat-icon {
    position: absolute;
    right: 20px;
    top: 20px;
    font-size: 48px;
    opacity: 0.2;
}
.stat-title {
    font-size: 14px;
    color: #6c757d;
    margin-bottom: 10px;
}
.stat-value {
    font-size: 32px;
    font-weight: bold;
    margin-bottom: 0;
}
.attendance-table {
    background: white;
    border-radius: 15px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    overflow: hidden;
}
.table-header {
    padding: 15px 20px;
    border-bottom: 1px solid #e9ecef;
    background: white;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.fade-in-up {
    animation: fadeInUp 0.5s ease-out;
}
@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}
.btn-primary {
    background-color: <?php echo $sidebar_color; ?>;
    border-color: <?php echo $sidebar_color; ?>;
}
.btn-primary:hover {
    background-color: <?php echo adjustBrightness($sidebar_color, -20); ?>;
    border-color: <?php echo adjustBrightness($sidebar_color, -20); ?>;
}
.btn-outline-primary {
    color: <?php echo $sidebar_color; ?>;
    border-color: <?php echo $sidebar_color; ?>;
}
.btn-outline-primary:hover {
    background-color: <?php echo $sidebar_color; ?>;
    border-color: <?php echo $sidebar_color; ?>;
}
.processing-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0,0,0,0.7);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 9999;
    display: none;
}
.processing-box {
    background: white;
    padding: 30px;
    border-radius: 15px;
    text-align: center;
    min-width: 300px;
}
.processing-spinner {
    width: 50px;
    height: 50px;
    border: 4px solid #f3f3f3;
    border-top: 4px solid <?php echo $sidebar_color; ?>;
    border-radius: 50%;
    animation: spin 1s linear infinite;
    margin: 0 auto 20px;
}
@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}
.result-toast {
    position: fixed;
    bottom: 20px;
    right: 20px;
    z-index: 10000;
    min-width: 300px;
    animation: slideIn 0.3s ease-out;
}
@keyframes slideIn {
    from {
        transform: translateX(100%);
        opacity: 0;
    }
    to {
        transform: translateX(0);
        opacity: 1;
    }
}
.action-buttons {
    display: flex;
    gap: 10px;
    margin-top: 10px;
}
.action-buttons .btn {
    flex: 1;
}
.attendance-info {
    background: #f8f9fa;
    border-radius: 10px;
    padding: 10px;
    margin-top: 10px;
}
.attendance-info p {
    margin-bottom: 5px;
}
</style>

<div class="p-4">
    <div class="welcome-banner fade-in-up">
        <div class="row align-items-center">
            <div class="col-md-8">
                <h1>Face Recognition Attendance</h1>
                <p>Select teacher and capture face photo - System will verify the captured face against the teacher's photo in database</p>
            </div>
            <div class="col-md-4 text-md-end">
                <div class="current-time-card">
                    <i class="bi bi-calendar-check me-2"></i>
                    <span id="current-date"></span><br>
                    <i class="bi bi-clock me-2"></i>
                    <span id="current-time" class="h5"></span>
                </div>
            </div>
        </div>
    </div>

    <div class="row mb-4">
        <div class="col-sm-6 col-lg-3 mb-3">
            <div class="stat-card fade-in-up">
                <div class="stat-icon"><i class="bi bi-person-check"></i></div>
                <div class="stat-title">Present Today</div>
                <div class="stat-value" id="present-count"><?php echo $present_count; ?></div>
            </div>
        </div>
        <div class="col-sm-6 col-lg-3 mb-3">
            <div class="stat-card fade-in-up">
                <div class="stat-icon"><i class="bi bi-person-x"></i></div>
                <div class="stat-title">Absent Today</div>
                <div class="stat-value" id="absent-count"><?php echo $absent_count; ?></div>
            </div>
        </div>
        <div class="col-sm-6 col-lg-3 mb-3">
            <div class="stat-card fade-in-up">
                <div class="stat-icon"><i class="bi bi-clock"></i></div>
                <div class="stat-title">Late Arrivals</div>
                <div class="stat-value" id="late-count"><?php echo $late_count; ?></div>
            </div>
        </div>
        <div class="col-sm-6 col-lg-3 mb-3">
            <div class="stat-card fade-in-up">
                <div class="stat-icon"><i class="bi bi-box-arrow-right"></i></div>
                <div class="stat-title">Checked Out</div>
                <div class="stat-value" id="checkedout-count"><?php echo $checked_out_count; ?></div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-6 mb-4">
            <div class="attendance-table fade-in-up">
                <div class="table-header">
                    <h5 class="mb-0"><i class="bi bi-person me-2"></i> Step 1: Select Teacher</h5>
                </div>
                <div class="p-3">
                    <select id="teacher-select" class="form-select mb-3" onchange="onTeacherSelected()">
                        <option value="">-- Select Teacher --</option>
                        <?php while($teacher = $teachers->fetch_object()): ?>
                        <option value="<?php echo $teacher->id; ?>" data-photo="<?php echo htmlspecialchars($teacher->photo); ?>" data-name="<?php echo htmlspecialchars($teacher->fullname); ?>">
                            <?php echo htmlspecialchars($teacher->fullname); ?> (<?php echo htmlspecialchars($teacher->subject ?? 'No Subject'); ?>)
                        </option>
                        <?php endwhile; ?>
                    </select>
                    
                    <div id="no-photo-warning" class="alert alert-warning" style="display: none;">
                        <i class="bi bi-exclamation-triangle-fill"></i> This teacher has no profile photo in database. Please upload one first for face verification.
                    </div>
                    
                    <!-- Selected Teacher Preview -->
                    <div id="selected-teacher-preview" style="display: none;" class="mt-3 text-center">
                        <img id="selected-teacher-photo" src="" style="width: 100px; height: 100px; border-radius: 50%; object-fit: cover; border: 2px solid <?php echo $sidebar_color; ?>;">
                        <div id="selected-teacher-name" class="mt-2 fw-bold"></div>
                        <div class="small text-muted">Database Photo (for verification)</div>
                    </div>
                    
                    <!-- Today's Status for Selected Teacher -->
                    <div id="today-status" style="display: none;" class="mt-3 attendance-info">
                        <p><i class="bi bi-info-circle-fill"></i> <strong>Today's Status:</strong></p>
                        <div id="teacher-attendance-status"></div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6 mb-4">
            <div class="attendance-table fade-in-up">
                <div class="table-header">
                    <h5 class="mb-0"><i class="bi bi-camera me-2"></i> Step 2: Take Action</h5>
                    <button class="btn btn-sm btn-outline-secondary" onclick="restartCamera()">
                        <i class="bi bi-arrow-repeat"></i> Restart Camera
                    </button>
                </div>
                <div class="p-3">
                    <div class="camera-container">
                        <div class="camera-wrapper">
                            <video id="video" autoplay playsinline muted></video>
                            <img id="captured-photo" alt="Captured">
                        </div>
                        <div id="camera-status" class="mt-2 text-center text-success">
                            <i class="bi bi-check-circle-fill"></i> Camera ready
                        </div>

                        <div id="action-buttons" class="action-buttons" style="display: none;">
                            <button class="btn btn-success" onclick="capturePhotoForCheckIn()" id="checkInBtn">
                                <i class="bi bi-box-arrow-in-right me-2"></i> Check In
                            </button>
                            <button class="btn btn-info" onclick="capturePhotoForCheckOut()" id="checkOutBtn">
                                <i class="bi bi-box-arrow-right me-2"></i> Check Out
                            </button>
                        </div>
                        
                        <div id="select-teacher-message" class="alert alert-info mt-3 text-center">
                            <i class="bi bi-info-circle-fill"></i> Please select a teacher first
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Auto Verification Result Section -->
    <div class="row" id="result-section" style="display: none;">
        <div class="col-12 mb-4">
            <div class="attendance-table fade-in-up">
                <div class="table-header">
                    <h5 class="mb-0"><i class="bi bi-check-circle me-2"></i> Face Verification Result</h5>
                </div>
                <div class="p-3">
                    <div id="verification-result" class="text-center"></div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row mt-4">
        <div class="col-12">
            <div class="attendance-table fade-in-up">
                <div class="table-header">
                    <h5 class="mb-0"><i class="bi bi-clock-history me-2"></i> Today's Attendance</h5>
                    <button class="btn btn-sm btn-outline-primary" onclick="loadAttendance()">
                        <i class="bi bi-arrow-repeat"></i> Refresh
                    </button>
                </div>
                <div class="p-3">
                    <div id="today-attendance" class="attendance-timeline">
                        <div class="text-center py-5">
                            <div class="spinner-border text-primary"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Processing Overlay -->
<div id="processing-overlay" class="processing-overlay">
    <div class="processing-box">
        <div class="processing-spinner"></div>
        <h5>Verifying Face Against Database...</h5>
        <p class="text-muted">Please wait while we compare the captured face with teacher's photo in database</p>
    </div>
</div>

<script>
let videoStream = null;
let capturedImageBlob = null;
let capturedImageDataUrl = null;
let selectedTeacherId = null;
let selectedTeacherName = null;
let selectedTeacherPhoto = null;
let currentAction = null; // 'checkin' or 'checkout'
let video = document.getElementById('video');
let capturedPhotoImg = document.getElementById('captured-photo');
let isProcessing = false;

// Start camera
async function startCamera() {
    try {
        if (videoStream) {
            videoStream.getTracks().forEach(track => track.stop());
        }
        
        videoStream = await navigator.mediaDevices.getUserMedia({ 
            video: { width: 640, height: 480, facingMode: "user" } 
        });
        
        video.srcObject = videoStream;
        await video.play();
        
        document.getElementById('camera-status').innerHTML = '<i class="bi bi-check-circle-fill text-success"></i> Camera ready';
        
    } catch (err) {
        document.getElementById('camera-status').innerHTML = '<i class="bi bi-exclamation-triangle-fill text-danger"></i> Camera error: ' + err.message;
        alert('Please allow camera access to use this feature');
    }
}

function restartCamera() {
    startCamera();
    resetCapture();
}

function resetCapture() {
    capturedImageBlob = null;
    capturedImageDataUrl = null;
    capturedPhotoImg.style.display = 'none';
    video.style.display = 'block';
    document.getElementById('camera-status').innerHTML = '<i class="bi bi-check-circle-fill text-success"></i> Camera ready';
    document.getElementById('result-section').style.display = 'none';
    currentAction = null;
}

async function onTeacherSelected() {
    const select = document.getElementById('teacher-select');
    const selectedOption = select.options[select.selectedIndex];
    
    if (!selectedOption.value) {
        selectedTeacherId = null;
        selectedTeacherName = null;
        selectedTeacherPhoto = null;
        document.getElementById('selected-teacher-preview').style.display = 'none';
        document.getElementById('no-photo-warning').style.display = 'none';
        document.getElementById('result-section').style.display = 'none';
        document.getElementById('today-status').style.display = 'none';
        document.getElementById('action-buttons').style.display = 'none';
        document.getElementById('select-teacher-message').style.display = 'block';
        return;
    }
    
    selectedTeacherId = selectedOption.value;
    selectedTeacherName = selectedOption.getAttribute('data-name');
    selectedTeacherPhoto = selectedOption.getAttribute('data-photo');
    
    // Show teacher preview
    if (selectedTeacherPhoto && selectedTeacherPhoto !== 'null' && selectedTeacherPhoto !== '') {
        let teacherPhotoUrl = selectedTeacherPhoto;
        if (!teacherPhotoUrl.startsWith('http') && !teacherPhotoUrl.startsWith('/')) {
            teacherPhotoUrl = '/' + teacherPhotoUrl;
        }
        document.getElementById('selected-teacher-photo').src = teacherPhotoUrl;
        document.getElementById('selected-teacher-name').innerHTML = selectedTeacherName;
        document.getElementById('selected-teacher-preview').style.display = 'block';
        document.getElementById('no-photo-warning').style.display = 'none';
    } else {
        document.getElementById('selected-teacher-preview').style.display = 'none';
        document.getElementById('no-photo-warning').style.display = 'block';
        document.getElementById('action-buttons').style.display = 'none';
        document.getElementById('select-teacher-message').style.display = 'block';
        return;
    }
    
    // Check today's status for this teacher
    await checkTeacherTodayStatus();
    
    document.getElementById('result-section').style.display = 'none';
    document.getElementById('select-teacher-message').style.display = 'none';
    document.getElementById('action-buttons').style.display = 'flex';
}

async function checkTeacherTodayStatus() {
    try {
        const response = await fetch(`api/get_teacher_today_status.php?teacher_id=${selectedTeacherId}`);
        const data = await response.json();
        
        const statusDiv = document.getElementById('teacher-attendance-status');
        const todayStatusDiv = document.getElementById('today-status');
        
        if (data.has_record) {
            let statusHtml = `
                <div class="alert alert-${data.check_out ? 'success' : 'warning'} mb-0">
                    <strong>Check In:</strong> ${data.check_in || 'Not checked in'}<br>
                    ${data.check_out ? `<strong>Check Out:</strong> ${data.check_out}<br>` : ''}
                    <strong>Status:</strong> ${data.status}<br>
                    ${!data.check_out && data.check_in ? '<span class="text-info"><i class="bi bi-info-circle"></i> Ready for check out</span>' : ''}
                    ${data.check_out ? '<span class="text-success"><i class="bi bi-check-circle"></i> Completed for today</span>' : ''}
                </div>
            `;
            statusDiv.innerHTML = statusHtml;
            todayStatusDiv.style.display = 'block';
            
            // Show/hide check-in/check-out buttons based on status
            const checkInBtn = document.getElementById('checkInBtn');
            const checkOutBtn = document.getElementById('checkOutBtn');
            
            if (data.check_out) {
                checkInBtn.disabled = true;
                checkOutBtn.disabled = true;
                checkInBtn.title = "Already checked out today";
                checkOutBtn.title = "Already checked out today";
            } else if (data.check_in) {
                checkInBtn.disabled = true;
                checkOutBtn.disabled = false;
                checkInBtn.title = "Already checked in today";
                checkOutBtn.title = "Check out now";
            } else {
                checkInBtn.disabled = false;
                checkOutBtn.disabled = true;
                checkInBtn.title = "Check in now";
                checkOutBtn.title = "Check in first";
            }
        } else {
            statusDiv.innerHTML = '<div class="alert alert-info mb-0">No attendance record for today. Ready for check in.</div>';
            todayStatusDiv.style.display = 'block';
            document.getElementById('checkInBtn').disabled = false;
            document.getElementById('checkOutBtn').disabled = true;
        }
    } catch (err) {
        console.error('Error checking status:', err);
    }
}

// Capture face photo for check-in
async function capturePhotoForCheckIn() {
    if (isProcessing) return;
    
    if (!selectedTeacherId) {
        showToast('Please select a teacher first', 'warning');
        return;
    }
    
    if (!selectedTeacherPhoto || selectedTeacherPhoto === 'null' || selectedTeacherPhoto === '') {
        showToast('Teacher has no profile photo in database. Cannot verify face.', 'danger');
        return;
    }
    
    currentAction = 'checkin';
    await captureAndVerify();
}

// Capture face photo for check-out
async function capturePhotoForCheckOut() {
    if (isProcessing) return;
    
    if (!selectedTeacherId) {
        showToast('Please select a teacher first', 'warning');
        return;
    }
    
    if (!selectedTeacherPhoto || selectedTeacherPhoto === 'null' || selectedTeacherPhoto === '') {
        showToast('Teacher has no profile photo in database. Cannot verify face.', 'danger');
        return;
    }
    
    currentAction = 'checkout';
    await captureAndVerify();
}

async function captureAndVerify() {
    // Capture face photo from video
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const context = canvas.getContext('2d');
    context.drawImage(video, 0, 0, canvas.width, canvas.height);
    
    // Get image data URL
    capturedImageDataUrl = canvas.toDataURL('image/jpeg', 0.9);
    
    // Convert to blob using promise
    capturedImageBlob = await new Promise((resolve) => {
        canvas.toBlob((blob) => {
            resolve(blob);
        }, 'image/jpeg', 0.9);
    });
    
    // Show captured face photo
    capturedPhotoImg.src = capturedImageDataUrl;
    capturedPhotoImg.style.display = 'block';
    video.style.display = 'none';
    
    // Auto-verify captured face against database
    await autoVerifyAndMarkAttendance();
}

async function autoVerifyAndMarkAttendance() {
    if (isProcessing) return;
    isProcessing = true;
    
    // Check if blob is valid
    if (!capturedImageBlob || !(capturedImageBlob instanceof Blob)) {
        showToast('Error: Invalid captured face image. Please retake photo.', 'danger');
        isProcessing = false;
        return;
    }
    
    // Show processing overlay
    document.getElementById('processing-overlay').style.display = 'flex';
    document.getElementById('result-section').style.display = 'none';
    
    const formData = new FormData();
    formData.append('teacher_id', selectedTeacherId);
    formData.append('face_image', capturedImageBlob, 'captured_face_' + Date.now() + '.jpg');
    formData.append('teacher_photo', selectedTeacherPhoto);
    formData.append('action', currentAction);
    
    try {
        const response = await fetch('api/mark_attendance_auto.php', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        // Hide processing overlay
        document.getElementById('processing-overlay').style.display = 'none';
        
        // Show result
        displayResult(data);
        
        if (data.success) {
            showToast(`${currentAction === 'checkin' ? 'Check-in' : 'Check-out'} successful for ${data.teacher_name}!`, 'success');
            // Refresh attendance list and stats
            loadAttendance();
            updateStats();
            await checkTeacherTodayStatus();
            // Reset after successful marking
            setTimeout(() => {
                resetForm();
            }, 3000);
        } else {
            showToast(data.message, 'danger');
        }
        
    } catch (error) {
        console.error('Error:', error);
        document.getElementById('processing-overlay').style.display = 'none';
        showToast('Error: ' + error.message, 'danger');
        displayResult({ success: false, message: error.message });
    } finally {
        isProcessing = false;
    }
}

function displayResult(data) {
    const resultDiv = document.getElementById('verification-result');
    const resultSection = document.getElementById('result-section');
    
    if (data.success) {
        const matchScoreClass = data.match_score >= 80 ? 'high' : (data.match_score >= 60 ? 'medium' : 'low');
        resultDiv.innerHTML = `
            <div class="alert alert-success">
                <i class="bi bi-check-circle-fill" style="font-size: 24px;"></i>
                <h4 class="mt-2">Face Verified Successfully!</h4>
                <p><strong>Teacher:</strong> ${escapeHtml(data.teacher_name)}</p>
                <p><strong>Action:</strong> ${data.action === 'checkin' ? 'Check In' : 'Check Out'} | <strong>Time:</strong> ${data.time}</p>
                <p><strong>Status:</strong> ${data.status}</p>
                <p><strong>Face Match Score:</strong> <span class="match-badge ${matchScoreClass}">${data.match_score}%</span></p>
                <p class="text-muted small mt-2">Captured face photo has been saved for reference. Face matched with database photo at ${data.match_score}% confidence.</p>
            </div>
        `;
    } else {
        resultDiv.innerHTML = `
            <div class="alert alert-danger">
                <i class="bi bi-x-circle-fill" style="font-size: 24px;"></i>
                <h4 class="mt-2">Face Verification Failed</h4>
                <p>${escapeHtml(data.message)}</p>
                ${data.match_score ? `<p><strong>Face Match Score:</strong> ${data.match_score}% (Threshold: 70% required)</p>` : ''}
                <p class="text-muted">The captured face does not match the teacher's photo in database.</p>
                <button class="btn btn-outline-primary mt-2" onclick="retakePhoto()">
                    <i class="bi bi-camera"></i> Retake Face Photo
                </button>
            </div>
        `;
    }
    
    resultSection.style.display = 'block';
    resultSection.scrollIntoView({ behavior: 'smooth' });
}

function retakePhoto() {
    resetCapture();
    document.getElementById('result-section').style.display = 'none';
}

function resetForm() {
    document.getElementById('teacher-select').value = '';
    selectedTeacherId = null;
    selectedTeacherName = null;
    selectedTeacherPhoto = null;
    document.getElementById('selected-teacher-preview').style.display = 'none';
    document.getElementById('no-photo-warning').style.display = 'none';
    document.getElementById('today-status').style.display = 'none';
    document.getElementById('action-buttons').style.display = 'none';
    document.getElementById('select-teacher-message').style.display = 'block';
    resetCapture();
    document.getElementById('result-section').style.display = 'none';
}

function showToast(message, type) {
    const toast = document.createElement('div');
    toast.className = `result-toast alert alert-${type}`;
    toast.innerHTML = `
        <i class="bi bi-${type === 'success' ? 'check-circle-fill' : (type === 'danger' ? 'exclamation-triangle-fill' : 'info-circle-fill')} me-2"></i>
        ${escapeHtml(message)}
    `;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.style.animation = 'slideOut 0.3s ease-out forwards';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// Load today's attendance with captured face images
async function loadAttendance() {
    try {
        const response = await fetch('api/fetch_attendance.php?today=1&details=1');
        const data = await response.json();
        const container = document.getElementById('today-attendance');
        
        if (data.success && data.attendance && data.attendance.length > 0) {
            let html = '';
            data.attendance.forEach(record => {
                const statusClass = record.status.toLowerCase();
                const capturedImage = record.captured_image || null;
                const hasImage = capturedImage && capturedImage !== '';
                const imagePath = hasImage ? '/' + capturedImage : '';
                const hasCheckOut = record.check_out && record.check_out !== '00:00:00';
                
                html += `
                    <div class="timeline-item ${statusClass} mb-3">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <strong>${escapeHtml(record.fullname)}</strong>
                                ${hasImage ? `<button class="btn btn-sm btn-link p-0 ms-2" onclick="viewCapturedImage('${imagePath}', '${escapeHtml(record.fullname)}')" title="View captured face photo"><i class="bi bi-camera"></i> View Captured Face</button>` : ''}
                            </div>
                            <span class="status-badge ${statusClass}">${record.status}</span>
                        </div>
                        <div class="timeline-time">
                            <i class="bi bi-box-arrow-in-right"></i> Check In: ${record.check_in || '--:--'}
                            ${hasCheckOut ? `<br><i class="bi bi-box-arrow-right"></i> Check Out: ${record.check_out}` : ''}
                        </div>
                        ${hasImage ? '<div class="small text-muted mt-1"><i class="bi bi-person-bounding-box"></i> Face photo captured and verified</div>' : ''}
                    </div>
                `;
            });
            container.innerHTML = html;
        } else {
            container.innerHTML = '<div class="text-center py-5"><i class="bi bi-calendar-x" style="font-size: 48px; color: #ccc;"></i><p class="mt-3">No attendance records today</p></div>';
        }
    } catch (err) {
        console.error('Error loading attendance:', err);
        container.innerHTML = '<div class="alert alert-danger">Error loading data</div>';
    }
}

function viewCapturedImage(imagePath, teacherName) {
    const modalHtml = `
        <div class="modal fade" id="imageModal" tabindex="-1">
            <div class="modal-dialog modal-lg modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Captured Face Photo - ${teacherName}</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body text-center">
                        <img src="${imagePath}" class="img-fluid" alt="Captured face photo">
                        <p class="text-muted mt-2">This face photo was captured during attendance and verified against database</p>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    const existingModal = document.getElementById('imageModal');
    if (existingModal) existingModal.remove();
    
    document.body.insertAdjacentHTML('beforeend', modalHtml);
    const modal = new bootstrap.Modal(document.getElementById('imageModal'));
    modal.show();
    
    document.getElementById('imageModal').addEventListener('hidden.bs.modal', function() {
        this.remove();
    });
}

async function updateStats() {
    try {
        const response = await fetch('api/fetch_attendance.php?today=1');
        const data = await response.json();
        if (data.success) {
            document.getElementById('present-count').textContent = data.present_count || 0;
            document.getElementById('absent-count').textContent = data.absent_count || 0;
            document.getElementById('late-count').textContent = data.late_count || 0;
            document.getElementById('checkedout-count').textContent = data.checked_out_count || 0;
        }
    } catch (err) {
        console.error('Error updating stats:', err);
    }
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function updateDateTime() {
    const now = new Date();
    document.getElementById('current-date').textContent = now.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
    document.getElementById('current-time').textContent = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
}

// Add slideOut animation
const style = document.createElement('style');
style.textContent = `
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

// Initialize
startCamera();
loadAttendance();
updateDateTime();
setInterval(updateDateTime, 1000);
setInterval(loadAttendance, 30000);
setInterval(updateStats, 30000);
</script>

<?php require_once 'includes/footer.php'; ?>