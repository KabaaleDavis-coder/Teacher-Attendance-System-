<?php
require_once 'includes/header.php';
requireAdmin();

// Define adjustBrightness function if not already defined
if (!function_exists('adjustBrightness')) {
    function adjustBrightness($hex, $percent) {
        $hex = ltrim($hex, '#');
        $r = hexdec(substr($hex, 0, 2));
        $g = hexdec(substr($hex, 2, 2));
        $b = hexdec(substr($hex, 4, 2));
        
        $r = max(0, min(255, $r + $percent));
        $g = max(0, min(255, $g + $percent));
        $b = max(0, min(255, $b + $percent));
        
        return sprintf("#%02x%02x%02x", $r, $g, $b);
    }
}

$settings_sql = $mysqli->prepare("SELECT * FROM system_settings LIMIT 1");
$settings_sql->execute();
$current_settings = $settings_sql->get_result()->fetch_object();

$success = '';
$error = '';

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $system_name = mysqli_real_escape_string($mysqli, $_POST['system_name']);
    $sidebar_color = mysqli_real_escape_string($mysqli, $_POST['sidebar_color']);
    $font_family = mysqli_real_escape_string($mysqli, $_POST['font_family']);
    $font_size = mysqli_real_escape_string($mysqli, $_POST['font_size']);

    $update_stmt = $mysqli->prepare("UPDATE system_settings SET system_name = ?, sidebar_color = ?, font_family = ?, font_size = ? WHERE id = 1");
    $update_stmt->bind_param("ssss", $system_name, $sidebar_color, $font_family, $font_size);

    if($update_stmt->execute()){
        $success = "Settings updated successfully!";
        // Refresh settings after update
        $settings_sql->execute();
        $current_settings = $settings_sql->get_result()->fetch_object();
    } else {
        $error = "Failed to update settings";
    }
}

$sidebar_color = $current_settings->sidebar_color ?? '#2c3e50';
?>

<style>
.settings-card {
    background: white;
    border-radius: 20px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    overflow: hidden;
    margin-bottom: 25px;
}
.settings-header {
    padding: 20px 25px;
    background: linear-gradient(135deg, <?php echo $sidebar_color; ?> 0%, <?php echo adjustBrightness($sidebar_color, 40); ?> 100%);
    color: white;
}
.settings-body {
    padding: 25px;
}
.preview-card {
    background: white;
    border-radius: 20px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    overflow: hidden;
    position: sticky;
    top: 20px;
}
.preview-header {
    padding: 15px 20px;
    background: #f8f9fa;
    border-bottom: 1px solid #e9ecef;
}
.preview-content {
    padding: 20px;
}
.live-preview-sidebar {
    background: <?php echo $sidebar_color; ?>;
    border-radius: 12px;
    padding: 15px;
    color: white;
    margin-bottom: 15px;
}
.live-preview-sidebar .nav-item {
    padding: 8px 12px;
    margin: 5px 0;
    border-radius: 8px;
    background: rgba(255,255,255,0.1);
}
.live-preview-card {
    background: white;
    border-radius: 12px;
    padding: 15px;
    box-shadow: 0 2px 5px rgba(0,0,0,0.05);
    margin-bottom: 15px;
    font-family: <?php echo $current_settings->font_family ?? 'Arial'; ?>;
    font-size: <?php echo $current_settings->font_size ?? '14px'; ?>;
}
.color-preview {
    width: 40px;
    height: 40px;
    border-radius: 8px;
    border: 2px solid #e9ecef;
    display: inline-block;
    vertical-align: middle;
    margin-left: 10px;
}
.font-preview {
    padding: 10px;
    background: #f8f9fa;
    border-radius: 8px;
    margin-top: 5px;
}
.welcome-banner {
    background: linear-gradient(135deg, <?php echo $sidebar_color; ?> 0%, <?php echo adjustBrightness($sidebar_color, 40); ?> 100%);
    color: white;
    padding: 25px;
    border-radius: 15px;
    margin-bottom: 25px;
}
.stat-card {
    background: white;
    border-radius: 15px;
    padding: 20px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    position: relative;
    overflow: hidden;
    transition: transform 0.3s;
}
.stat-card:hover {
    transform: translateY(-5px);
}
.stat-icon {
    position: absolute;
    right: 20px;
    top: 20px;
    font-size: 48px;
    opacity: 0.2;
}
.stat-title {
    font-size: 14px;
    color: #6c757d;
    margin-bottom: 10px;
}
.stat-value {
    font-size: 32px;
    font-weight: bold;
    margin-bottom: 0;
}
.fade-in-up {
    animation: fadeInUp 0.5s ease-out;
}
@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}
.form-control, .form-select {
    border-radius: 10px;
    border: 1px solid #e9ecef;
    padding: 10px 15px;
}
.form-control:focus, .form-select:focus {
    border-color: <?php echo $sidebar_color; ?>;
    box-shadow: 0 0 0 0.2rem rgba(<?php echo hexdec(substr($sidebar_color, 1, 2)); ?>, <?php echo hexdec(substr($sidebar_color, 3, 2)); ?>, <?php echo hexdec(substr($sidebar_color, 5, 2)); ?>, 0.25);
}
.btn-primary {
    background-color: <?php echo $sidebar_color; ?>;
    border-color: <?php echo $sidebar_color; ?>;
    border-radius: 10px;
    padding: 10px 25px;
}
.btn-primary:hover {
    background-color: <?php echo adjustBrightness($sidebar_color, -20); ?>;
    border-color: <?php echo adjustBrightness($sidebar_color, -20); ?>;
}
.btn-secondary {
    border-radius: 10px;
    padding: 10px 25px;
}
</style>

<div class="p-4">
    <div class="welcome-banner fade-in-up">
        <div class="row align-items-center">
            <div class="col-md-8">
                <h1>System Settings</h1>
                <p>Configure your attendance system appearance and preferences</p>
            </div>
            <div class="col-md-4 text-md-end">
                <i class="bi bi-gear-fill" style="font-size: 48px;"></i>
            </div>
        </div>
    </div>

    <?php if($success): ?>
    <div class="alert alert-success alert-dismissible fade show fade-in-up" role="alert">
        <i class="bi bi-check-circle-fill me-2"></i> <?php echo htmlspecialchars($success); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <?php if($error): ?>
    <div class="alert alert-danger alert-dismissible fade show fade-in-up" role="alert">
        <i class="bi bi-exclamation-triangle-fill me-2"></i> <?php echo htmlspecialchars($error); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <div class="row">
        <!-- Settings Form -->
        <div class="col-lg-7 mb-4">
            <div class="settings-card fade-in-up" style="animation-delay: 0.1s">
                <div class="settings-header">
                    <h5 class="mb-0"><i class="bi bi-sliders2 me-2"></i> Configuration Settings</h5>
                </div>
                <div class="settings-body">
                    <form method="POST" action="" id="settingsForm">
                        <div class="mb-4">
                            <label class="form-label fw-bold">
                                <i class="bi bi-building me-2"></i> System Name
                            </label>
                            <input type="text" class="form-control" name="system_name" 
                                   value="<?php echo htmlspecialchars($current_settings->system_name); ?>" 
                                   required id="systemName">
                            <small class="text-muted">This name appears in the browser tab and header</small>
                        </div>

                        <div class="mb-4">
                            <label class="form-label fw-bold">
                                <i class="bi bi-palette me-2"></i> Sidebar Color
                            </label>
                            <div class="input-group">
                                <input type="color" class="form-control form-control-color" 
                                       name="sidebar_color" value="<?php echo htmlspecialchars($current_settings->sidebar_color); ?>" 
                                       required id="sidebarColor" style="width: 60px; padding: 5px;">
                                <input type="text" class="form-control" id="sidebarColorHex" 
                                       value="<?php echo htmlspecialchars($current_settings->sidebar_color); ?>" 
                                       readonly>
                            </div>
                            <small class="text-muted">Choose a color for the sidebar and primary buttons</small>
                            <div class="mt-2">
                                <span class="badge bg-secondary">Preview:</span>
                                <div class="color-preview" style="background: <?php echo $current_settings->sidebar_color; ?>;"></div>
                            </div>
                        </div>

                        <div class="mb-4">
                            <label class="form-label fw-bold">
                                <i class="bi bi-type me-2"></i> Font Family
                            </label>
                            <select class="form-select" name="font_family" required id="fontFamily">
                                <option value="Arial" <?php echo $current_settings->font_family == 'Arial' ? 'selected' : ''; ?>>Arial</option>
                                <option value="Helvetica" <?php echo $current_settings->font_family == 'Helvetica' ? 'selected' : ''; ?>>Helvetica</option>
                                <option value="Times New Roman" <?php echo $current_settings->font_family == 'Times New Roman' ? 'selected' : ''; ?>>Times New Roman</option>
                                <option value="Courier New" <?php echo $current_settings->font_family == 'Courier New' ? 'selected' : ''; ?>>Courier New</option>
                                <option value="Verdana" <?php echo $current_settings->font_family == 'Verdana' ? 'selected' : ''; ?>>Verdana</option>
                                <option value="Georgia" <?php echo $current_settings->font_family == 'Georgia' ? 'selected' : ''; ?>>Georgia</option>
                                <option value="'Segoe UI'" <?php echo $current_settings->font_family == "'Segoe UI'" ? 'selected' : ''; ?>>Segoe UI</option>
                                <option value="'Inter', sans-serif" <?php echo $current_settings->font_family == "'Inter', sans-serif" ? 'selected' : ''; ?>>Inter (Modern)</option>
                            </select>
                            <div class="font-preview mt-2" id="fontPreview" style="font-family: <?php echo $current_settings->font_family; ?>;">
                                The quick brown fox jumps over the lazy dog. 1234567890
                            </div>
                            <small class="text-muted">Choose a font for the entire system</small>
                        </div>

                        <div class="mb-4">
                            <label class="form-label fw-bold">
                                <i class="bi bi-textarea-resize me-2"></i> Font Size
                            </label>
                            <select class="form-select" name="font_size" required id="fontSize">
                                <option value="12px" <?php echo $current_settings->font_size == '12px' ? 'selected' : ''; ?>>12px - Small</option>
                                <option value="14px" <?php echo $current_settings->font_size == '14px' ? 'selected' : ''; ?>>14px - Normal</option>
                                <option value="16px" <?php echo $current_settings->font_size == '16px' ? 'selected' : ''; ?>>16px - Large</option>
                                <option value="18px" <?php echo $current_settings->font_size == '18px' ? 'selected' : ''; ?>>18px - Extra Large</option>
                            </select>
                            <div class="mt-2" id="sizePreview" style="font-size: <?php echo $current_settings->font_size; ?>;">
                                Sample text at this size
                            </div>
                            <small class="text-muted">Choose the base font size for the system</small>
                        </div>

                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-primary">
                                <i class="bi bi-save me-2"></i> Save Settings
                            </button>
                            <button type="button" class="btn btn-secondary" onclick="resetToDefault()">
                                <i class="bi bi-arrow-repeat me-2"></i> Reset to Default
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Live Preview -->
        <div class="col-lg-5 mb-4">
            <div class="preview-card fade-in-up" style="animation-delay: 0.2s">
                <div class="preview-header">
                    <h5 class="mb-0"><i class="bi bi-eye me-2"></i> Live Preview</h5>
                    <small class="text-muted">See your changes in real-time</small>
                </div>
                <div class="preview-content" id="livePreview">
                    <div class="live-preview-sidebar" id="previewSidebar">
                        <div class="mb-3">
                            <strong id="previewSystemName"><?php echo htmlspecialchars($current_settings->system_name); ?></strong>
                        </div>
                        <div class="nav-item">
                            <i class="bi bi-speedometer2 me-2"></i> Dashboard
                        </div>
                        <div class="nav-item">
                            <i class="bi bi-people me-2"></i> Teachers
                        </div>
                        <div class="nav-item">
                            <i class="bi bi-calendar-check me-2"></i> Attendance
                        </div>
                        <div class="nav-item">
                            <i class="bi bi-gear me-2"></i> Settings
                        </div>
                    </div>
                    
                    <div class="live-preview-card" id="previewCard">
                        <h6>Sample Card Title</h6>
                        <p>This is how your content will appear with the selected settings. The sidebar color, font family, and font size will be applied throughout the system.</p>
                        <div class="d-flex gap-2">
                            <button class="btn btn-sm" id="previewButton" style="background: <?php echo $sidebar_color; ?>; color: white; border: none; border-radius: 6px; padding: 5px 12px;">
                                Sample Button
                            </button>
                            <button class="btn btn-sm btn-outline-secondary">Secondary</button>
                        </div>
                    </div>
                    
                    <div class="live-preview-card">
                        <div class="row">
                            <div class="col-6">
                                <div class="text-center">
                                    <h3>85%</h3>
                                    <small>Attendance Rate</small>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="text-center">
                                    <h3>24</h3>
                                    <small>Present Today</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Additional Settings Section -->
    <div class="row mt-3">
        <div class="col-12">
            <div class="settings-card fade-in-up" style="animation-delay: 0.3s">
                <div class="settings-header">
                    <h5 class="mb-0"><i class="bi bi-info-circle me-2"></i> System Information</h5>
                </div>
                <div class="settings-body">
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <div class="stat-card">
                                <div class="stat-icon"><i class="bi bi-database"></i></div>
                                <div class="stat-title">Database Version</div>
                                <div class="stat-value h5">MySQL <?php echo $mysqli->server_info; ?></div>
                            </div>
                        </div>
                        <div class="col-md-4 mb-3">
                            <div class="stat-card">
                                <div class="stat-icon"><i class="bi bi-people"></i></div>
                                <div class="stat-title">Total Teachers</div>
                                <?php 
                                $count_sql = $mysqli->query("SELECT COUNT(*) as count FROM teachers");
                                $teacher_count = $count_sql->fetch_object()->count ?? 0;
                                ?>
                                <div class="stat-value h5"><?php echo $teacher_count; ?> Teachers</div>
                            </div>
                        </div>
                        <div class="col-md-4 mb-3">
                            <div class="stat-card">
                                <div class="stat-icon"><i class="bi bi-calendar-check"></i></div>
                                <div class="stat-title">PHP Version</div>
                                <div class="stat-value h5"><?php echo phpversion(); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Live preview functionality
const systemNameInput = document.getElementById('systemName');
const sidebarColorInput = document.getElementById('sidebarColor');
const sidebarColorHex = document.getElementById('sidebarColorHex');
const fontFamilySelect = document.getElementById('fontFamily');
const fontSizeSelect = document.getElementById('fontSize');

const previewSidebar = document.getElementById('previewSidebar');
const previewSystemName = document.getElementById('previewSystemName');
const previewCard = document.getElementById('previewCard');
const previewButton = document.getElementById('previewButton');
const fontPreview = document.getElementById('fontPreview');
const sizePreview = document.getElementById('sizePreview');

function updatePreview() {
    // Update sidebar color
    const color = sidebarColorInput.value;
    previewSidebar.style.background = color;
    previewButton.style.background = color;
    sidebarColorHex.value = color;
    
    // Update system name
    previewSystemName.textContent = systemNameInput.value || 'Teacher Attendance System';
    
    // Update font family
    const fontFamily = fontFamilySelect.value;
    previewCard.style.fontFamily = fontFamily;
    fontPreview.style.fontFamily = fontFamily;
    
    // Update font size
    const fontSize = fontSizeSelect.value;
    previewCard.style.fontSize = fontSize;
    fontPreview.style.fontSize = fontSize;
    sizePreview.style.fontSize = fontSize;
}

// Add event listeners
if(systemNameInput) systemNameInput.addEventListener('input', updatePreview);
if(sidebarColorInput) sidebarColorInput.addEventListener('input', updatePreview);
if(fontFamilySelect) fontFamilySelect.addEventListener('change', updatePreview);
if(fontSizeSelect) fontSizeSelect.addEventListener('change', updatePreview);

// Reset to default settings
function resetToDefault() {
    if(confirm('Reset all settings to default values?')) {
        systemNameInput.value = 'Teacher Attendance System';
        sidebarColorInput.value = '#2c3e50';
        fontFamilySelect.value = 'Inter, sans-serif';
        fontSizeSelect.value = '14px';
        updatePreview();
        
        // Optional: Submit form with default values
        document.getElementById('settingsForm').submit();
    }
}

// Color picker hex display
if(sidebarColorInput && sidebarColorHex) {
    sidebarColorInput.addEventListener('input', function() {
        sidebarColorHex.value = this.value;
    });
}

// Initialize preview
updatePreview();
</script>

<?php require_once 'includes/footer.php'; ?>