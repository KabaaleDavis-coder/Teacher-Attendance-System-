<?php
require_once 'includes/header.php';
requireLogin();
requireAdmin(); // This will check for admin role and redirect if not admin

// Define adjustBrightness function
if (!function_exists('adjustBrightness')) {
    function adjustBrightness($hex, $percent) {
        $hex = ltrim($hex, '#');
        $r = hexdec(substr($hex, 0, 2));
        $g = hexdec(substr($hex, 2, 2));
        $b = hexdec(substr($hex, 4, 2));
        
        $r = max(0, min(255, $r + $percent));
        $g = max(0, min(255, $g + $percent));
        $b = max(0, min(255, $b + $percent));
        
        return sprintf("#%02x%02x%02x", $r, $g, $b);
    }
}

$sidebar_color = $settings->sidebar_color ?? '#2c3e50';
?>

<style>
.verification-container {
    background: #f8f9fa;
    border-radius: 10px;
    padding: 20px;
    border: 1px solid #e9ecef;
}
.photo-comparison {
    display: flex;
    justify-content: space-around;
    align-items: center;
    gap: 20px;
    flex-wrap: wrap;
}
.photo-box {
    text-align: center;
    flex: 1;
    min-width: 200px;
}
.photo-box img {
    width: 200px;
    height: 200px;
    border-radius: 10px;
    object-fit: cover;
    border: 3px solid <?php echo $sidebar_color; ?>;
    margin-bottom: 10px;
    background: #fff;
}
.photo-box .label {
    font-size: 14px;
    color: #6c757d;
    margin-top: 5px;
    font-weight: 500;
}
.photo-box .teacher-name {
    font-weight: bold;
    color: #333;
    margin-top: 8px;
}
.match-score-card {
    background: white;
    border-radius: 10px;
    padding: 15px;
    margin-top: 20px;
    text-align: center;
}
.match-score {
    font-size: 48px;
    font-weight: bold;
    margin: 10px 0;
}
.match-score.high { color: #28a745; }
.match-score.medium { color: #ffc107; }
.match-score.low { color: #dc3545; }
.status-badge {
    display: inline-block;
    padding: 5px 15px;
    border-radius: 20px;
    font-size: 14px;
    font-weight: 500;
}
.status-badge.verified { background: #d4edda; color: #155724; }
.status-badge.unverified { background: #f8d7da; color: #721c24; }
.status-badge.overridden { background: #fff3cd; color: #856404; }
.status-badge.present { background: #d4edda; color: #155724; }
.status-badge.absent { background: #f8d7da; color: #721c24; }
.status-badge.late { background: #fff3cd; color: #856404; }
.btn-override {
    background-color: #ffc107;
    border-color: #ffc107;
    color: #000;
}
.btn-override:hover {
    background-color: #e0a800;
    border-color: #e0a800;
}
.btn-correct {
    background-color: #28a745;
    border-color: #28a745;
}
.attendance-table {
    background: white;
    border-radius: 15px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    overflow: hidden;
}
.table-header {
    padding: 15px 20px;
    border-bottom: 1px solid #e9ecef;
    background: white;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.filter-bar {
    background: white;
    padding: 15px 20px;
    border-radius: 10px;
    margin-bottom: 20px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.05);
}
.verification-detail {
    background: #f8f9fa;
    border-radius: 10px;
    padding: 15px;
    margin-top: 15px;
}
.verification-detail .row {
    margin-bottom: 10px;
}
.admin-notes {
    width: 100%;
    padding: 8px;
    border: 1px solid #ddd;
    border-radius: 5px;
    resize: vertical;
}
.loading-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0,0,0,0.7);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 9999;
    display: none;
}
.loading-box {
    background: white;
    padding: 30px;
    border-radius: 15px;
    text-align: center;
    min-width: 300px;
}
.loading-spinner {
    width: 50px;
    height: 50px;
    border: 4px solid #f3f3f3;
    border-top: 4px solid <?php echo $sidebar_color; ?>;
    border-radius: 50%;
    animation: spin 1s linear infinite;
    margin: 0 auto 20px;
}
@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}
.result-toast {
    position: fixed;
    bottom: 20px;
    right: 20px;
    z-index: 10000;
    min-width: 300px;
    animation: slideIn 0.3s ease-out;
}
@keyframes slideIn {
    from {
        transform: translateX(100%);
        opacity: 0;
    }
    to {
        transform: translateX(0);
        opacity: 1;
    }
}
.btn-primary {
    background-color: <?php echo $sidebar_color; ?>;
    border-color: <?php echo $sidebar_color; ?>;
}
.btn-primary:hover {
    background-color: <?php echo adjustBrightness($sidebar_color, -20); ?>;
    border-color: <?php echo adjustBrightness($sidebar_color, -20); ?>;
}
.fade-in-up {
    animation: fadeInUp 0.5s ease-out;
}
@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}
.welcome-banner {
    background: linear-gradient(135deg, <?php echo $sidebar_color; ?> 0%, <?php echo adjustBrightness($sidebar_color, 40); ?> 100%);
    color: white;
    padding: 25px;
    border-radius: 15px;
    margin-bottom: 25px;
}
.stat-card {
    background: white;
    border-radius: 15px;
    padding: 20px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.05);
}
.stat-value {
    font-size: 32px;
    font-weight: bold;
    margin-bottom: 5px;
}
.stat-title {
    font-size: 14px;
    color: #6c757d;
}
.table th {
    background: #f8f9fa;
    font-weight: 600;
}
.checkout-time {
    font-size: 12px;
    color: #6c757d;
}
.duration-badge {
    background: #e9ecef;
    padding: 2px 8px;
    border-radius: 12px;
    font-size: 11px;
    display: inline-block;
    margin-top: 4px;
}
</style>

<div class="p-4">
    <div class="welcome-banner fade-in-up">
        <div class="row align-items-center">
            <div class="col-md-8">
                <h1><i class="bi bi-shield-check"></i> Face Verification Management</h1>
                <p>Compare scanned attendance images with teacher database photos. Verify or override mismatches.</p>
            </div>
            <div class="col-md-4 text-md-end">
                <div class="current-time-card" style="background: rgba(255,255,255,0.2); padding: 10px 15px; border-radius: 10px; display: inline-block;">
                    <i class="bi bi-calendar-check me-2"></i>
                    <span id="current-date"></span><br>
                    <i class="bi bi-clock me-2"></i>
                    <span id="current-time" class="h5"></span>
                </div>
            </div>
        </div>
    </div>

    <!-- Filter Bar -->
    <div class="filter-bar fade-in-up">
        <div class="row">
            <div class="col-md-3 mb-2">
                <label class="form-label">Filter by Status</label>
                <select id="filter-status" class="form-select" onchange="loadUnverifiedAttendances()">
                    <option value="all">All Records</option>
                    <option value="unverified">Unverified (Low Match Score)</option>
                    <option value="verified">Verified</option>
                    <option value="overridden">Admin Overridden</option>
                </select>
            </div>
            <div class="col-md-3 mb-2">
                <label class="form-label">Filter by Attendance</label>
                <select id="filter-attendance" class="form-select" onchange="loadUnverifiedAttendances()">
                    <option value="all">All Attendance</option>
                    <option value="present">Present</option>
                    <option value="absent">Absent</option>
                    <option value="late">Late</option>
                </select>
            </div>
            <div class="col-md-3 mb-2">
                <label class="form-label">Select Teacher</label>
                <select id="filter-teacher" class="form-select" onchange="loadUnverifiedAttendances()">
                    <option value="">All Teachers</option>
                </select>
            </div>
            <div class="col-md-3 mb-2">
                <label class="form-label">Date Range</label>
                <input type="date" id="filter-date" class="form-control" onchange="loadUnverifiedAttendances()">
            </div>
        </div>
        <div class="row mt-2">
            <div class="col-12 text-end">
                <button class="btn btn-primary" onclick="loadUnverifiedAttendances()">
                    <i class="bi bi-search"></i> Search
                </button>
                <button class="btn btn-secondary" onclick="resetFilters()">
                    <i class="bi bi-arrow-repeat"></i> Reset
                </button>
            </div>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="row mb-4" id="stats-cards">
        <div class="col-md-3 mb-3">
            <div class="stat-card">
                <div class="stat-value" id="total-records">0</div>
                <div class="stat-title">Total Records</div>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="stat-card">
                <div class="stat-value text-warning" id="unverified-count">0</div>
                <div class="stat-title">Needs Verification</div>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="stat-card">
                <div class="stat-value text-success" id="verified-count">0</div>
                <div class="stat-title">Verified</div>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="stat-card">
                <div class="stat-value text-info" id="overridden-count">0</div>
                <div class="stat-title">Admin Overridden</div>
            </div>
        </div>
    </div>

    <!-- Attendance Records List -->
    <div class="attendance-table fade-in-up">
        <div class="table-header">
            <h5 class="mb-0"><i class="bi bi-list-check"></i> Attendance Records for Verification</h5>
            <button class="btn btn-sm btn-outline-primary" onclick="loadUnverifiedAttendances()">
                <i class="bi bi-arrow-repeat"></i> Refresh
            </button>
        </div>
        <div class="p-0">
            <div id="attendance-list" class="p-3">
                <div class="text-center py-5">
                    <div class="spinner-border text-primary"></div>
                    <p class="mt-2">Loading records...</p>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Verification Modal -->
<div class="modal fade" id="verificationModal" tabindex="-1" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="bi bi-shield-check"></i> Face Verification
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="verification-container">
                    <div class="photo-comparison">
                        <div class="photo-box">
                            <img id="modal-captured-image" src="" alt="Captured Face">
                            <div class="label">Captured Face (Attendance Scan)</div>
                            <div class="teacher-name" id="modal-teacher-name"></div>
                            <div class="small text-muted">Date: <span id="modal-attendance-date"></span></div>
                            <div class="small text-muted">Check In: <span id="modal-attendance-time"></span></div>
                            <div class="small text-muted">Check Out: <span id="modal-checkout-time"></span></div>
                        </div>
                        <div class="photo-box">
                            <img id="modal-teacher-image" src="" alt="Teacher Photo">
                            <div class="label">Database Photo (Registered)</div>
                            <div class="teacher-name" id="modal-teacher-db-name"></div>
                        </div>
                    </div>
                    
                    <div class="match-score-card">
                        <div class="label">Face Match Score</div>
                        <div class="match-score" id="modal-match-score">0%</div>
                        <div id="modal-match-message"></div>
                    </div>

                    <div class="verification-detail" id="verification-detail">
                        <div class="row">
                            <div class="col-md-4">
                                <strong>Current Status:</strong>
                                <span id="modal-current-status" class="status-badge"></span>
                            </div>
                            <div class="col-md-4">
                                <strong>Attendance Status:</strong>
                                <span id="modal-attendance-status" class="status-badge"></span>
                            </div>
                            <div class="col-md-4">
                                <strong>Verification By:</strong>
                                <span id="modal-verified-by">-</span>
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="col-12">
                                <strong>Admin Notes:</strong>
                                <textarea id="modal-admin-notes" class="admin-notes" rows="3" placeholder="Add notes about verification decision..."></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-warning btn-override" onclick="overrideAttendance(false)">
                    <i class="bi bi-x-circle"></i> Mark as Not Matching (Absent)
                </button>
                <button type="button" class="btn btn-success btn-correct" onclick="overrideAttendance(true)">
                    <i class="bi bi-check-circle"></i> Confirm Match (Present)
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Loading Overlay -->
<div id="loading-overlay" class="loading-overlay">
    <div class="loading-box">
        <div class="loading-spinner"></div>
        <h5>Processing...</h5>
        <p class="text-muted">Please wait while we process your request</p>
    </div>
</div>

<script>
let currentAttendanceId = null;
let currentTeacherId = null;

// Reset filters
function resetFilters() {
    document.getElementById('filter-status').value = 'all';
    document.getElementById('filter-attendance').value = 'all';
    document.getElementById('filter-teacher').value = '';
    document.getElementById('filter-date').value = '';
    loadUnverifiedAttendances();
}

// Load teachers for filter dropdown
async function loadTeachers() {
    try {
        const response = await fetch('api/face_verification_api.php?action=get_teachers');
        const data = await response.json();
        
        if (data.success && data.teachers) {
            const select = document.getElementById('filter-teacher');
            data.teachers.forEach(teacher => {
                const option = document.createElement('option');
                option.value = teacher.id;
                option.textContent = teacher.fullname;
                select.appendChild(option);
            });
        }
    } catch (error) {
        console.error('Error loading teachers:', error);
    }
}

// Load unverified attendances
async function loadUnverifiedAttendances() {
    const loadingDiv = document.getElementById('attendance-list');
    loadingDiv.innerHTML = '<div class="text-center py-5"><div class="spinner-border text-primary"></div><p class="mt-2">Loading records...</p></div>';
    
    const status = document.getElementById('filter-status').value;
    const attendanceStatus = document.getElementById('filter-attendance').value;
    const teacherId = document.getElementById('filter-teacher').value;
    const date = document.getElementById('filter-date').value;
    
    let url = `api/face_verification_api.php?action=get_attendances&status=${status}&attendance_status=${attendanceStatus}`;
    if (teacherId) url += `&teacher_id=${teacherId}`;
    if (date) url += `&date=${date}`;
    
    try {
        const response = await fetch(url);
        const data = await response.json();
        
        if (data.success) {
            updateStats(data.stats);
            displayAttendanceList(data.attendances);
        } else {
            loadingDiv.innerHTML = `<div class="alert alert-danger">${data.message}</div>`;
        }
    } catch (error) {
        console.error('Error:', error);
        loadingDiv.innerHTML = '<div class="alert alert-danger">Error loading data</div>';
    }
}

// Update statistics cards
function updateStats(stats) {
    document.getElementById('total-records').textContent = stats.total || 0;
    document.getElementById('unverified-count').textContent = stats.unverified || 0;
    document.getElementById('verified-count').textContent = stats.verified || 0;
    document.getElementById('overridden-count').textContent = stats.overridden || 0;
}

// Display attendance list with check-out column
function displayAttendanceList(attendances) {
    const container = document.getElementById('attendance-list');
    
    if (!attendances || attendances.length === 0) {
        container.innerHTML = '<div class="text-center py-5"><i class="bi bi-inbox" style="font-size: 48px; color: #ccc;"></i><p class="mt-3">No attendance records found</p></div>';
        return;
    }
    
    let html = '<div class="table-responsive"><table class="table table-hover"><thead><tr>';
    html += '<th>Date</th>';
    html += '<th>Teacher</th>';
    html += '<th>Check In</th>';
    html += '<th>Check Out</th>';
    html += '<th>Duration</th>';
    html += '<th>Attendance Status</th>';
    html += '<th>Match Score</th>';
    html += '<th>Verification Status</th>';
    html += '<th>Verified By</th>';
    html += '<th>Actions</th>';
    html += '</thead><tbody>';
    
    attendances.forEach(record => {
        // Attendance status badge
        let attendanceStatusClass = '';
        let attendanceStatusText = '';
        if (record.attendance_status === 'Present') {
            attendanceStatusClass = 'present';
            attendanceStatusText = 'Present';
        } else if (record.attendance_status === 'Absent') {
            attendanceStatusClass = 'absent';
            attendanceStatusText = 'Absent';
        } else if (record.attendance_status === 'Late') {
            attendanceStatusClass = 'late';
            attendanceStatusText = 'Late';
        } else {
            attendanceStatusClass = 'absent';
            attendanceStatusText = record.attendance_status || 'Unknown';
        }
        
        // Verification status badge
        let verificationStatusClass = '';
        let verificationStatusText = '';
        if (record.admin_override) {
            verificationStatusClass = 'overridden';
            verificationStatusText = 'Admin Overridden';
        } else if (record.match_score >= 70) {
            verificationStatusClass = 'verified';
            verificationStatusText = 'Verified';
        } else {
            verificationStatusClass = 'unverified';
            verificationStatusText = 'Needs Verification';
        }
        
        const scoreColor = record.match_score >= 70 ? 'text-success' : (record.match_score >= 50 ? 'text-warning' : 'text-danger');
        
        // Format check-in and check-out times
        const checkInTime = record.check_in && record.check_in !== '00:00:00' ? record.check_in : '--:--';
        const checkOutTime = record.check_out && record.check_out !== '00:00:00' ? record.check_out : '--:--';
        
        // Calculate duration if both times exist
        let durationHtml = '';
        if (record.check_in && record.check_out && record.check_in !== '00:00:00' && record.check_out !== '00:00:00') {
            const duration = calculateDuration(record.check_in, record.check_out);
            if (duration) {
                durationHtml = `<div class="duration-badge"><i class="bi bi-clock-history"></i> ${duration}</div>`;
            }
        }
        
        html += `<tr>
            <td>${escapeHtml(record.date)}</td>
            <td><strong>${escapeHtml(record.teacher_name)}</strong></td>
            <td>${checkInTime}</td>
            <td>
                ${checkOutTime}
                ${durationHtml}
            </td>
            <td>${durationHtml ? '' : '--:--'}</td>
            <td><span class="status-badge ${attendanceStatusClass}">${attendanceStatusText}</span></td>
            <td class="${scoreColor} fw-bold">${record.match_score ? record.match_score + '%' : 'N/A'}</td>
            <td><span class="status-badge ${verificationStatusClass}">${verificationStatusText}</span></td>
            <td>${record.verified_by_name || '-'}</td>
            <td>
                <button class="btn btn-sm btn-primary" onclick="openVerificationModal(${record.id}, ${record.teacher_id})">
                    <i class="bi bi-shield-check"></i> Verify
                </button>
             </td>
        </tr>`;
    });
    
    html += '</tbody></table></div>';
    container.innerHTML = html;
}

// Calculate duration between check-in and check-out
function calculateDuration(checkIn, checkOut) {
    try {
        const [inHour, inMin, inSec] = checkIn.split(':');
        const [outHour, outMin, outSec] = checkOut.split(':');
        
        const inDate = new Date();
        inDate.setHours(parseInt(inHour), parseInt(inMin), parseInt(inSec || 0));
        
        const outDate = new Date();
        outDate.setHours(parseInt(outHour), parseInt(outMin), parseInt(outSec || 0));
        
        let diffMs = outDate - inDate;
        if (diffMs < 0) {
            // If check-out is next day
            diffMs += 24 * 60 * 60 * 1000;
        }
        
        const diffHrs = Math.floor(diffMs / (1000 * 60 * 60));
        const diffMins = Math.floor((diffMs % (3600000)) / (1000 * 60));
        
        if (diffHrs > 0) {
            return `${diffHrs}h ${diffMins}m`;
        } else {
            return `${diffMins}m`;
        }
    } catch (e) {
        return null;
    }
}

// Open verification modal
async function openVerificationModal(attendanceId, teacherId) {
    currentAttendanceId = attendanceId;
    currentTeacherId = teacherId;
    
    // Show loading overlay
    document.getElementById('loading-overlay').style.display = 'flex';
    
    try {
        const response = await fetch(`api/face_verification_api.php?action=get_verification_details&attendance_id=${attendanceId}&teacher_id=${teacherId}`);
        const data = await response.json();
        
        document.getElementById('loading-overlay').style.display = 'none';
        
        if (data.success) {
            // Set images
            document.getElementById('modal-captured-image').src = data.captured_image_url || 'assets/images/no-image.png';
            document.getElementById('modal-teacher-image').src = data.teacher_photo_url || 'assets/images/default-avatar.png';
            
            // Set teacher info
            document.getElementById('modal-teacher-name').textContent = data.teacher_name;
            document.getElementById('modal-teacher-db-name').textContent = data.teacher_name;
            document.getElementById('modal-attendance-date').textContent = data.date;
            document.getElementById('modal-attendance-time').textContent = data.check_in || '--:--';
            document.getElementById('modal-checkout-time').textContent = data.check_out || '--:--';
            
            // Set match score
            const matchScore = data.match_score || 0;
            const matchScoreElem = document.getElementById('modal-match-score');
            matchScoreElem.textContent = matchScore + '%';
            matchScoreElem.className = 'match-score ' + (matchScore >= 70 ? 'high' : (matchScore >= 50 ? 'medium' : 'low'));
            
            const matchMessage = document.getElementById('modal-match-message');
            if (matchScore >= 70) {
                matchMessage.innerHTML = '<div class="alert alert-success mt-2">✓ Faces match with high confidence</div>';
            } else if (matchScore >= 50) {
                matchMessage.innerHTML = '<div class="alert alert-warning mt-2">⚠️ Partial match - Manual review recommended</div>';
            } else {
                matchMessage.innerHTML = '<div class="alert alert-danger mt-2">✗ Faces do not match - Please verify manually</div>';
            }
            
            // Set verification status
            const verificationSpan = document.getElementById('modal-current-status');
            if (data.admin_override) {
                verificationSpan.className = 'status-badge overridden';
                verificationSpan.textContent = 'Admin Overridden';
            } else if (matchScore >= 70) {
                verificationSpan.className = 'status-badge verified';
                verificationSpan.textContent = 'Verified';
            } else {
                verificationSpan.className = 'status-badge unverified';
                verificationSpan.textContent = 'Needs Verification';
            }
            
            // Set attendance status
            const attendanceSpan = document.getElementById('modal-attendance-status');
            let attendanceClass = '';
            let attendanceText = '';
            if (data.attendance_status === 'Present') {
                attendanceClass = 'present';
                attendanceText = 'Present';
            } else if (data.attendance_status === 'Absent') {
                attendanceClass = 'absent';
                attendanceText = 'Absent';
            } else if (data.attendance_status === 'Late') {
                attendanceClass = 'late';
                attendanceText = 'Late';
            } else {
                attendanceClass = 'absent';
                attendanceText = data.attendance_status || 'Unknown';
            }
            attendanceSpan.className = `status-badge ${attendanceClass}`;
            attendanceSpan.textContent = attendanceText;
            
            document.getElementById('modal-verified-by').textContent = data.verified_by_name || 'Not verified yet';
            document.getElementById('modal-admin-notes').value = data.admin_notes || '';
            
            // Show modal
            const modal = new bootstrap.Modal(document.getElementById('verificationModal'));
            modal.show();
        } else {
            showToast(data.message, 'danger');
        }
    } catch (error) {
        document.getElementById('loading-overlay').style.display = 'none';
        showToast('Error loading verification details', 'danger');
        console.error('Error:', error);
    }
}

// Override attendance
async function overrideAttendance(confirmMatch) {
    const adminNotes = document.getElementById('modal-admin-notes').value;
    
    if (!confirmMatch && !adminNotes) {
        showToast('Please provide notes when marking as not matching', 'warning');
        return;
    }
    
    document.getElementById('loading-overlay').style.display = 'flex';
    
    const formData = new FormData();
    formData.append('action', 'override_attendance');
    formData.append('attendance_id', currentAttendanceId);
    formData.append('teacher_id', currentTeacherId);
    formData.append('confirm_match', confirmMatch ? '1' : '0');
    formData.append('admin_notes', adminNotes);
    
    try {
        const response = await fetch('api/face_verification_api.php', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        document.getElementById('loading-overlay').style.display = 'none';
        
        if (data.success) {
            showToast(data.message, 'success');
            
            // Close modal
            const modal = bootstrap.Modal.getInstance(document.getElementById('verificationModal'));
            modal.hide();
            
            // Reload list
            loadUnverifiedAttendances();
        } else {
            showToast(data.message, 'danger');
        }
    } catch (error) {
        document.getElementById('loading-overlay').style.display = 'none';
        showToast('Error processing request', 'danger');
        console.error('Error:', error);
    }
}

// Show toast notification
function showToast(message, type) {
    const toast = document.createElement('div');
    toast.className = `result-toast alert alert-${type}`;
    toast.innerHTML = `
        <i class="bi bi-${type === 'success' ? 'check-circle-fill' : 'exclamation-triangle-fill'} me-2"></i>
        ${escapeHtml(message)}
    `;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.style.animation = 'slideOut 0.3s ease-out forwards';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// Add slideOut animation
const style = document.createElement('style');
style.textContent = `
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function updateDateTime() {
    const now = new Date();
    document.getElementById('current-date').textContent = now.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
    document.getElementById('current-time').textContent = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
}

// Initialize
loadTeachers();
loadUnverifiedAttendances();
updateDateTime();
setInterval(updateDateTime, 1000);
setInterval(loadUnverifiedAttendances, 30000);
</script>

<?php require_once 'includes/footer.php'; ?>