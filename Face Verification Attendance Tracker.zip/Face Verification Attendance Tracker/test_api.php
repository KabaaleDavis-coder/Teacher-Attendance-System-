<?php
/**
 * API Testing Script
 * Tests all API endpoints
 */

session_start();
require_once 'config/database.php';

echo "<h2>API Endpoints Test</h2>";
echo "<style>
    body { font-family: Arial, sans-serif; padding: 20px; }
    .test-section { margin: 20px 0; padding: 15px; border: 1px solid #ddd; }
    .success { color: green; }
    .error { color: red; }
    .warning { color: orange; }
</style>";

// Test 1: Check if API files exist
echo "<div class='test-section'>";
echo "<h3>Test 1: API Files Existence</h3>";
$api_files = [
    'api/add_teacher.php',
    'api/delete_teacher.php',
    'api/mark_attendance.php',
    'api/fetch_attendance.php'
];

foreach ($api_files as $file) {
    if (file_exists($file)) {
        echo "<p class='success'>✅ $file exists</p>";
    } else {
        echo "<p class='error'>❌ $file does not exist</p>";
    }
}
echo "</div>";

// Test 2: Test fetch_attendance.php without authentication
echo "<div class='test-section'>";
echo "<h3>Test 2: Fetch Attendance (No Auth)</h3>";
echo "<p>Testing API endpoint without authentication...</p>";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "http://" . $_SERVER['HTTP_HOST'] . "/api/fetch_attendance.php");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
$response = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($http_code == 200) {
    $data = json_decode($response, true);
    if (isset($data['success']) && $data['success'] === false && $data['message'] === 'Unauthorized') {
        echo "<p class='success'>✅ Authentication check working - Unauthorized access blocked</p>";
    } else {
        echo "<p class='warning'>⚠️ Response: " . htmlspecialchars($response) . "</p>";
    }
} else {
    echo "<p class='error'>❌ HTTP Code: $http_code</p>";
}
echo "</div>";

// Test 3: Database queries
echo "<div class='test-section'>";
echo "<h3>Test 3: Database Queries</h3>";

// Test teacher query
$teacher_query = "SELECT COUNT(*) as count FROM teachers";
$result = $mysqli->query($teacher_query);
if ($result) {
    $count = $result->fetch_object()->count;
    echo "<p class='success'>✅ Teachers query successful - Found $count teachers</p>";
} else {
    echo "<p class='error'>❌ Teachers query failed: " . $mysqli->error . "</p>";
}

// Test attendance query
$attendance_query = "SELECT COUNT(*) as count FROM attendance WHERE date = CURDATE()";
$result = $mysqli->query($attendance_query);
if ($result) {
    $count = $result->fetch_object()->count;
    echo "<p class='success'>✅ Attendance query successful - Found $count attendance records today</p>";
} else {
    echo "<p class='error'>❌ Attendance query failed: " . $mysqli->error . "</p>";
}
echo "</div>";

// Test 4: Session handling
echo "<div class='test-section'>";
echo "<h3>Test 4: Session Management</h3>";
if (session_status() === PHP_SESSION_ACTIVE) {
    echo "<p class='success'>✅ Session is active</p>";

    if (isset($_SESSION['user_id'])) {
        echo "<p class='success'>✅ User is logged in (ID: " . $_SESSION['user_id'] . ")</p>";
        echo "<p>User Name: " . htmlspecialchars($_SESSION['user_name'] ?? 'N/A') . "</p>";
        echo "<p>User Role: " . htmlspecialchars($_SESSION['user_role'] ?? 'N/A') . "</p>";
    } else {
        echo "<p class='warning'>⚠️ No user is currently logged in</p>";
    }
} else {
    echo "<p class='error'>❌ Session is not active</p>";
}
echo "</div>";

// Test 5: File permissions
echo "<div class='test-section'>";
echo "<h3>Test 5: File Permissions</h3>";
$critical_files = [
    'config/database.php' => 'readable',
    'includes/auth.php' => 'readable',
    'uploads/teachers' => 'writable',
    'uploads/attendance' => 'writable'
];

foreach ($critical_files as $file => $permission) {
    if (file_exists($file)) {
        if ($permission === 'readable' && is_readable($file)) {
            echo "<p class='success'>✅ $file is readable</p>";
        } elseif ($permission === 'writable' && is_writable($file)) {
            echo "<p class='success'>✅ $file is writable</p>";
        } else {
            echo "<p class='error'>❌ $file is not $permission</p>";
        }
    } else {
        echo "<p class='error'>❌ $file does not exist</p>";
    }
}
echo "</div>";

// Test 6: JSON encoding test
echo "<div class='test-section'>";
echo "<h3>Test 6: JSON Encoding</h3>";
$test_data = [
    'success' => true,
    'message' => 'Test message',
    'data' => ['id' => 1, 'name' => 'Test Teacher']
];
$json = json_encode($test_data);
if ($json !== false) {
    echo "<p class='success'>✅ JSON encoding works</p>";
    echo "<pre>" . htmlspecialchars($json) . "</pre>";
} else {
    echo "<p class='error'>❌ JSON encoding failed</p>";
}
echo "</div>";

echo "<hr>";
echo "<h3>Testing Complete</h3>";
echo "<p><a href='test_db_connection.php'>Run Database Tests</a> | <a href='login.php'>Go to Login</a></p>";

$mysqli->close();
?>
