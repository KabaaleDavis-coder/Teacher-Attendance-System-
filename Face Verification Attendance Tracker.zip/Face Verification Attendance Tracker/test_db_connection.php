<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>Database Connection Test</h1>";

// Try to include database.php
$db_path = 'config/database.php';
echo "<p>Looking for database file at: " . realpath($db_path) . "</p>";

if (file_exists($db_path)) {
    echo "<p style='color:green'>✓ database.php found</p>";
    require_once $db_path;
    
    if (isset($mysqli) && $mysqli) {
        echo "<p style='color:green'>✓ Database connection successful</p>";
        
        // Test query
        $result = $mysqli->query("SELECT COUNT(*) as count FROM teachers");
        if ($result) {
            $row = $result->fetch_assoc();
            echo "<p style='color:green'>✓ Found " . $row['count'] . " teachers in database</p>";
        } else {
            echo "<p style='color:red'>✗ Error querying database: " . $mysqli->error . "</p>";
        }
    } else {
        echo "<p style='color:red'>✗ Database connection failed</p>";
    }
} else {
    echo "<p style='color:red'>✗ database.php not found</p>";
}

// Show session info
session_start();
echo "<h2>Session Info:</h2>";
echo "<pre>";
print_r($_SESSION);
echo "</pre>";
?>