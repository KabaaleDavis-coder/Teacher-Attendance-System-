<?php
// Get current page for active state
$current_page = basename($_SERVER['PHP_SELF']);
$sidebar_color = isset($settings->sidebar_color) ? $settings->sidebar_color : '#2c3e50';
?>

<div class="sidebar" id="sidebar">
    <div class="d-flex flex-column h-100">
        <!-- Sidebar Header -->
        <div class="sidebar-header">
            <div class="sidebar-logo">
                <img src="images/logo.jpg" alt="Logo" class="logo-img">
                <h5 class="mb-0"><?php echo htmlspecialchars($settings->system_name ?? 'Attendance System'); ?></h5>
            </div>
        </div>
        
        <!-- Navigation Links -->
        <div class="flex-grow-1">
            <nav class="nav flex-column">
                <a href="dashboard.php" class="nav-link <?php echo $current_page == 'dashboard.php' ? 'active' : ''; ?>">
                    <i class="bi bi-speedometer2"></i> Dashboard
                </a>
                
                <?php if(isset($_SESSION['user_role']) && $_SESSION['user_role'] == 'admin'): ?>
                <a href="teachers.php" class="nav-link <?php echo $current_page == 'teachers.php' ? 'active' : ''; ?>">
                    <i class="bi bi-people"></i> Manage Teachers
                </a>
                <?php endif; ?>
                
                <a href="attendance.php" class="nav-link <?php echo $current_page == 'attendance.php' ? 'active' : ''; ?>">
                    <i class="bi bi-calendar-check"></i> Attendance
                </a>
                
                <?php if(isset($_SESSION['user_role']) && $_SESSION['user_role'] == 'admin'): ?>
                <a href="compare.php" class="nav-link <?php echo $current_page == 'compare.php' ? 'active' : ''; ?>">
                    <i class="bi bi-shield-check"></i> Face Verification
                </a>
                <?php endif; ?>
                
                <a href="reports.php" class="nav-link <?php echo $current_page == 'reports.php' ? 'active' : ''; ?>">
                    <i class="bi bi-file-earmark-bar-graph"></i> Reports
                </a>
                
                <?php if(isset($_SESSION['user_role']) && $_SESSION['user_role'] == 'admin'): ?>
                <a href="settings.php" class="nav-link <?php echo $current_page == 'settings.php' ? 'active' : ''; ?>">
                    <i class="bi bi-gear"></i> Settings
                </a>
                <?php endif; ?>
            </nav>
        </div>
        
        <!-- Sidebar Footer -->
        <div class="sidebar-footer">
            <a href="logout.php" class="logout-btn">
                <i class="bi bi-box-arrow-right"></i> Logout
            </a>
        </div>
    </div>
</div>

<script>
// Mobile sidebar toggle
document.addEventListener('DOMContentLoaded', function() {
    const sidebar = document.getElementById('sidebar');
    const toggleBtn = document.getElementById('sidebarToggle');
    const overlay = document.getElementById('overlay');
    
    if (toggleBtn) {
        toggleBtn.addEventListener('click', function() {
            sidebar.classList.toggle('show');
            overlay.classList.toggle('show');
        });
    }
    
    if (overlay) {
        overlay.addEventListener('click', function() {
            sidebar.classList.remove('show');
            overlay.classList.remove('show');
        });
    }
    
    // Close sidebar on window resize if screen becomes larger
    window.addEventListener('resize', function() {
        if (window.innerWidth > 768) {
            sidebar.classList.remove('show');
            overlay.classList.remove('show');
        }
    });
});
</script>