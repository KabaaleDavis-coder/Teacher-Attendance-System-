   
    <script src="assets/js/ajax.js"></script>
    </div>
</div>
</body>
</html>