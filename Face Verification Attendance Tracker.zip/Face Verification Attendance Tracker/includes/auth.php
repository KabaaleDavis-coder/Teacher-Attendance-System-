<?php
// DO NOT start session here - it should be started in header.php

function isLoggedIn() {
    return isset($_SESSION['user_id']) && isset($_SESSION['user_role']);
}

function isAdmin() {
    return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
}

function requireLogin() {
    if (!isLoggedIn()) {
        //header("Location: login.php");
        printf("<script>document.location.href='login.php'</script>");
        exit();
    }
}

function requireAdmin() {
    requireLogin();
    if (!isAdmin()) {
        printf("<script>document.location.href='login.php'</script>");
        exit();
    }
}
?>