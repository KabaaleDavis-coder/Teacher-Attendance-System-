<?php
// Error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start session if not started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include database and auth
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/auth.php';

// Get system settings
$settings_sql = $mysqli->prepare("SELECT * FROM system_settings LIMIT 1");
if ($settings_sql) {
    $settings_sql->execute();
    $settings_result = $settings_sql->get_result();
    $settings = $settings_result->fetch_object();
} else {
    $settings = new stdClass();
    $settings->system_name = 'Teacher Attendance System';
    $settings->sidebar_color = '#2c3e50';
    $settings->font_family = 'Inter, sans-serif';
    $settings->font_size = '14px';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($settings->system_name ?? 'Teacher Attendance System'); ?></title>
    
    <link rel="icon" href="images/logo.jpg">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            background: #f8f9fc;
            font-family: <?php echo htmlspecialchars($settings->font_family ?? 'Inter, sans-serif'); ?>;
            font-size: <?php echo htmlspecialchars($settings->font_size ?? '14px'); ?>;
            overflow-x: hidden;
            width: 100%;
        }
        
        /* Main Layout Container */
        .app-wrapper {
            display: flex;
            width: 100%;
            min-height: 100vh;
            overflow-x: hidden;
        }
        
        /* Fixed Sidebar Styling */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: 280px;
            height: 100vh;
            background: <?php echo htmlspecialchars($settings->sidebar_color ?? '#2c3e50'); ?>;
            color: white;
            transition: all 0.3s ease-in-out;
            z-index: 1040;
            overflow-y: auto;
            overflow-x: hidden;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            flex-shrink: 0;
        }
        
        /* Custom scrollbar for sidebar */
        .sidebar::-webkit-scrollbar {
            width: 5px;
        }
        
        .sidebar::-webkit-scrollbar-track {
            background: rgba(255,255,255,0.1);
        }
        
        .sidebar::-webkit-scrollbar-thumb {
            background: rgba(255,255,255,0.3);
            border-radius: 5px;
        }
        
        .sidebar::-webkit-scrollbar-thumb:hover {
            background: rgba(255,255,255,0.5);
        }
        
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            transition: 0.3s;
            border-radius: 8px;
            margin: 5px 10px;
        }
        
        .sidebar .nav-link:hover {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        
        .sidebar .nav-link.active {
            background: rgba(255,255,255,0.2);
            color: white;
        }
        
        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
        }
        
        .sidebar-header {
            padding: 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            margin-bottom: 20px;
        }
        
        .sidebar-logo {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .logo-img {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            object-fit: cover;
        }
        
        .sidebar-footer {
            padding: 20px;
            border-top: 1px solid rgba(255,255,255,0.1);
            margin-top: auto;
        }
        
        .logout-btn {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 15px;
            background: #dc3545;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            transition: 0.3s;
        }
        
        .logout-btn:hover {
            background: #c82333;
            color: white;
        }
        
        /* Main Content Area */
        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 20px;
            min-height: 100vh;
            transition: all 0.3s ease-in-out;
            width: calc(100% - 280px);
            max-width: calc(100% - 280px);
            overflow-x: hidden;
        }
        
        /* Mobile toggle button */
        .sidebar-toggle {
            display: none;
            position: fixed;
            top: 15px;
            left: 15px;
            z-index: 1050;
            background: <?php echo htmlspecialchars($settings->sidebar_color ?? '#2c3e50'); ?>;
            border: none;
            color: white;
            width: 45px;
            height: 45px;
            border-radius: 8px;
            font-size: 1.5rem;
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
            transition: all 0.3s;
        }
        
        .sidebar-toggle:hover {
            transform: scale(1.05);
        }
        
        /* Mobile responsive styles */
        @media (max-width: 768px) {
            .sidebar-toggle {
                display: block;
            }
            
            .sidebar {
                left: -280px;
                box-shadow: none;
            }
            
            .sidebar.show {
                left: 0;
                box-shadow: 2px 0 10px rgba(0,0,0,0.2);
            }
            
            .main-content {
                margin-left: 0;
                padding: 70px 15px 20px 15px;
                width: 100%;
                max-width: 100%;
            }
            
            .overlay {
                display: none;
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: rgba(0,0,0,0.5);
                z-index: 1030;
            }
            
            .overlay.show {
                display: block;
            }
        }
        
        /* Tablet styles */
        @media (min-width: 769px) and (max-width: 1024px) {
            .sidebar {
                width: 250px;
            }
            
            .main-content {
                margin-left: 250px;
                width: calc(100% - 250px);
                max-width: calc(100% - 250px);
            }
        }
        
        /* Stats Cards */
        .stat-card {
            background: white;
            border-radius: 20px;
            padding: 1.5rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            transition: all 0.3s ease;
            border-left: 4px solid;
            position: relative;
            overflow: hidden;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        
        .stat-card .stat-icon {
            position: absolute;
            right: 1rem;
            top: 50%;
            transform: translateY(-50%);
            font-size: 3rem;
            opacity: 0.2;
        }
        
        .stat-card.present { border-left-color: #28a745; }
        .stat-card.absent { border-left-color: #dc3545; }
        .stat-card.late { border-left-color: #ffc107; }
        .stat-card.total { border-left-color: <?php echo htmlspecialchars($settings->sidebar_color ?? '#2c3e50'); ?>; }
        
        /* Chart Cards */
        .chart-card {
            background: white;
            border-radius: 20px;
            padding: 1.5rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 1.5rem;
        }
        
        /* Attendance Table */
        .attendance-table {
            background: white;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .attendance-table .table-header {
            background: <?php echo htmlspecialchars($settings->sidebar_color ?? '#2c3e50'); ?>;
            color: white;
            padding: 1rem 1.5rem;
        }
        
        .status-badge {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
            display: inline-block;
        }
        
        .status-badge.present { background: #d4edda; color: #155724; }
        .status-badge.late { background: #fff3cd; color: #856404; }
        .status-badge.absent { background: #f8d7da; color: #721c24; }
        
        .teacher-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
        }
        
        .welcome-banner {
            background: linear-gradient(135deg, <?php echo htmlspecialchars($settings->sidebar_color ?? '#2c3e50'); ?>, <?php echo htmlspecialchars($settings->sidebar_color ?? '#2c3e50'); ?>dd);
            border-radius: 20px;
            padding: 2rem;
            color: white;
            margin-bottom: 2rem;
        }
        
        /* Ensure all containers don't overflow */
        .container-fluid, .row, .col, [class*="col-"] {
            overflow-x: hidden;
        }
        
        /* Fix for any potential overflow */
        .table-responsive {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }
        
        /* Smooth scroll behavior */
        html {
            scroll-behavior: smooth;
        }
        
        /* Animation */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .fade-in-up {
            animation: fadeInUp 0.5s ease-out;
        }
        
        /* Utility classes */
        .cursor-pointer {
            cursor: pointer;
        }
        
        .transition-all {
            transition: all 0.3s ease;
        }
        
        /* Card hover effects */
        .card-hover {
            transition: all 0.3s ease;
        }
        
        .card-hover:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        }
        
        /* Ensure proper box sizing for all elements */
        *, *::before, *::after {
            box-sizing: border-box;
        }
    </style>
</head>
<body>

<!-- Mobile Toggle Button -->
<button class="sidebar-toggle" id="sidebarToggle">
    <i class="bi bi-list"></i>
</button>

<!-- Overlay for mobile -->
<div class="overlay" id="overlay"></div>

<!-- App Wrapper - This contains both sidebar and content -->
<div class="app-wrapper">
    <!-- Sidebar -->
    <?php include 'includes/sidebar.php'; ?>
    
    <!-- Main Content -->
    <div class="main-content">