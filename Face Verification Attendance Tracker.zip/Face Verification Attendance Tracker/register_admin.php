<?php
// Error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', 'error_log.txt');

session_start();
require_once 'config/database.php';
require_once 'api/mailer.php';

// Fetch system settings for styling consistency
$settings_sql = $mysqli->prepare("SELECT * FROM system_settings LIMIT 1");
$settings_sql->execute();
$settings_result = $settings_sql->get_result();
$settings = $settings_result->fetch_object();

// Set defaults if no settings exist
$system_name = $settings->system_name ?? 'Teacher Attendance System';
$sidebar_color = $settings->sidebar_color ?? '#343a40';
$font_family = $settings->font_family ?? 'Inter, sans-serif';
$font_size = $settings->font_size ?? '14px';

$error = '';
$success = '';
$show_verification_section = false;
$registered_email = '';
$registered_user_id = '';

// Handle verification form submission
if (isset($_POST['verify_code'])) {
    $verification_code = trim($_POST['verification_code']);
    $registered_email = trim($_POST['registered_email']);
    
    if (empty($verification_code)) {
        $error = "Please enter your verification code.";
    } else {
        try {
            // Check if verification code exists and is valid
            $verify_stmt = $mysqli->prepare("
                SELECT av.*, u.id as user_id, u.fullname, u.email 
                FROM admin_verifications av 
                JOIN users u ON av.user_id = u.id 
                WHERE av.verification_code = ? AND av.verified_at IS NULL AND av.expires_at > NOW()
            ");
            $verify_stmt->bind_param("s", $verification_code);
            $verify_stmt->execute();
            $verify_result = $verify_stmt->get_result();
            $verification = $verify_result->fetch_assoc();
            
            if ($verification) {
                // Mark as verified
                $update_stmt = $mysqli->prepare("UPDATE admin_verifications SET verified_at = NOW() WHERE id = ?");
                $update_stmt->bind_param("i", $verification['id']);
                $update_stmt->execute();
                
                $success = "Account verified successfully! Redirecting to login...";
                
                // Redirect after 3 seconds
                echo "<script>
                    setTimeout(function() {
                        window.location.href = 'login.php';
                    }, 3000);
                </script>";
            } else {
                $error = "Invalid or expired verification code. Please check your email or register again.";
            }
        } catch (Exception $e) {
            $error = "Verification failed: " . $e->getMessage();
            error_log("Verification error: " . $e->getMessage());
        }
    }
}

// Handle registration form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register'])) {
    $fullname = mysqli_real_escape_string($mysqli, $_POST['fullname']);
    $email = mysqli_real_escape_string($mysqli, $_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if ($password !== $confirm_password) {
        $error = "Passwords do not match";
    } elseif (strlen($password) < 6) {
        $error = "Password must be at least 6 characters long";
    } else {
        // Check if email already exists in users table
        $check_stmt = $mysqli->prepare("SELECT id, role FROM users WHERE email = ?");
        $check_stmt->bind_param("s", $email);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();
        $existing_user = $check_result->fetch_assoc();

        if ($existing_user) {
            if ($existing_user['role'] == 'admin') {
                $error = "Email already registered as admin. Please login.";
            } else {
                $error = "Email already exists. Please use a different email address.";
            }
        } else {
            // Check for pending verification (unverified admin)
            $pending_check = $mysqli->prepare("
                SELECT av.*, u.email 
                FROM admin_verifications av 
                JOIN users u ON av.user_id = u.id 
                WHERE u.email = ? AND av.verified_at IS NULL AND av.expires_at > NOW()
            ");
            $pending_check->bind_param("s", $email);
            $pending_check->execute();
            $pending_result = $pending_check->get_result();

            if ($pending_result->num_rows > 0) {
                $error = "A pending verification already exists for this email. Please check your email and enter the verification code below.";
                $show_verification_section = true;
                $registered_email = $email;
            } else {
                // Start transaction
                $mysqli->begin_transaction();

                try {
                    // Insert new user with role admin (but not yet verified)
                    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                    $role = 'admin';

                    $stmt = $mysqli->prepare("INSERT INTO users (fullname, email, password, role) VALUES (?, ?, ?, ?)");
                    $stmt->bind_param("ssss", $fullname, $email, $hashed_password, $role);

                    if ($stmt->execute()) {
                        $user_id = $mysqli->insert_id;

                        // Generate verification code in format: user_id-XXXX (4-digit random)
                        $randomCode = str_pad(mt_rand(1, 9999), 4, '0', STR_PAD_LEFT);
                        $verificationCode = $user_id . '-' . $randomCode;
                        $expiresAt = date('Y-m-d H:i:s', strtotime('+24 hours'));

                        // Store verification record
                        $verify_stmt = $mysqli->prepare("
                            INSERT INTO admin_verifications (user_id, verification_code, email, expires_at) 
                            VALUES (?, ?, ?, ?)
                        ");
                        $verify_stmt->bind_param("isss", $user_id, $verificationCode, $email, $expiresAt);
                        $verify_stmt->execute();

                        // Send verification email
                        $emailResult = sendVerificationEmail($email, $fullname, $verificationCode, $system_name, $sidebar_color);

                        if ($emailResult['success']) {
                            $mysqli->commit();
                            $success = "Registration successful! A verification email has been sent to <strong>" . htmlspecialchars($email) . "</strong>";
                            $show_verification_section = true;
                            $registered_email = $email;
                            $registered_user_id = $user_id;
                        } else {
                            // Rollback if email fails
                            $mysqli->rollback();
                            $error = "Registration failed: Unable to send verification email. Please try again.<br>Error: " . $emailResult['message'];
                        }
                    } else {
                        $mysqli->rollback();
                        $error = "Registration failed. Please try again.";
                    }
                } catch (Exception $e) {
                    $mysqli->rollback();
                    $error = "Registration failed: " . $e->getMessage();
                    error_log("Registration error: " . $e->getMessage());
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Registration - <?php echo htmlspecialchars($system_name); ?></title>
    <!-- Favicon -->
    <link rel="icon" type="image/jpeg" href="images/logo.jpg">
    <link rel="shortcut icon" type="image/jpeg" href="images/logo.jpg">
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&family=Poppins:wght@500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: linear-gradient(145deg, 
                <?php echo htmlspecialchars($sidebar_color); ?>CC 0%, 
                <?php echo htmlspecialchars($sidebar_color); ?> 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: <?php echo htmlspecialchars($font_family); ?>;
            font-size: <?php echo htmlspecialchars($font_size); ?>;
            padding: 1.5rem;
            position: relative;
        }

        /* Background overlay with logo pattern */
        body::before {
            content: "";
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-image: url('images/logo.jpg');
            background-repeat: repeat;
            background-size: 60px;
            background-position: center;
            opacity: 0.08;
            pointer-events: none;
            z-index: 0;
        }

        body::after {
            content: "";
            position: absolute;
            width: 100%;
            height: 100%;
            background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="rgba(255,255,255,0.08)" fill-opacity="0.5" d="M0,96L48,112C96,128,192,160,288,160C384,160,480,128,576,122.7C672,117,768,139,864,154.7C960,171,1056,181,1152,165.3C1248,149,1344,107,1392,85.3L1440,64L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path></svg>');
            background-repeat: no-repeat;
            background-position: bottom;
            background-size: cover;
            opacity: 0.3;
            bottom: 0;
            left: 0;
            pointer-events: none;
            z-index: 0;
        }

        .register-wrapper {
            width: 100%;
            max-width: 550px;
            position: relative;
            z-index: 2;
            animation: fadeSlideUp 0.6s ease-out;
        }

        @keyframes fadeSlideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .register-card {
            background: rgba(255, 255, 255, 0.98);
            border-radius: 2rem;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.35);
            padding: 2rem 2rem 2.2rem;
            transition: transform 0.2s ease;
            border: 1px solid rgba(255,255,255,0.3);
        }

        .register-card:hover {
            transform: translateY(-4px);
        }

        .logo-area {
            text-align: center;
            margin-bottom: 1.5rem;
        }

        .logo-img {
            width: 85px;
            height: 85px;
            object-fit: cover;
            border-radius: 50%;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
            border: 3px solid white;
            background: #f8f9fc;
            padding: 4px;
            transition: all 0.3s;
        }

        .logo-img:hover {
            transform: scale(1.02);
            box-shadow: 0 12px 24px rgba(0, 0, 0, 0.2);
        }

        .brand-title {
            font-family: 'Poppins', sans-serif;
            font-weight: 700;
            font-size: 1.75rem;
            margin-top: 0.75rem;
            margin-bottom: 0.25rem;
            background: linear-gradient(135deg, 
                <?php echo htmlspecialchars($sidebar_color); ?>, 
                <?php echo htmlspecialchars($sidebar_color); ?>dd);
            background-clip: text;
            -webkit-background-clip: text;
            color: transparent;
            letter-spacing: -0.3px;
        }

        .badge-admin {
            background: <?php echo htmlspecialchars($sidebar_color); ?>15;
            color: <?php echo htmlspecialchars($sidebar_color); ?>;
            font-size: 0.75rem;
            font-weight: 600;
            padding: 0.25rem 0.9rem;
            border-radius: 40px;
            display: inline-block;
            margin-top: 6px;
        }

        .form-label {
            font-weight: 600;
            font-size: 0.85rem;
            margin-bottom: 0.4rem;
            color: <?php echo htmlspecialchars($sidebar_color); ?>;
            letter-spacing: -0.2px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .form-label i {
            color: <?php echo htmlspecialchars($sidebar_color); ?>;
            font-size: 0.9rem;
            width: 20px;
        }

        .input-group-custom {
            position: relative;
        }

        .form-control {
            border-radius: 1rem;
            border: 1px solid #e2e8f0;
            padding: 0.7rem 1rem;
            font-size: <?php echo htmlspecialchars($font_size); ?>;
            transition: all 0.2s;
            background-color: #ffffff;
            font-weight: 500;
        }

        .form-control:focus {
            border-color: <?php echo htmlspecialchars($sidebar_color); ?>;
            box-shadow: 0 0 0 4px <?php echo htmlspecialchars($sidebar_color); ?>25;
            outline: none;
        }

        .form-control.is-valid {
            border-color: #198754;
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 8 8'%3e%3cpath fill='%23198754' d='M2.3 6.73L.6 4.53c-.4-1.04.46-1.4 1.1-.8l1.1 1.4 3.4-3.8c.6-.63 1.6-.27 1.2.7l-4 4.6c-.43.5-.8.4-1.1.1z'/%3e%3c/svg%3e");
            background-repeat: no-repeat;
            background-position: right 1rem center;
            background-size: 1rem;
            padding-right: 2.5rem;
        }
        
        .form-control.is-invalid {
            border-color: #dc3545;
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 12 12' width='12' height='12' fill='none' stroke='%23dc3545'%3e%3ccircle cx='6' cy='6' r='4.5'/%3e%3cpath stroke-linecap='round' d='M5.8 3.6h.4L6 6.5z'/%3e%3ccircle cx='6' cy='8.2' r='.6' fill='%23dc3545' stroke='none'/%3e%3c/svg%3e");
            background-repeat: no-repeat;
            background-position: right 1rem center;
            background-size: 1rem;
            padding-right: 2.5rem;
        }
        
        .invalid-feedback, .valid-feedback {
            font-size: 0.75rem;
            margin-top: 0.25rem;
        }
        
        .password-strength {
            height: 4px;
            border-radius: 2px;
            margin-top: 5px;
            transition: all 0.3s;
            background-color: #e2e8f0;
        }

        .password-toggle {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #8ba0ae;
            background: white;
            padding-left: 6px;
            z-index: 5;
        }

        .password-toggle:hover {
            color: <?php echo htmlspecialchars($sidebar_color); ?>;
        }

        .btn-register, .btn-verify {
            background: linear-gradient(95deg, 
                <?php echo htmlspecialchars($sidebar_color); ?>, 
                <?php echo htmlspecialchars($sidebar_color); ?>cc);
            border: none;
            border-radius: 2rem;
            padding: 0.8rem;
            font-weight: 700;
            font-size: 1rem;
            transition: all 0.25s;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            letter-spacing: 0.3px;
            color: white;
        }

        .btn-register:hover, .btn-verify:hover {
            background: linear-gradient(95deg, 
                <?php echo htmlspecialchars($sidebar_color); ?>dd, 
                <?php echo htmlspecialchars($sidebar_color); ?>);
            transform: scale(1.01);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
            color: white;
        }
        
        .btn-register:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }

        .login-link {
            text-decoration: none;
            font-weight: 600;
            color: <?php echo htmlspecialchars($sidebar_color); ?>;
            transition: 0.2s;
        }

        .login-link:hover {
            color: <?php echo htmlspecialchars($sidebar_color); ?>cc;
            text-decoration: underline;
        }

        hr {
            background: #dee2e6;
            opacity: 0.5;
        }

        .alert {
            border-radius: 1.2rem;
            border: none;
            font-weight: 500;
            font-size: 0.85rem;
            padding: 0.8rem 1rem;
        }

        .alert-danger {
            background: #ffe6e5;
            color: #b13e3e;
        }

        .alert-success {
            background: #e0f7ef;
            color: #1d6f4c;
        }

        .info-box {
            background: #f8f9fa;
            border-left: 4px solid <?php echo htmlspecialchars($sidebar_color); ?>;
            padding: 1rem;
            border-radius: 0.5rem;
            margin-bottom: 1rem;
        }

        .verification-section {
            animation: slideDown 0.5s ease-out;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .registration-section {
            transition: all 0.5s ease;
        }
        
        .registration-section.hide {
            display: none;
        }

        @media (max-width: 480px) {
            .register-card {
                padding: 1.5rem;
            }
            .brand-title {
                font-size: 1.5rem;
            }
            .logo-img {
                width: 70px;
                height: 70px;
            }
        }
        
        .checking-status {
            font-size: 0.7rem;
            margin-top: 0.25rem;
        }
    </style>
</head>
<body>

<div class="register-wrapper">
    <div class="register-card">
        
        <div class="logo-area">
            <img src="images/logo.jpg" alt="<?php echo htmlspecialchars($system_name); ?> Logo" class="logo-img" onerror="this.onerror=null; this.src='https://placehold.co/200x200?text=Logo';">
            <div class="brand-title"><?php echo htmlspecialchars($system_name); ?></div>
            <div class="badge-admin"><i class="fas fa-shield-alt me-1"></i> Admin Registration</div>
        </div>

        <?php if(!empty($error)): ?>
        <div class="alert alert-danger d-flex align-items-center" role="alert">
            <i class="fas fa-exclamation-circle me-2"></i>
            <div><?php echo $error; ?></div>
        </div>
        <?php endif; ?>

        <?php if(!empty($success)): ?>
        <div class="alert alert-success d-flex align-items-center" role="alert">
            <i class="fas fa-check-circle me-2"></i>
            <div><?php echo $success; ?></div>
        </div>
        <?php endif; ?>

        <!-- Registration Section - Hidden after successful registration -->
        <div class="registration-section <?php echo $show_verification_section ? 'hide' : ''; ?>">
            <form method="POST" action="" id="registerForm">
                <div class="mb-3">
                    <label for="fullname" class="form-label">
                        <i class="fas fa-user-circle"></i> Full Name
                    </label>
                    <div class="input-group-custom">
                        <input type="text" class="form-control" id="fullname" name="fullname" 
                               placeholder="Enter your full name" required>
                    </div>
                </div>

                <div class="mb-3">
                    <label for="email" class="form-label">
                        <i class="fas fa-envelope"></i> Email Address
                    </label>
                    <div class="input-group-custom">
                        <input type="email" class="form-control" id="email" name="email" 
                               placeholder="admin@school.edu" required autocomplete="off">
                        <div class="checking-status" id="emailStatus"></div>
                    </div>
                </div>

                <div class="mb-3">
                    <label for="password" class="form-label">
                        <i class="fas fa-lock"></i> Password
                    </label>
                    <div class="input-group-custom position-relative">
                        <input type="password" class="form-control" id="password" name="password" 
                               placeholder="Create a strong password" required>
                        <span class="password-toggle" id="togglePassword">
                            <i class="far fa-eye-slash" id="togglePasswordIcon"></i>
                        </span>
                    </div>
                    <div class="password-strength" id="passwordStrength"></div>
                    <div class="form-text" id="passwordHelp" style="font-size: 0.7rem;"></div>
                </div>

                <div class="mb-4">
                    <label for="confirm_password" class="form-label">
                        <i class="fas fa-check-double"></i> Confirm Password
                    </label>
                    <div class="input-group-custom position-relative">
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" 
                               placeholder="Repeat your password" required>
                        <span class="password-toggle" id="toggleConfirmPassword">
                            <i class="far fa-eye-slash" id="toggleConfirmIcon"></i>
                        </span>
                    </div>
                    <div class="invalid-feedback" id="confirmFeedback"></div>
                </div>

                <input type="hidden" name="register" value="1">
                <button type="submit" class="btn btn-register w-100 py-2" id="registerBtn" disabled>
                    <i class="fas fa-user-plus me-2"></i> Register & Send Verification
                </button>
            </form>
        </div>

        <!-- Verification Section - Only appears after successful registration -->
        <?php if($show_verification_section): ?>
        <div class="verification-section">
            <div class="info-box">
                <i class="fas fa-envelope me-2" style="color: <?php echo htmlspecialchars($sidebar_color); ?>;"></i>
                <strong>Check your email!</strong><br>
                We've sent a verification code to <strong><?php echo htmlspecialchars($registered_email); ?></strong>. 
                Enter the code below to activate your account.
            </div>
            
            <form method="POST" action="">
                <div class="mb-3">
                    <label for="verification_code" class="form-label">
                        <i class="fas fa-key"></i> Verification Code
                    </label>
                    <div class="input-group-custom">
                        <input type="text" class="form-control" id="verification_code" name="verification_code" 
                               placeholder="Enter code (e.g., 1-1234)" required autocomplete="off">
                    </div>
                    <div class="form-text" style="font-size: 0.7rem;">Enter the verification code sent to your email address. Format: UserID-XXXX</div>
                </div>
                
                <input type="hidden" name="registered_email" value="<?php echo htmlspecialchars($registered_email); ?>">
                <button type="submit" name="verify_code" class="btn btn-verify w-100 py-2">
                    <i class="fas fa-check-circle me-2"></i> Verify Account
                </button>
            </form>
            
            <div class="text-center mt-3">
                <p class="text-muted small mb-0">
                    <i class="fas fa-envelope me-1"></i> Didn't receive the email? 
                    <a href="register_admin.php" class="login-link">Register again</a>
                </p>
            </div>
        </div>
        <?php endif; ?>

        <hr class="my-4">

        <div class="text-center">
            <p class="text-muted mb-0" style="font-size: 0.9rem;">
                <i class="fas fa-arrow-left me-1"></i> Already have a verified account? 
                <a href="login.php" class="login-link">Sign in here</a>
            </p>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    (function() {
        // DOM Elements
        const fullnameInput = document.getElementById('fullname');
        const emailInput = document.getElementById('email');
        const passwordInput = document.getElementById('password');
        const confirmInput = document.getElementById('confirm_password');
        const registerBtn = document.getElementById('registerBtn');
        const emailStatus = document.getElementById('emailStatus');
        const passwordStrength = document.getElementById('passwordStrength');
        const passwordHelp = document.getElementById('passwordHelp');
        const confirmFeedback = document.getElementById('confirmFeedback');
        
        let emailTimeout;
        let isEmailValid = false;
        let isPasswordValid = false;
        let isConfirmValid = false;
        let isFullnameValid = false;
        
        // Function to check if email format is valid
        function isValidEmail(email) {
            const re = /^[^\s@]+@([^\s@]+\.)+[^\s@]+$/;
            return re.test(email);
        }
        
        // Function to validate confirm password
        function validateConfirmPassword() {
            const password = passwordInput.value;
            const confirm = confirmInput.value;
            
            if (confirm === '') {
                confirmInput.classList.remove('is-valid', 'is-invalid');
                if (confirmFeedback) confirmFeedback.textContent = '';
                isConfirmValid = false;
                validateForm();
                return;
            }
            
            if (password === confirm) {
                confirmInput.classList.remove('is-invalid');
                confirmInput.classList.add('is-valid');
                if (confirmFeedback) confirmFeedback.textContent = '';
                isConfirmValid = true;
            } else {
                confirmInput.classList.remove('is-valid');
                confirmInput.classList.add('is-invalid');
                if (confirmFeedback) confirmFeedback.textContent = 'Passwords do not match';
                isConfirmValid = false;
            }
            validateForm();
        }
        
        // Full name validation
        function validateFullname() {
            const fullname = fullnameInput.value.trim();
            if (fullname.length >= 3) {
                fullnameInput.classList.add('is-valid');
                fullnameInput.classList.remove('is-invalid');
                isFullnameValid = true;
            } else {
                fullnameInput.classList.remove('is-valid');
                if (fullname.length > 0) {
                    fullnameInput.classList.add('is-invalid');
                } else {
                    fullnameInput.classList.remove('is-invalid');
                }
                isFullnameValid = false;
            }
            validateForm();
        }
        
        // Real-time email availability check
        emailInput.addEventListener('input', function() {
            clearTimeout(emailTimeout);
            const email = this.value.trim();
            
            if (email === '') {
                emailStatus.innerHTML = '';
                this.classList.remove('is-valid', 'is-invalid');
                isEmailValid = false;
                validateForm();
                return;
            }
            
            if (!isValidEmail(email)) {
                emailStatus.innerHTML = '<span class="text-danger"><i class="fas fa-times-circle me-1"></i>Invalid email format</span>';
                this.classList.remove('is-valid');
                this.classList.add('is-invalid');
                isEmailValid = false;
                validateForm();
                return;
            }
            
            emailStatus.innerHTML = '<span class="text-muted"><i class="fas fa-spinner fa-spin me-1"></i>Checking availability...</span>';
            
            emailTimeout = setTimeout(function() {
                fetch('api/check_email.php?email=' + encodeURIComponent(email))
                    .then(response => response.json())
                    .then(data => {
                        if (data.available) {
                            emailStatus.innerHTML = '<span class="text-success"><i class="fas fa-check-circle me-1"></i>Email available</span>';
                            emailInput.classList.remove('is-invalid');
                            emailInput.classList.add('is-valid');
                            isEmailValid = true;
                        } else {
                            emailStatus.innerHTML = '<span class="text-danger"><i class="fas fa-times-circle me-1"></i>' + data.message + '</span>';
                            emailInput.classList.remove('is-valid');
                            emailInput.classList.add('is-invalid');
                            isEmailValid = false;
                        }
                        validateForm();
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        emailStatus.innerHTML = '<span class="text-danger"><i class="fas fa-exclamation-circle me-1"></i>Error checking email</span>';
                        isEmailValid = false;
                        validateForm();
                    });
            }, 500);
        });
        
        // Real-time password strength validation
        passwordInput.addEventListener('input', function() {
            const password = this.value;
            
            if (password === '') {
                if (passwordStrength) passwordStrength.style.width = '0%';
                if (passwordStrength) passwordStrength.style.backgroundColor = '#e2e8f0';
                if (passwordHelp) passwordHelp.innerHTML = '';
                this.classList.remove('is-valid', 'is-invalid');
                isPasswordValid = false;
                // Reset confirm password validation
                if (confirmInput.value !== '') {
                    validateConfirmPassword();
                }
                validateForm();
                return;
            }
            
            // Check password strength
            let strength = 0;
            let strengthText = '';
            let strengthColor = '';
            
            if (password.length >= 6) strength++;
            if (password.length >= 8) strength++;
            if (/[A-Z]/.test(password)) strength++;
            if (/[0-9]/.test(password)) strength++;
            if (/[^A-Za-z0-9]/.test(password)) strength++;
            
            if (strength <= 2) {
                strengthText = 'Weak';
                strengthColor = '#dc3545';
                this.classList.add('is-invalid');
                this.classList.remove('is-valid');
                isPasswordValid = false;
            } else if (strength <= 4) {
                strengthText = 'Medium';
                strengthColor = '#ffc107';
                this.classList.add('is-valid');
                this.classList.remove('is-invalid');
                isPasswordValid = true;
            } else {
                strengthText = 'Strong';
                strengthColor = '#198754';
                this.classList.add('is-valid');
                this.classList.remove('is-invalid');
                isPasswordValid = true;
            }
            
            const percentage = (strength / 5) * 100;
            if (passwordStrength) passwordStrength.style.width = percentage + '%';
            if (passwordStrength) passwordStrength.style.backgroundColor = strengthColor;
            if (passwordHelp) passwordHelp.innerHTML = 'Strength: ' + strengthText + ' | ' + password.length + ' characters';
            
            // Re-validate confirm password
            if (confirmInput.value !== '') {
                validateConfirmPassword();
            } else {
                // If confirm is empty, set isConfirmValid to false
                isConfirmValid = false;
                if (confirmFeedback) confirmFeedback.textContent = '';
            }
            
            validateForm();
        });
        
        // Confirm password validation
        confirmInput.addEventListener('input', validateConfirmPassword);
        
        // Full name validation
        fullnameInput.addEventListener('input', validateFullname);
        
        // Form validation function
        function validateForm() {
            // Check all validation flags
            const allValid = isFullnameValid && isEmailValid && isPasswordValid && isConfirmValid;
            
            if (registerBtn) {
                registerBtn.disabled = !allValid;
                
                // Debug: Log validation status (remove in production)
                console.log({
                    fullname: isFullnameValid,
                    email: isEmailValid,
                    password: isPasswordValid,
                    confirm: isConfirmValid,
                    allValid: allValid
                });
            }
        }
        
        // Password visibility toggle
        const togglePassword = document.getElementById('togglePassword');
        if(togglePassword && passwordInput) {
            togglePassword.addEventListener('click', function() {
                const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
                passwordInput.setAttribute('type', type);
                const icon = document.getElementById('togglePasswordIcon');
                if (icon) {
                    icon.classList.toggle('fa-eye');
                    icon.classList.toggle('fa-eye-slash');
                }
            });
        }
        
        const toggleConfirm = document.getElementById('toggleConfirmPassword');
        const confirmField = document.getElementById('confirm_password');
        if(toggleConfirm && confirmField) {
            toggleConfirm.addEventListener('click', function() {
                const type = confirmField.getAttribute('type') === 'password' ? 'text' : 'password';
                confirmField.setAttribute('type', type);
                const icon = document.getElementById('toggleConfirmIcon');
                if (icon) {
                    icon.classList.toggle('fa-eye');
                    icon.classList.toggle('fa-eye-slash');
                }
            });
        }
        
        // Initial validation trigger
        validateFullname();
        
        // Add some visual feedback for the button state
        if (registerBtn) {
            registerBtn.addEventListener('mouseenter', function() {
                if (this.disabled) {
                    this.title = 'Please fill all fields correctly';
                }
            });
        }
    })();
</script>
</body>
</html>