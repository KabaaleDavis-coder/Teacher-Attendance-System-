<?php
header('Content-Type: application/json');

require_once dirname(__DIR__) . '/config/database.php';

session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);
$attendance_id = intval($input['attendance_id'] ?? 0);
$is_verified = isset($input['is_verified']) ? $input['is_verified'] : false;
$notes = $input['notes'] ?? '';

if ($attendance_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid attendance ID']);
    exit();
}

// Update face verification log
$update_stmt = $mysqli->prepare("
    UPDATE face_verification_logs 
    SET admin_override = ?, admin_notes = ? 
    WHERE attendance_id = ?
");
$admin_override = $is_verified ? 1 : 0;
$update_stmt->bind_param("isi", $admin_override, $notes, $attendance_id);
$update_stmt->execute();

if ($update_stmt->affected_rows >= 0) {
    echo json_encode(['success' => true, 'message' => 'Verification saved']);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to save verification']);
}

$update_stmt->close();
$mysqli->close();
?>